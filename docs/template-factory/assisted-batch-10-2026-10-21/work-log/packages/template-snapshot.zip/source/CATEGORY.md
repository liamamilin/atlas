# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_a5ba5020abbe461fa5992a4e01bee420@1

按日登记项目开始结束时间和休息分钟数，自动计算净工时，修改后日汇总立即重算。

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_work_log_1

https://github.com/kimai/kimai/blob/acc17ef21c2f1466a0b399cf6595fd4b20b1f085/src/Entity/Timesheet.php · acc17ef21c2f1466a0b399cf6595fd4b20b1f085

code_observation: Timesheet分别记录日期、begin/end、duration、break、user、activity、project和description。

AGPL-3.0（LICENSE；只研究，不复制实现）

https://github.com/kimai/kimai/blob/acc17ef21c2f1466a0b399cf6595fd4b20b1f085/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S03 · ev_assisted_work_log_2

https://github.com/kimai/kimai/blob/acc17ef21c2f1466a0b399cf6595fd4b20b1f085/src/Entity/Timesheet.php · acc17ef21c2f1466a0b399cf6595fd4b20b1f085

code_observation: getCalculatedDuration使用结束时间减开始时间再减break；running记录另有警告。

AGPL-3.0（LICENSE；只研究，不复制实现）

https://github.com/kimai/kimai/blob/acc17ef21c2f1466a0b399cf6595fd4b20b1f085/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S04 · ev_assisted_work_log_design

https://github.com/kimai/kimai/blob/acc17ef21c2f1466a0b399cf6595fd4b20b1f085/LICENSE · acc17ef21c2f1466a0b399cf6595fd4b20b1f085

inference: 目标只记录已结束的同日工作，不做运行中计时器、账单费率、后台监控或跨时区时间；以分钟整数派生日总。

AGPL-3.0（LICENSE；只研究，不复制实现）

https://github.com/kimai/kimai/blob/acc17ef21c2f1466a0b399cf6595fd4b20b1f085/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## 待验证

- 证据独立审阅pending
- 上游not_run
- 辅助试用，非严格G1/T08；Codex研究与编写，证据独审pending，上游未运行。
- 本模板尚未开发代表应用或取得下游运行证据；验收程序仅编译检查，不能据此声称运行通过。
- 单人本机显式保存，无账户、云同步、协作；不复制上游实现。
- 不做计费、发票、自动计时、跨午夜或夏令时跨度计算。
