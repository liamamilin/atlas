# 架构与契约

## 运行边界
Python标准库HTTP+SQLite，本机127.0.0.1；--data-dir独立目录，--demo仅新库首次初始化。GET只读，所有错误JSON为{error:{code,message}}，失败零写入，未知ID404not_found。输入类型先校验；事务保存；UI文本转义，无第三方资源。
## 数据与规则
projects(id,name UNIQUE)，entries(id,project_id,date,start,end,break_minutes,notes)。时间HH:MM按本地墙上时间，end>start且同日，break为整数0..区间；净时长可为0。所有项目同日工作半开区间[start,end)不得重叠，相邻可接；更正时排除自己。更新重新派生duration_minutes，不累计旧汇总。
## 接口
GET /api/health；GET /api/state?date=YYYY-MM-DD -> {projects,entries:[含duration_minutes],summary:{total_minutes,by_project}}；POST /api/projects {name}->201；POST /api/entries {project_id,date,start,end,break_minutes,notes}->201；POST /api/entries/update {id,project_id,date,start,end,break_minutes,notes}->200。400 invalid_time/invalid_break/invalid_date/invalid_name，重叠409overlap；未知项目404。
## 交互
日期导航、项目选择、开始结束和休息字段，明确分钟和净工时；条目编辑显式保存，错误保留输入；空日不显示上日工时。
## 来源与推断
目标只记录已结束的同日工作，不做运行中计时器、账单费率、后台监控或跨时区时间；以分钟整数派生日总。
