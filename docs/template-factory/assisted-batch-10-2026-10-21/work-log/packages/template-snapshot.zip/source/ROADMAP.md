# 阶段与验收

## P0 · 核心可用

按日登记项目开始结束时间和休息分钟数，自动计算净工时，修改后日汇总立即重算。

| 用例 | 类型 | 行为 | 执行器 |
| --- | --- | --- | --- |
| A01 | positive | 项目A登记09:00–11:00休息15分钟，净105分钟。 | acceptance/probe.py |
| A02 | positive | 再记13:00–14:00得到总165分钟；第一条休息改30后日总150。 | acceptance/probe.py |
| A03 | positive | 同日重叠、倒置时间、休息超过区间或跨午夜拒绝；另一日不混入。 | acceptance/probe.py |
| A04 | positive | 重启保留项目与条目，汇总与保存前一致。 | acceptance/probe.py |
