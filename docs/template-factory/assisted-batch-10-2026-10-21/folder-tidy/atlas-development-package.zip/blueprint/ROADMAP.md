# 阶段与验收

## P0 · 核心可用

浏览独立沙箱文件，先预览重命名及子目录移动，再确认执行；禁止覆盖、越界和跟随符号链接。

| 用例 | 类型 | 行为 | 执行器 |
| --- | --- | --- | --- |
| A01 | positive | 临时沙箱有note.txt，创建“归档”子目录并预览归档/notes.txt，不立即移动。 | acceptance/probe.py |
| A02 | positive | 确认token后移动成功，原文件消失、目标字节摘要一致；重复确认只返回既有结果。 | acceptance/probe.py |
| A03 | positive | ../、绝对路径、符号链接、目标已存在或预览后源变化均失败且不覆盖。 | acceptance/probe.py |
| A04 | positive | 同沙箱及数据目录重启，目录结构、文件内容和操作记录保留。 | acceptance/probe.py |
