# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_639d6d74b2914439867875295f4ab528@1

浏览独立沙箱文件，先预览重命名及子目录移动，再确认执行；禁止覆盖、越界和跟随符号链接。

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_folder_tidy_1

https://github.com/filebrowser/filebrowser/blob/833d908884d5c801f30f5c098d7977177eb3a36b/files/scoped.go · 833d908884d5c801f30f5c098d7977177eb3a36b

code_observation: ScopedFs说明在BasePathFs之上为可访问磁盘的操作增加范围检查，防止符号链接逃逸。

Apache-2.0（LICENSE；只研究，不复制实现）

https://github.com/filebrowser/filebrowser/blob/833d908884d5c801f30f5c098d7977177eb3a36b/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S03 · ev_assisted_folder_tidy_2

https://github.com/filebrowser/filebrowser/blob/833d908884d5c801f30f5c098d7977177eb3a36b/files/scoped.go · 833d908884d5c801f30f5c098d7977177eb3a36b

code_observation: guard调用within，而within对root和目标使用EvalSymlinks后校验范围。

Apache-2.0（LICENSE；只研究，不复制实现）

https://github.com/filebrowser/filebrowser/blob/833d908884d5c801f30f5c098d7977177eb3a36b/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S04 · ev_assisted_folder_tidy_3

https://github.com/filebrowser/filebrowser/blob/833d908884d5c801f30f5c098d7977177eb3a36b/files/scoped.go · 833d908884d5c801f30f5c098d7977177eb3a36b

code_observation: Rename分别检查旧、新路径后再委托底层Rename；目标预览及拒绝覆盖另行设计。

Apache-2.0（LICENSE；只研究，不复制实现）

https://github.com/filebrowser/filebrowser/blob/833d908884d5c801f30f5c098d7977177eb3a36b/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S05 · ev_assisted_folder_tidy_design

https://github.com/filebrowser/filebrowser/blob/833d908884d5c801f30f5c098d7977177eb3a36b/LICENSE · 833d908884d5c801f30f5c098d7977177eb3a36b

inference: 目标不开放任意用户目录，要求显式--sandbox-root，仅新建测试沙箱；预览token绑定源字节和目录身份，操作只支持单文件且拒绝覆盖和全部符号链接。宿主共享记录不是对实现安全认证。

Apache-2.0（LICENSE；只研究，不复制实现）

https://github.com/filebrowser/filebrowser/blob/833d908884d5c801f30f5c098d7977177eb3a36b/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## 待验证

- 证据独立审阅pending
- 上游not_run
- 辅助试用，非严格G1/T08；Codex研究与编写，证据独审pending，上游未运行。
- 本模板尚未开发代表应用或取得下游运行证据；验收程序仅编译检查，不能据此声称运行通过。
- 单人本机显式保存，无账户、云同步、协作；不复制上游实现。
- 安全敏感模板尚未应用运行或专项安全审阅，不建议直接操作珍贵原文件；TOCTOU/平台文件系统差异需后续实测。
- 不做删除、批量规则、外盘跨FS、压缩/上传、目录树移动或权限修改。
