# 架构与契约

## 运行边界
Python标准库HTTP+SQLite，本机127.0.0.1；--data-dir独立目录，--demo仅新库首次初始化。GET只读，所有错误JSON为{error:{code,message}}，失败零写入，未知ID404not_found。输入类型先校验；事务保存；UI文本转义，无第三方资源。
## 数据与规则
真实磁盘为真相；SQLite只存previews(token,source,target,source_sha256,source_stat,consumed,result)。启动必须传--sandbox-root，缺省则仅创建data-dir/sandbox练习目录，不枚举HOME。所有API路径只允许相对POSIX路径，不许空段、..、绝对路径或NUL；逐段lstat拒绝symlink，根目录本身也不能是链接。只移动普通文件，不批量/删文件/跟随链接。源预览后有变化=>409source_changed；目标已存在409target_exists；确认前再次验证；使用同目录临时与不覆盖原子策略，不用先删目标。token只代表本机明确确认，非认证。跨文件系统返回unsupported_move不复制删源。
## 接口
GET /api/health；GET /api/state?path= -> {entries:[{name,kind,size}],operations}；POST /api/folders {path}->201；POST /api/preview {source,target}->201{token,source_sha256,source,target}（不写文件）；POST /api/confirm {token}->200{source,target,sha256}幂等返回。400 invalid_path/symlink_forbidden/unsupported_move；404not_found；409target_exists/source_changed。GET /api/health。--data-dir存操作库，与--sandbox-root分离；练习套件使用data-dir/sandbox。
## 交互
固定根说明、面包屑列表、单文件目标输入、预览原/目标/摘要、独立确认按钮。警示只整理练习副本；不提供删除或一键全目录移动；后台限127.0.0.1并校验同源。
## 来源与推断
目标不开放任意用户目录，要求显式--sandbox-root，仅新建测试沙箱；预览token绑定源字节和目录身份，操作只支持单文件且拒绝覆盖和全部符号链接。宿主共享记录不是对实现安全认证。
