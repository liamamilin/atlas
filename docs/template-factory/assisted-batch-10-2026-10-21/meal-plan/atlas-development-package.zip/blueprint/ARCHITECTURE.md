# 架构与契约

## 数据和计算
单用户本机127.0.0.1，Python标准库HTTP+SQLite，显式HTML表单，零外部依赖。recipes(id,name,base_servings,ingredients JSON)为不可变菜谱；ingredients为[{name,unit,quantity}]，quantity为十进制正数字符串最多2位小数，单位仅g/ml/个，每名每单位在单一菜谱唯一。base_servings与计划servings为整数1–20。plans(id,date UNIQUE,recipe_id,servings,active)；每日期只有一份晚餐，重复409already_exists，即使暂停也先更新或恢复，禁止覆盖。
食材数量按整数百分之一存储；每个有效计划贡献=原数量×servings/base_servings，Decimal ROUND_HALF_UP保留2位；按trim+casefold后的名称和精确单位分组，相同单位加总，不自动换算g/kg。显示单位与数量，说明份数估算并非营养建议。暂停不删除原计划；GET不写库。
## 接口
GET /api/health；GET /api/state?start=YYYY-MM-DD&end=YYYY-MM-DD -> recipes,plans（含暂停）,shopping{items:[{name,unit,quantity_minor}],plan_count}；GET /api/shopping?start=&end= -> {items,plan_count}。范围1–7天含首尾，默认本周，旧周与新周隔离。
POST /api/recipes {name,base_servings,ingredients:[{name,unit,quantity}]} ->201{id,...}；POST /api/plans {date,recipe_id,servings}->201{id,...}；POST /api/plans/update {id,servings}->200；POST /api/plans/toggle {id}->200切换active。400 invalid_servings/invalid_quantity/invalid_ingredient/invalid_date/invalid_range/invalid_name，404not_found，409already_exists；{error:{code,message}}，失败零写入。
## 界面和启动
首页选择起止日期，显示晚餐计划、人数、修改/暂停/恢复按钮、合并采购清单和菜谱登记。食材每行“名称|单位|数量”，字段label明确，错误保留原输入，HTML全部转义。显式提交，暂停可以恢复。新增日期后跳回包含所选日期的周，不能保存成功却看不到计划。--port5277 --data-dir指向独立目录；--demo仅新库首次创建。采购数量非真实购买订单，不自动下单，不读取原应用库。
