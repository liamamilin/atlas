# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_860a53784e704b9687ddef39f51be5aa@1

把菜谱安排到一周晚餐，按用餐份数自动合并同名同单位食材，修改计划后采购量立即重算。

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_meal_plan_1

https://github.com/mealie-recipes/mealie/blob/9b66aa319d32ea5dbdf112fe6bcda60015702721/mealie/db/models/household/mealplan.py · 9b66aa319d32ea5dbdf112fe6bcda60015702721

code_observation: GroupMealPlan定义date、entry_type、recipe_id与recipe_scale，把日期餐次与菜谱及倍率连接。

AGPL-3.0根LICENSE；参考研究，不复制实现

https://github.com/mealie-recipes/mealie/blob/9b66aa319d32ea5dbdf112fe6bcda60015702721/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S03 · ev_assisted_meal_plan_2

https://github.com/mealie-recipes/mealie/blob/9b66aa319d32ea5dbdf112fe6bcda60015702721/mealie/db/models/household/shopping_list.py · 9b66aa319d32ea5dbdf112fe6bcda60015702721

code_observation: ShoppingListItemRecipeReference记录recipe_id、recipe_quantity、recipe_scale；这里只观察购物项的菜谱引用，不据此宣称已运行完整合并算法。

AGPL-3.0根LICENSE；参考研究，不复制实现

https://github.com/mealie-recipes/mealie/blob/9b66aa319d32ea5dbdf112fe6bcda60015702721/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S04 · ev_assisted_meal_plan_design

https://github.com/mealie-recipes/mealie/blob/9b66aa319d32ea5dbdf112fe6bcda60015702721/LICENSE · 9b66aa319d32ea5dbdf112fe6bcda60015702721

inference: 目标缩小为晚餐、单人本机、不可变菜谱和可暂停计划；用整数百分之一数量按份数缩放后合并同名同单位，不自动换算单位/营养或调用食谱抓取。

AGPL-3.0根LICENSE；参考研究，不复制实现

https://github.com/mealie-recipes/mealie/blob/9b66aa319d32ea5dbdf112fe6bcda60015702721/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## 待验证

- 证据独立审阅pending
- 上游not_run
- Codex静态研究和编写，证据独审pending；上游未安装运行
- 只供本机辅助试用，非严格G1/T08；不改旧应用或数据
- 仅晚餐/7天窗口；菜谱不可变，无营养建议、单位自动换算、附件、抓取、同步或采购下单
