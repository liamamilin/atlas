# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_3b74c4ea6d2345988d877e975eb0a5fa@1

把待办安排到一天的时间块，避免重叠，结束时把未完成块顺延到明天待安排区而保留来源。

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_day_blocks_1

https://github.com/super-productivity/super-productivity/blob/0556bdb84d09faeff18d6c18abf867e28f3c1f69/README.md · 0556bdb84d09faeff18d6c18abf867e28f3c1f69

documentation: README声明任务分类、planner/schedule时间轴、timeboxing、time tracking及focus能力；文档声明未代替上游运行。

MIT（LICENSE；只研究，不复制实现）

https://github.com/super-productivity/super-productivity/blob/0556bdb84d09faeff18d6c18abf867e28f3c1f69/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S03 · ev_assisted_day_blocks_design

https://github.com/super-productivity/super-productivity/blob/0556bdb84d09faeff18d6c18abf867e28f3c1f69/LICENSE · 0556bdb84d09faeff18d6c18abf867e28f3c1f69

inference: 目标把计划时间与实际工时分开，只实现当日排程、完成与未完成迁移；不从现有工时模板换名字复用。

MIT（LICENSE；只研究，不复制实现）

https://github.com/super-productivity/super-productivity/blob/0556bdb84d09faeff18d6c18abf867e28f3c1f69/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## 待验证

- 证据独立审阅pending
- 上游not_run
- 辅助试用，非严格G1/T08；Codex研究与编写，证据独审pending，上游未运行。
- 本模板尚未开发代表应用或取得下游运行证据；验收程序仅编译检查，不能据此声称运行通过。
- 单人本机显式保存，无账户、云同步、协作；不复制上游实现。
- 不接外部日历、通知、自动番茄钟或真实工时统计；顺延日如需补录先列待办，不静默绕过封存。
