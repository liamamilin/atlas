# 架构与契约

## 运行边界
Python标准库HTTP+SQLite，本机127.0.0.1；--data-dir独立目录，--demo仅新库首次初始化。GET只读，所有错误JSON为{error:{code,message}}，失败零写入，未知ID404not_found。输入类型先校验；事务保存；UI文本转义，无第三方资源。
## 数据与规则
blocks(id,title,date,start nullable,end nullable,done,origin_date)。未排期start/end均null；已排期HH:MM同日且end>start。日期有效ISO，title1..160；所有已排期块包括done的半开时间区间不得重叠。carry{date}把未完成块原ID迁到次日、清空start/end，首次保留origin_date；已完成不迁。事务内标记该source日已carry，第二次请求幂等，不移动后来次日新建项。次日已存在块不复制/覆盖。
## 接口
GET /api/health；GET /api/state?date= -> {blocks,carried:bool}；POST /api/blocks {title,date,start,end}->201；POST /api/blocks/done {id}->200切换；POST /api/blocks/schedule {id,date,start,end}->200；POST /api/carry {date}->200{moved_ids}（幂等第二次moved_ids=[]）。400 invalid_date/invalid_time/invalid_name，409overlap；顺延完成后原日期禁止新增/移入新块409day_carried，避免幂等状态歧义。
## 交互
时间轴+未安排区；完成项打勾保留原时间；顺延按钮先展示目标次日及未完数量，显式确认。未排期不能伪装为已完成工作小时。
## 来源与推断
目标把计划时间与实际工时分开，只实现当日排程、完成与未完成迁移；不从现有工时模板换名字复用。
