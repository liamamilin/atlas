import re
from datetime import UTC, date, datetime
from enum import Enum
from types import SimpleNamespace
from typing import Annotated

from pydantic import AfterValidator, BaseModel, StringConstraints, field_validator
from sqlalchemy import (JSON, Column, Index, MetaData, UniqueConstraint, event,
                        select)
from sqlalchemy.orm import Session, object_session
from sqlalchemy.types import TypeDecorator
from sqlmodel import DateTime, Field, Relationship, SQLModel

from ..config import get_settings
from ..utils.date import dt_utc
from ..utils.utils import remove_attachment, remove_backup, remove_image

convention = {
    "ix": "ix_%(column_0_label)s",
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    "ck": "ck_%(table_name)s_%(constraint_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "pk": "pk_%(table_name)s",
}

SQLModel.metadata = MetaData(naming_convention=convention)


def _naive_utc(value: datetime | None) -> datetime | None:
    return value.astimezone(UTC).replace(tzinfo=None) if value is not None and value.tzinfo else value


# SQLModel >=0.0.45 fix - Datetimes stored as naive UTC: sa_type=DateTime (override SQLModel UTCDateTime)
UTCNaive = Annotated[datetime, AfterValidator(_naive_utc)]


@event.listens_for(Session, "after_commit")
def cleanup_after_commit(session):
    if hasattr(session, "_images_to_delete"):
        for filename in session._images_to_delete:
            remove_image(filename)
        delattr(session, "_images_to_delete")

    if hasattr(session, "_attachments_to_delete"):
        for attachment in session._attachments_to_delete:
            remove_attachment(attachment.trip_id, attachment.stored_filename)
        delattr(session, "_attachments_to_delete")

    if hasattr(session, "_backups_to_delete"):
        for filename in session._backups_to_delete:
            remove_backup(filename)
        delattr(session, "_backups_to_delete")


def _prefix_assets_url(filename: str) -> str:
    base = get_settings().ASSETS_URL
    if not base.endswith("/"):
        base += "/"
    return base + filename


class TripItemStatusEnum(str, Enum):
    PENDING = "pending"
    CONFIRMED = "booked"
    CONSTRAINT = "constraint"
    OPTIONAL = "optional"


class BookingTypeEnum(str, Enum):
    flight = "flight"
    car = "car"
    hotel = "hotel"
    activity = "activity"
    train = "train"
    boat = "boat"
    generic = "generic"


class PackingListCategoryEnum(str, Enum):
    CLOTHES = "clothes"
    TOILETRIES = "toiletries"
    TECH = "tech"
    DOCUMENTS = "documents"
    OTHER = "other"


class BackupStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


class MapProvider(str, Enum):
    OPENSTREETMAP = "osm"
    GOOGLE = "google"
    PHOTON = "photon"


class AuthParams(BaseModel):
    oidc: str | None
    register_enabled: bool


class LoginRegisterModel(BaseModel):
    username: Annotated[
        str,
        StringConstraints(min_length=1, max_length=19, pattern=r"^[a-zA-Z0-9_-]+$"),
    ]
    password: str
    magicToken: str | None = None


class UpdateUserPassword(BaseModel):
    current: str
    updated: Annotated[str, StringConstraints(min_length=8)]
    code: str | None = None


class LatitudeLongitude(BaseModel):
    latitude: float
    longitude: float


class LatLng(BaseModel):
    lat: float
    lng: float


class Token(BaseModel):
    access_token: str
    refresh_token: str


class PendingTOTP(BaseModel):
    pending_code: str
    username: str


class ProviderPlaceResult(BaseModel):
    name: str | None = None
    place: str | None = None
    category: str | None = None
    lat: float | None = None
    lng: float | None = None
    price: float | None = None
    allowdog: bool | None = None
    description: str | None = None
    types: list[str] = []
    image: str | None = None
    restroom: bool | None = None
    links: list[str] | None = None


class ProviderBoundaries(BaseModel):
    northeast: LatLng
    southwest: LatLng


class RoutingQuery(BaseModel):
    coordinates: list[LatLng]
    profile: str


class RoutingResponse(BaseModel):
    distance: float | None
    duration: float | None
    coordinates: list[tuple[float, float]]


class ConfigRead(BaseModel):
    PLACE_IMAGE_SIZE: int
    TRIP_IMAGE_SIZE: int
    ATTACHMENT_MAX_SIZE: int
    BACKUP_IMPORT_MAX_ENTRY_SIZE: int
    BACKUP_IMPORT_MAX_TOTAL_SIZE: int
    KML_MAX_ENTRY_SIZE: int
    PROVIDER_IMPORT_MAX_SIZE: int
    ACCESS_TOKEN_EXPIRE_MINUTES: int
    REFRESH_TOKEN_EXPIRE_MINUTES: int
    REGISTER_ENABLE: bool
    OIDC_DISCOVERY_URL: str
    OIDC_CLIENT_ID: str
    OIDC_CLIENT_SECRET: str
    OIDC_REDIRECT_URI: str
    DEFAULT_TILE: str
    PHOTON_URL: str
    DEFAULT_CURRENCY: str
    DEFAULT_MAP_LAT: float
    DEFAULT_MAP_LNG: float


class ConfigUpdate(BaseModel):
    PLACE_IMAGE_SIZE: int | None = None
    TRIP_IMAGE_SIZE: int | None = None
    ATTACHMENT_MAX_SIZE: int | None = None
    BACKUP_IMPORT_MAX_ENTRY_SIZE: int | None = None
    BACKUP_IMPORT_MAX_TOTAL_SIZE: int | None = None
    KML_MAX_ENTRY_SIZE: int | None = None
    PROVIDER_IMPORT_MAX_SIZE: int | None = None
    ACCESS_TOKEN_EXPIRE_MINUTES: int | None = None
    REFRESH_TOKEN_EXPIRE_MINUTES: int | None = None
    REGISTER_ENABLE: bool | None = None
    OIDC_DISCOVERY_URL: str | None = None
    OIDC_CLIENT_ID: str | None = None
    OIDC_CLIENT_SECRET: str | None = None
    OIDC_REDIRECT_URI: str | None = None
    DEFAULT_TILE: str | None = None
    PHOTON_URL: str | None = None
    DEFAULT_CURRENCY: str | None = None
    DEFAULT_MAP_LAT: float | None = None
    DEFAULT_MAP_LNG: float | None = None


class TempPasswordRead(BaseModel):
    temporary: str


class MagicLinkBase(SQLModel):
    token: str = Field(index=True, unique=True)
    expires: datetime = Field(sa_type=DateTime)


class MagicLink(MagicLinkBase, table=True):
    id: int | None = Field(default=None, primary_key=True)
    user: str = Field(foreign_key="user.username", ondelete="CASCADE", index=True)


class MagicLinkRead(MagicLinkBase):
    @classmethod
    def serialize(cls, obj: MagicLink) -> "MagicLinkRead":
        return cls(token=obj.token, expires=obj.expires)


class ImageBase(SQLModel):
    filename: str
    file_size: int | None = 0


class Image(ImageBase, table=True):
    id: int | None = Field(default=None, primary_key=True)
    user: str = Field(foreign_key="user.username", ondelete="CASCADE", index=True)

    categories: list["Category"] = Relationship(back_populates="image")
    places: list["Place"] = Relationship(back_populates="image")
    trips: list["Trip"] = Relationship(back_populates="image")
    tripitems: list["TripItem"] = Relationship(back_populates="image")


class ImageRead(BaseModel):
    id: int
    url: str

    @classmethod
    def serialize(cls, obj: Image) -> "ImageRead":
        return cls(id=obj.id, url=_prefix_assets_url(obj.filename))


@event.listens_for(Image, "after_delete")
def mark_image_for_deletion(mapper, connection, target: Image):
    session = object_session(target)
    if not session:
        return
    if not hasattr(session, "_images_to_delete"):
        session._images_to_delete = []
    session._images_to_delete.append(target.filename)


class BackupBase(SQLModel):
    completed_at: datetime | None = Field(default=None, sa_type=DateTime)
    filename: str | None = None
    error_message: str | None = None
    file_size: int | None = None
    full: bool = False


class Backup(BackupBase, table=True):
    id: int | None = Field(default=None, primary_key=True)
    user: str = Field(foreign_key="user.username", ondelete="CASCADE")
    status: BackupStatus = Field(default=BackupStatus.PENDING)
    created_at: datetime = Field(default_factory=dt_utc, sa_type=DateTime)


@event.listens_for(Backup, "after_delete")
def mark_backup_for_deletion(mapper, connection, target: Backup):
    session = object_session(target)
    if not session:
        return
    if not hasattr(session, "_backups_to_delete"):
        session._backups_to_delete = []
    session._backups_to_delete.append(target.filename)


class BackupRead(BackupBase):
    id: int
    created_at: datetime
    status: BackupStatus
    user: str

    @classmethod
    def serialize(cls, obj: Backup) -> "BackupRead":
        return cls(
            id=obj.id,
            completed_at=obj.completed_at,
            created_at=obj.created_at,
            error_message=obj.error_message,
            filename=obj.filename,
            file_size=obj.file_size,
            status=obj.status,
            user=obj.user,
        )


class DataMigration(SQLModel, table=True):
    name: str = Field(primary_key=True)
    applied_at: datetime = Field(default_factory=dt_utc, sa_type=DateTime)


class UserBase(SQLModel):
    map_lat: float = get_settings().DEFAULT_MAP_LAT
    map_lng: float = get_settings().DEFAULT_MAP_LNG
    currency: str = get_settings().DEFAULT_CURRENCY
    do_not_display: str = ""
    tile_layer: str | None = None
    mode_low_network: bool | None = True
    mode_dark: bool | None = False
    mode_gpx_in_place: bool | None = False
    mode_display_visited: bool | None = False
    mode_map_position: bool | None = False
    show_dog_tag: bool | None = True
    fetch_link_titles: bool | None = False
    api_token: str | None = None
    duplicate_dist: int | None = None
    language: str | None = None


class User(UserBase, table=True):
    username: str = Field(primary_key=True)
    password: str
    totp_enabled: bool = False
    totp_secret: str | None = None
    google_apikey: str | None = None
    apprise_webhook_url: str | None = None
    map_provider: MapProvider = Field(default=MapProvider.OPENSTREETMAP)
    is_admin: bool = False


@event.listens_for(User, "before_delete")
def user_delete_assets(mapper, connection, target: User):
    session = object_session(target)

    image_filenames = (
        connection.execute(
            select(Image.__table__.c.filename).where(Image.__table__.c.user == target.username)
        )
        .scalars()
        .all()
    )
    if session and image_filenames:
        if not hasattr(session, "_images_to_delete"):
            session._images_to_delete = []
        session._images_to_delete.extend(image_filenames)

    backup_filenames = (
        connection.execute(
            select(Backup.__table__.c.filename)
            .where(Backup.__table__.c.user == target.username)
            .where(Backup.__table__.c.filename.isnot(None))
        )
        .scalars()
        .all()
    )
    if session and backup_filenames:
        if not hasattr(session, "_backups_to_delete"):
            session._backups_to_delete = []
        session._backups_to_delete.extend(backup_filenames)

    attachment_rows = connection.execute(
        select(
            TripAttachment.__table__.c.trip_id,
            TripAttachment.__table__.c.stored_filename,
        ).where(TripAttachment.__table__.c.uploaded_by == target.username)
    ).all()
    if session and attachment_rows:
        if not hasattr(session, "_attachments_to_delete"):
            session._attachments_to_delete = []
        # remove_attachment expects (trip_id, stored_filename) so we SimpleNamespace to fake
        session._attachments_to_delete.extend(
            SimpleNamespace(trip_id=attachment.trip_id, stored_filename=attachment.stored_filename)
            for attachment in attachment_rows
        )


class UserUpdate(UserBase):
    map_lat: float | None = None
    map_lng: float | None = None
    currency: str | None = None
    do_not_display: list[str] | None = None
    google_apikey: str | None = None
    apprise_webhook_url: str | None = None
    map_provider: MapProvider | None = None


class UserRead(UserBase):
    username: str
    do_not_display: list[str]
    totp_enabled: bool
    google_apikey: bool
    apprise_webhook_url: bool
    api_token: bool
    map_provider: str
    is_admin: bool

    @classmethod
    def serialize(cls, obj: User) -> "UserRead":
        return cls(
            username=obj.username,
            map_lat=obj.map_lat,
            map_lng=obj.map_lng,
            currency=obj.currency,
            do_not_display=obj.do_not_display.split(",") if obj.do_not_display else [],
            tile_layer=obj.tile_layer if obj.tile_layer else get_settings().DEFAULT_TILE,
            mode_low_network=obj.mode_low_network,
            mode_dark=obj.mode_dark,
            mode_gpx_in_place=obj.mode_gpx_in_place,
            mode_display_visited=obj.mode_display_visited,
            mode_map_position=obj.mode_map_position,
            show_dog_tag=obj.show_dog_tag,
            fetch_link_titles=obj.fetch_link_titles,
            totp_enabled=obj.totp_enabled,
            google_apikey=True if obj.google_apikey else False,
            apprise_webhook_url=True if obj.apprise_webhook_url else False,
            api_token=True if obj.api_token else False,
            map_provider=obj.map_provider.value,
            duplicate_dist=obj.duplicate_dist,
            is_admin=obj.is_admin if obj.is_admin else False,
            language=obj.language if obj.language else "en",
        )


class AdminUserRead(UserBase):
    username: str
    quota_bytes: int
    quota_places: int
    totp_enabled: bool
    google_apikey: bool
    api_token: bool
    is_admin: bool

    @classmethod
    def serialize(cls, obj: User, places_count: int = 0, storage_bytes: int = 0) -> "AdminUserRead":
        return cls(
            username=obj.username,
            totp_enabled=obj.totp_enabled,
            quota_bytes=storage_bytes,
            quota_places=places_count,
            google_apikey=True if obj.google_apikey else False,
            api_token=True if obj.api_token else False,
            is_admin=obj.is_admin if obj.is_admin else False,
        )


class CategoryBase(SQLModel):
    name: str
    color: str | None = None


class Category(CategoryBase, table=True):
    id: int | None = Field(default=None, primary_key=True)
    image_id: int | None = Field(default=None, foreign_key="image.id", ondelete="CASCADE")
    image: Image | None = Relationship(back_populates="categories")
    places: list["Place"] = Relationship(back_populates="category", cascade_delete=True)
    user: str = Field(foreign_key="user.username", ondelete="CASCADE", index=True)


class CategoryCreate(CategoryBase):
    name: str
    image: str | None = None
    color: str | None = None


class CategoryUpdate(CategoryBase):
    name: str | None = None
    image: str | None = None
    color: str | None = None


class CategoryRead(CategoryBase):
    id: int
    image: str | None
    image_id: int | None
    color: str

    @classmethod
    def serialize(cls, obj: Category) -> "CategoryRead":
        return cls(
            id=obj.id,
            name=obj.name,
            image_id=obj.image_id,
            image=_prefix_assets_url(obj.image.filename) if obj.image else "/favicon.png",
            color=obj.color if obj.color else "#000000",
        )


class TripPlaceLink(SQLModel, table=True):
    trip_id: int = Field(foreign_key="trip.id", primary_key=True, ondelete="CASCADE")
    place_id: int = Field(foreign_key="place.id", primary_key=True, index=True, ondelete="CASCADE")


class LinkItem(BaseModel):
    url: str
    title: str | None = None


class LinksJSON(TypeDecorator):
    impl = JSON
    cache_ok = True

    def process_bind_param(self, value, dialect):
        if value is None:
            return None
        return [v.model_dump(exclude_none=True) if isinstance(v, BaseModel) else v for v in value]


class PlaceBase(SQLModel):
    name: str
    lat: float
    lng: float
    place: str
    allowdog: bool | None = None
    description: str | None = None
    price: float | None = None
    duration: int | None = None
    favorite: bool | None = None
    visited: bool | None = None
    gpx: str | None = None
    restroom: bool | None = None
    links: list[str] | None = None


class Place(PlaceBase, table=True):
    id: int | None = Field(default=None, primary_key=True)
    cdate: date = Field(default_factory=lambda: datetime.now(UTC))
    user: str = Field(foreign_key="user.username", ondelete="CASCADE", index=True)
    links: list[str | LinkItem] | None = Field(default=None, sa_column=Column(LinksJSON))

    image_id: int | None = Field(default=None, foreign_key="image.id", ondelete="CASCADE")
    image: Image | None = Relationship(back_populates="places")

    category_id: int = Field(foreign_key="category.id", index=True, ondelete="CASCADE")
    category: Category | None = Relationship(back_populates="places")

    trip_items: list["TripItem"] = Relationship(back_populates="place")

    trips: list["Trip"] = Relationship(back_populates="places", link_model=TripPlaceLink)

    __table_args__ = (Index("idx_place_user_category", "user", "category_id"),)


class PlaceCreate(PlaceBase):
    image: str | None = None
    category_id: int


class PlaceUpdate(PlaceBase):
    name: str | None = None
    lat: float | None = None
    lng: float | None = None
    place: str | None = None
    category_id: int | None = None
    image: str | None = None


class PlaceRead(PlaceBase):
    id: int
    category: CategoryRead
    image: str | None
    image_id: int | None
    user: str
    trip_count: int = 0
    links: list[str | LinkItem] | None = None

    @classmethod
    def serialize(cls, obj: Place, exclude_gpx=True) -> "PlaceRead":
        return cls(
            id=obj.id,
            user=obj.user,
            name=obj.name,
            lat=obj.lat,
            lng=obj.lng,
            place=obj.place,
            category=CategoryRead.serialize(obj.category),
            allowdog=obj.allowdog,
            description=obj.description,
            price=obj.price,
            duration=obj.duration,
            visited=obj.visited,
            image=_prefix_assets_url(obj.image.filename) if obj.image else None,
            image_id=obj.image_id,
            favorite=obj.favorite,
            gpx=("1" if obj.gpx else None)
            if exclude_gpx
            else obj.gpx,  # Generic PlaceRead. Avoid large resp.
            restroom=obj.restroom,
            links=obj.links,
            trip_count=len(obj.trips),
        )


class TripBase(SQLModel):
    name: str
    archived: bool | None = None
    currency: str | None = get_settings().DEFAULT_CURRENCY
    notes: str | None = None
    archival_review: str | None = None


class Trip(TripBase, table=True):
    id: int | None = Field(default=None, primary_key=True)
    user: str = Field(foreign_key="user.username", ondelete="CASCADE", index=True)
    image_id: int | None = Field(default=None, foreign_key="image.id", ondelete="CASCADE")
    ics_token: str | None = Field(default=None, index=True, unique=True)

    image: Image | None = Relationship(back_populates="trips")
    places: list["Place"] = Relationship(
        back_populates="trips",
        sa_relationship_kwargs={"order_by": "Place.name"},
        link_model=TripPlaceLink,
    )
    days: list["TripDay"] = Relationship(
        back_populates="trip",
        sa_relationship_kwargs={"order_by": lambda: [TripDay.dt.asc().nulls_last(), TripDay.label]},
        cascade_delete=True,
    )
    shares: list["TripShare"] = Relationship(back_populates="trip", cascade_delete=True)
    packing_items: list["TripPackingListItem"] = Relationship(back_populates="trip", cascade_delete=True)
    checklist_items: list["TripChecklistItem"] = Relationship(back_populates="trip", cascade_delete=True)
    packing_lists: list["TripPackingList"] = Relationship(back_populates="trip", cascade_delete=True)
    checklists: list["TripChecklist"] = Relationship(back_populates="trip", cascade_delete=True)
    memberships: list["TripMember"] = Relationship(back_populates="trip", cascade_delete=True)
    attachments: list["TripAttachment"] = Relationship(back_populates="trip", cascade_delete=True)


class TripCreate(TripBase):
    image: str | None = None
    place_ids: list[int] = []


class TripUpdate(TripBase):
    name: str | None = None
    image: str | None = None
    place_ids: list[int] = []


class TripReadBase(TripBase):
    id: int
    image: str | None
    image_id: int | None
    days: int
    collaborators: list["TripMemberRead"]

    @classmethod
    def serialize(cls, obj: Trip) -> "TripRead":
        return cls(
            id=obj.id,
            name=obj.name,
            archived=obj.archived,
            image=_prefix_assets_url(obj.image.filename) if obj.image else None,
            image_id=obj.image_id,
            days=len(obj.days),
            collaborators=[TripMemberRead.serialize(m) for m in obj.memberships],
            currency=obj.currency if obj.currency else get_settings().DEFAULT_CURRENCY,
        )


class TripRead(TripBase):
    id: int
    image: str | None
    image_id: int | None
    days: list["TripDayRead"]
    places: list["PlaceRead"]
    collaborators: list["TripMemberRead"]
    shared: bool
    attachments: list["TripAttachmentRead"]

    @classmethod
    def serialize(cls, obj: Trip) -> "TripRead":
        return cls(
            id=obj.id,
            name=obj.name,
            archived=obj.archived,
            image=_prefix_assets_url(obj.image.filename) if obj.image else None,
            image_id=obj.image_id,
            days=[TripDayRead.serialize(day) for day in obj.days],
            places=[PlaceRead.serialize(place) for place in obj.places],
            collaborators=[TripMemberRead.serialize(m) for m in obj.memberships],
            shared=bool(obj.shares),
            currency=obj.currency if obj.currency else get_settings().DEFAULT_CURRENCY,
            notes=obj.notes,
            archival_review=obj.archival_review,
            attachments=[TripAttachmentRead.serialize(att) for att in obj.attachments],
        )


class TripMember(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    user: str = Field(foreign_key="user.username", ondelete="CASCADE")
    invited_by: str | None = Field(default=None, foreign_key="user.username", ondelete="SET NULL")
    invited_at: datetime = Field(default_factory=dt_utc, sa_type=DateTime)
    joined_at: datetime | None = Field(default=None, sa_type=DateTime)

    trip_id: int = Field(foreign_key="trip.id", ondelete="CASCADE", index=True)
    trip: Trip | None = Relationship(back_populates="memberships")

    __table_args__ = (
        Index("idx_tripmember_trip_user_joined", "trip_id", "user", "joined_at"),
        UniqueConstraint("trip_id", "user", name="uq_tripmember_trip_user"),
    )


class TripMemberCreate(BaseModel):
    user: str


class TripMemberRead(BaseModel):
    user: str
    invited_by: str | None = None
    invited_at: datetime | None = None
    joined_at: datetime | None = None

    @classmethod
    def serialize(cls, obj: TripMember) -> "TripMemberRead":
        return cls(
            user=obj.user,
            invited_by=obj.invited_by,
            invited_at=obj.invited_at,
            joined_at=obj.joined_at,
        )


class TripInvitationRead(TripReadBase):
    invited_by: str | None = None
    invited_at: datetime


class TripDayBase(SQLModel):
    label: str
    dt: date | None = None
    notes: str | None = None


class TripDay(TripDayBase, table=True):
    id: int | None = Field(default=None, primary_key=True)

    trip_id: int = Field(foreign_key="trip.id", ondelete="CASCADE", index=True)
    trip: Trip | None = Relationship(back_populates="days")

    items: list["TripItem"] = Relationship(
        back_populates="day",
        sa_relationship_kwargs={"order_by": "TripItem.time"},
        cascade_delete=True,
    )
    bookings: list["TripBooking"] = Relationship(back_populates="day", cascade_delete=True)


class TripBookingAttachmentLink(SQLModel, table=True):
    booking_id: int = Field(foreign_key="tripbooking.id", ondelete="CASCADE", primary_key=True, index=True)
    attachment_id: int = Field(foreign_key="tripattachment.id", ondelete="CASCADE", primary_key=True)


class TripBookingBase(SQLModel):
    type: BookingTypeEnum = BookingTypeEnum.generic
    label: str
    reference: str | None = None
    notes: str | None = None


class TripBooking(TripBookingBase, table=True):
    id: int | None = Field(default=None, primary_key=True)
    day_id: int = Field(foreign_key="tripday.id", ondelete="CASCADE", index=True)
    trip_id: int = Field(foreign_key="trip.id", ondelete="CASCADE", index=True)
    day: TripDay | None = Relationship(back_populates="bookings")

    attachments: list["TripAttachment"] = Relationship(
        back_populates="bookings", link_model=TripBookingAttachmentLink
    )


class TripBookingCreate(TripBookingBase):
    attachment_ids: list[int] = []


class TripBookingUpdate(TripBookingBase):
    day_id: int | None = None
    attachment_ids: list[int] = []


class TripBookingRead(TripBookingBase):
    id: int
    day_id: int
    attachments: list["TripAttachmentRead"]

    @classmethod
    def serialize(cls, obj: TripBooking) -> "TripBookingRead":
        return cls(
            id=obj.id,
            type=obj.type,
            label=obj.label,
            reference=obj.reference,
            notes=obj.notes,
            day_id=obj.day_id,
            attachments=[TripAttachmentRead.serialize(att) for att in obj.attachments],
        )


class TripShareBookingRead(TripBookingBase):
    id: int


class TripDayRead(TripDayBase):
    id: int
    items: list["TripItemRead"]
    bookings: list[TripBookingRead]

    @classmethod
    def serialize(cls, obj: TripDay) -> "TripDayRead":
        return cls(
            id=obj.id,
            dt=obj.dt,
            label=obj.label,
            items=[TripItemRead.serialize(item) for item in obj.items],
            bookings=[TripBookingRead.serialize(b) for b in obj.bookings],
            notes=obj.notes,
        )


class TripItemAttachmentLink(SQLModel, table=True):
    item_id: int = Field(foreign_key="tripitem.id", ondelete="CASCADE", primary_key=True, index=True)
    attachment_id: int = Field(foreign_key="tripattachment.id", ondelete="CASCADE", primary_key=True)


class TripItemImageLink(SQLModel, table=True):
    item_id: int = Field(foreign_key="tripitem.id", ondelete="CASCADE", primary_key=True, index=True)
    image_id: int = Field(foreign_key="image.id", ondelete="CASCADE", primary_key=True)


class TripItemBase(SQLModel):
    time: (
        Annotated[
            str,
            StringConstraints(min_length=2, max_length=5, pattern=r"^([01]\d|2[0-3])(:[0-5]\d)?$"),
        ]
        | None
    ) = None
    text: str
    comment: str | None = None
    lat: float | None = None
    price: float | None = None
    lng: float | None = None
    status: TripItemStatusEnum | None = None
    gpx: str | None = None
    links: list[str] | None = None

    @field_validator("time", mode="before")
    def pad_mm_if_needed(cls, value: str | None) -> str | None:
        if value is None:
            return value
        if re.fullmatch(r"^([01]\d|2[0-3])$", value):  # If it's just HH
            return f"{value}:00"
        return value


class TripItem(TripItemBase, table=True):
    id: int | None = Field(default=None, primary_key=True)
    links: list[str | LinkItem] | None = Field(default=None, sa_column=Column(LinksJSON))

    place_id: int | None = Field(default=None, foreign_key="place.id", ondelete="SET NULL")
    place: Place | None = Relationship(back_populates="trip_items")

    image_id: int | None = Field(default=None, foreign_key="image.id", ondelete="CASCADE")
    image: Image | None = Relationship(back_populates="tripitems")

    day_id: int = Field(foreign_key="tripday.id", ondelete="CASCADE", index=True)
    day: TripDay | None = Relationship(back_populates="items")

    paid_by: str | None = Field(default=None, foreign_key="user.username", ondelete="SET NULL")

    attachments: list["TripAttachment"] = Relationship(
        back_populates="items", link_model=TripItemAttachmentLink
    )

    images: list["Image"] = Relationship(link_model=TripItemImageLink)


class ItemImageInput(BaseModel):
    id: int | None = None
    data: str | None = None


class TripItemCreate(TripItemBase):
    place: int | None = None
    status: TripItemStatusEnum | None = None
    images: list[ItemImageInput] = []
    cover_index: int | None = None
    paid_by: str | None = None
    attachment_ids: list[int] = []


class TripItemUpdate(TripItemBase):
    time: str | None = None
    text: str | None = None
    place: int | None = None
    day_id: int | None = None
    status: TripItemStatusEnum | None = None
    images: list[ItemImageInput] | None = None
    cover_index: int | None = None
    paid_by: str | None = None
    attachment_ids: list[int] = []


class TripItemRead(TripItemBase):
    id: int
    place: PlaceRead | None
    day_id: int
    status: TripItemStatusEnum | None
    image: str | None
    image_id: int | None
    images: list[ImageRead]
    paid_by: str | None
    attachments: list["TripAttachmentRead"]
    links: list[str | LinkItem] | None = None

    @classmethod
    def serialize(cls, obj: TripItem) -> "TripItemRead":
        return cls(
            id=obj.id,
            time=obj.time,
            text=obj.text,
            comment=obj.comment,
            lat=obj.lat,
            lng=obj.lng,
            price=obj.price,
            day_id=obj.day_id,
            status=obj.status,
            place=PlaceRead.serialize(obj.place) if obj.place else None,
            image=_prefix_assets_url(obj.image.filename) if obj.image else None,
            image_id=obj.image_id,
            images=[ImageRead.serialize(img) for img in obj.images],
            gpx=obj.gpx,
            paid_by=obj.paid_by,
            links=obj.links,
            attachments=[TripAttachmentRead.serialize(att) for att in obj.attachments],
        )


class TripBalanceEntry(BaseModel):
    balance: float
    paid: float


class TripShareDetails(BaseModel):
    url: str
    is_full_access: bool | None


class TripShareCreate(BaseModel):
    is_full_access: bool | None


class TripCalendarDetails(BaseModel):
    url: str


class TripShare(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True)
    token: str = Field(index=True, unique=True)
    is_full_access: bool | None = None

    trip_id: int = Field(foreign_key="trip.id", ondelete="CASCADE")
    trip: Trip | None = Relationship(back_populates="shares")


class TripShareItemRead(TripItemBase):
    id: int
    place: PlaceRead | None
    day_id: int
    status: TripItemStatusEnum | None
    image: str | None
    image_id: int | None
    paid_by: str | None
    links: list[str | LinkItem] | None = None

    @classmethod
    def serialize(cls, obj: TripItem) -> "TripShareItemRead":
        return cls(
            id=obj.id,
            time=obj.time,
            text=obj.text,
            comment=obj.comment,
            lat=obj.lat,
            lng=obj.lng,
            price=obj.price,
            day_id=obj.day_id,
            status=obj.status,
            place=PlaceRead.serialize(obj.place) if obj.place else None,
            image=None,
            image_id=None,
            gpx=obj.gpx,
            paid_by=None,
            links=obj.links,
        )


class TripShareDayRead(TripDayBase):
    id: int
    items: list["TripShareItemRead"]
    bookings: list[TripShareBookingRead]

    @classmethod
    def serialize(cls, obj: TripDay) -> "TripShareDayRead":
        return cls(
            id=obj.id,
            dt=obj.dt,
            label=obj.label,
            items=[TripShareItemRead.serialize(item) for item in obj.items],
            bookings=[TripShareBookingRead.model_validate(b) for b in obj.bookings],
            notes=obj.notes,
        )


class TripShareRead(TripBase):
    id: int
    image: str | None
    image_id: int | None
    days: list["TripShareDayRead"]
    places: list["PlaceRead"]

    @classmethod
    def serialize(cls, obj: Trip) -> "TripShareRead":
        return cls(
            id=obj.id,
            name=obj.name,
            archived=obj.archived,
            image=_prefix_assets_url(obj.image.filename) if obj.image else None,
            image_id=obj.image_id,
            days=[TripShareDayRead.serialize(day) for day in obj.days],
            places=[PlaceRead.serialize(place) for place in obj.places],
            currency=obj.currency if obj.currency else get_settings().DEFAULT_CURRENCY,
        )


class TripPackingListItemBase(SQLModel):
    text: str | None = None
    qt: int | None = None
    category: PackingListCategoryEnum | None = None
    packed: bool | None = None


class TripPackingListItem(TripPackingListItemBase, table=True):
    id: int | None = Field(default=None, primary_key=True)

    trip_id: int = Field(foreign_key="trip.id", ondelete="CASCADE", index=True)
    trip: Trip | None = Relationship(back_populates="packing_items")


class TripPackingListItemCreate(TripPackingListItemBase):
    text: str
    category: PackingListCategoryEnum
    packed: bool = False

    @field_validator("text", mode="before")
    @classmethod
    def text_must_not_be_blank(cls, value):
        if value is None or not str(value).strip():
            raise ValueError("text must not be empty")
        return value


class TripPackingListItemUpdate(TripPackingListItemBase):
    @field_validator("text", "category", mode="before")
    @classmethod
    def reject_null(cls, value):
        if value is None:
            raise ValueError("must not be null")
        return value

    @field_validator("text")
    @classmethod
    def text_must_not_be_blank(cls, value):
        if value is not None and not value.strip():
            raise ValueError("text must not be empty")
        return value


class TripPackingListItemRead(TripPackingListItemBase):
    id: int

    @classmethod
    def serialize(cls, obj: "TripPackingListItem") -> "TripPackingListItemRead":
        return cls(
            id=obj.id,
            text=obj.text,
            qt=obj.qt,
            category=obj.category,
            packed=obj.packed,
        )


class TripChecklistItemBase(SQLModel):
    text: str | None = None
    checked: bool | None = None
    notify_dt: UTCNaive | None = Field(default=None, sa_type=DateTime)


class TripChecklistItem(TripChecklistItemBase, table=True):
    id: int | None = Field(default=None, primary_key=True)

    trip_id: int = Field(foreign_key="trip.id", ondelete="CASCADE", index=True)
    trip: Trip | None = Relationship(back_populates="checklist_items")


class TripChecklistItemCreate(TripChecklistItemBase):
    text: str
    checked: bool = False

    @field_validator("text", mode="before")
    @classmethod
    def text_must_not_be_blank(cls, value):
        if value is None or not str(value).strip():
            raise ValueError("text must not be empty")
        return value


class TripChecklistItemUpdate(TripChecklistItemBase):
    @field_validator("text", mode="before")
    @classmethod
    def reject_null(cls, value):
        if value is None:
            raise ValueError("must not be null")
        return value

    @field_validator("text")
    @classmethod
    def text_must_not_be_blank(cls, value):
        if value is not None and not value.strip():
            raise ValueError("text must not be empty")
        return value


class TripChecklistItemRead(TripChecklistItemBase):
    id: int

    @classmethod
    def serialize(cls, obj: "TripChecklistItem") -> "TripChecklistItemRead":
        return cls(
            id=obj.id,
            text=obj.text,
            checked=obj.checked,
            notify_dt=obj.notify_dt,
        )


class TripPackingListEntryBase(SQLModel):
    text: str | None = None
    qt: int | None = None
    category: PackingListCategoryEnum | None = None
    packed: bool | None = None


class TripPackingListEntry(TripPackingListEntryBase, table=True):
    id: int | None = Field(default=None, primary_key=True)

    packing_list_id: int = Field(foreign_key="trippackinglist.id", ondelete="CASCADE", index=True)
    packing_list: "TripPackingList" = Relationship(back_populates="items")


class TripPackingListEntryCreate(TripPackingListEntryBase):
    text: str
    category: PackingListCategoryEnum
    packed: bool = False

    @field_validator("text", mode="before")
    @classmethod
    def text_must_not_be_blank(cls, value):
        if value is None or not str(value).strip():
            raise ValueError("text must not be empty")
        return value


class TripPackingListEntryUpdate(TripPackingListEntryBase):
    @field_validator("text", "category", mode="before")
    @classmethod
    def reject_null(cls, value):
        if value is None:
            raise ValueError("must not be null")
        return value

    @field_validator("text")
    @classmethod
    def text_must_not_be_blank(cls, value):
        if value is not None and not value.strip():
            raise ValueError("text must not be empty")
        return value


class TripPackingListEntryRead(TripPackingListEntryBase):
    id: int

    @classmethod
    def serialize(cls, obj: "TripPackingListEntry") -> "TripPackingListEntryRead":
        return cls(
            id=obj.id,
            text=obj.text,
            qt=obj.qt,
            category=obj.category,
            packed=obj.packed,
        )


class TripPackingListBase(SQLModel):
    name: str | None = None


class TripPackingList(TripPackingListBase, table=True):
    id: int | None = Field(default=None, primary_key=True)

    trip_id: int = Field(foreign_key="trip.id", ondelete="CASCADE", index=True)
    trip: Trip | None = Relationship(back_populates="packing_lists")
    items: list[TripPackingListEntry] = Relationship(back_populates="packing_list", cascade_delete=True)


class TripPackingListCreate(TripPackingListBase):
    name: str

    @field_validator("name", mode="before")
    @classmethod
    def name_must_not_be_blank(cls, value):
        if value is None or not str(value).strip():
            raise ValueError("name must not be empty")
        return value


class TripPackingListUpdate(TripPackingListBase):
    name: str

    @field_validator("name", mode="before")
    @classmethod
    def name_must_not_be_blank(cls, value):
        if value is None or not str(value).strip():
            raise ValueError("name must not be empty")
        return value


class TripPackingListRead(TripPackingListBase):
    id: int
    name: str
    items: list[TripPackingListEntryRead]

    @classmethod
    def serialize(cls, obj: "TripPackingList") -> "TripPackingListRead":
        return cls(
            id=obj.id,
            name=obj.name,
            items=[TripPackingListEntryRead.serialize(i) for i in obj.items],
        )


class TripChecklistEntryBase(SQLModel):
    text: str | None = None
    checked: bool | None = None
    notify_dt: UTCNaive | None = Field(default=None, sa_type=DateTime)


class TripChecklistEntry(TripChecklistEntryBase, table=True):
    id: int | None = Field(default=None, primary_key=True)

    checklist_id: int = Field(foreign_key="tripchecklist.id", ondelete="CASCADE", index=True)
    checklist: "TripChecklist" = Relationship(back_populates="items")


class TripChecklistEntryCreate(TripChecklistEntryBase):
    text: str
    checked: bool = False

    @field_validator("text", mode="before")
    @classmethod
    def text_must_not_be_blank(cls, value):
        if value is None or not str(value).strip():
            raise ValueError("text must not be empty")
        return value


class TripChecklistEntryUpdate(TripChecklistEntryBase):
    @field_validator("text", mode="before")
    @classmethod
    def reject_null(cls, value):
        if value is None:
            raise ValueError("must not be null")
        return value

    @field_validator("text")
    @classmethod
    def text_must_not_be_blank(cls, value):
        if value is not None and not value.strip():
            raise ValueError("text must not be empty")
        return value


class TripChecklistEntryRead(TripChecklistEntryBase):
    id: int

    @classmethod
    def serialize(cls, obj: "TripChecklistEntry") -> "TripChecklistEntryRead":
        return cls(
            id=obj.id,
            text=obj.text,
            checked=obj.checked,
            notify_dt=obj.notify_dt,
        )


class TripChecklistBase(SQLModel):
    name: str | None = None


class TripChecklist(TripChecklistBase, table=True):
    id: int | None = Field(default=None, primary_key=True)

    trip_id: int = Field(foreign_key="trip.id", ondelete="CASCADE", index=True)
    trip: Trip | None = Relationship(back_populates="checklists")
    items: list[TripChecklistEntry] = Relationship(back_populates="checklist", cascade_delete=True)


class TripChecklistCreate(TripChecklistBase):
    name: str

    @field_validator("name", mode="before")
    @classmethod
    def name_must_not_be_blank(cls, value):
        if value is None or not str(value).strip():
            raise ValueError("name must not be empty")
        return value


class TripChecklistUpdate(TripChecklistBase):
    name: str

    @field_validator("name", mode="before")
    @classmethod
    def name_must_not_be_blank(cls, value):
        if value is None or not str(value).strip():
            raise ValueError("name must not be empty")
        return value


class TripChecklistRead(TripChecklistBase):
    id: int
    name: str
    items: list[TripChecklistEntryRead]

    @classmethod
    def serialize(cls, obj: "TripChecklist") -> "TripChecklistRead":
        return cls(
            id=obj.id,
            name=obj.name,
            items=[TripChecklistEntryRead.serialize(i) for i in obj.items],
        )


class NotificationChecklistItemRead(BaseModel):
    id: int
    text: str
    notify_dt: datetime
    trip_id: int
    trip_name: str
    list_id: int | None = None
    list_name: str | None = None


class TripAttachmentBase(SQLModel):
    filename: str
    file_size: int
    stored_filename: str


class TripAttachment(TripAttachmentBase, table=True):
    id: int | None = Field(default=None, primary_key=True)
    uploaded_at: datetime = Field(default_factory=dt_utc, sa_type=DateTime)
    uploaded_by: str = Field(foreign_key="user.username", ondelete="CASCADE")

    trip_id: int = Field(foreign_key="trip.id", ondelete="CASCADE", index=True)
    trip: Trip | None = Relationship(back_populates="attachments")

    items: list["TripItem"] = Relationship(back_populates="attachments", link_model=TripItemAttachmentLink)
    bookings: list["TripBooking"] = Relationship(
        back_populates="attachments", link_model=TripBookingAttachmentLink
    )


@event.listens_for(TripAttachment, "after_delete")
def mark_attachment_for_deletion(mapper, connection, target: TripAttachment):
    session = object_session(target)
    if not session:
        return
    if not hasattr(session, "_attachments_to_delete"):
        session._attachments_to_delete = []
    session._attachments_to_delete.append(target)


class TripAttachmentCreate(TripAttachmentBase): ...


class TripAttachmentRead(TripAttachmentBase):
    id: int
    uploaded_by: str

    @classmethod
    def serialize(cls, obj: TripAttachment) -> "TripAttachmentRead":
        return cls(
            id=obj.id,
            filename=obj.filename,
            file_size=obj.file_size,
            uploaded_by=obj.uploaded_by,
            stored_filename=obj.stored_filename,
        )
