# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_16afaedcefee4dd9b8e8931e3a29fd65@1

把地点安排进两天行程，调整参观顺序并标记已到访，离线回查地址和安排。

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_weekend_trip_1

https://github.com/itskovacs/trip/blob/856b1edfe81a735fce4b544c2e16a6518cebf164/backend/trip/models/models.py · 856b1edfe81a735fce4b544c2e16a6518cebf164

code_observation: TripPlaceLink连接旅行和地点；PlaceBase包含名称、坐标、描述和visited标志。

MIT（license.txt；只研究，不复制实现）

https://github.com/itskovacs/trip/blob/856b1edfe81a735fce4b544c2e16a6518cebf164/license.txt

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S03 · ev_assisted_weekend_trip_2

https://github.com/itskovacs/trip/blob/856b1edfe81a735fce4b544c2e16a6518cebf164/backend/trip/models/models.py · 856b1edfe81a735fce4b544c2e16a6518cebf164

code_observation: Trip拥有days关系，按日期和标签排序；目标日内的手动排序属于设计推断。

MIT（license.txt；只研究，不复制实现）

https://github.com/itskovacs/trip/blob/856b1edfe81a735fce4b544c2e16a6518cebf164/license.txt

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S04 · ev_assisted_weekend_trip_design

https://github.com/itskovacs/trip/blob/856b1edfe81a735fce4b544c2e16a6518cebf164/LICENSE · 856b1edfe81a735fce4b544c2e16a6518cebf164

inference: 只借鉴行程/地点/天的关系；目标手工地址文本与日内顺序，不接地图、导航、实时交通或预订。

MIT（license.txt；只研究，不复制实现）

https://github.com/itskovacs/trip/blob/856b1edfe81a735fce4b544c2e16a6518cebf164/license.txt

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## 待验证

- 证据独立审阅pending
- 上游not_run
- 辅助试用，非严格G1/T08；Codex研究与编写，证据独审pending，上游未运行。
- 本模板尚未开发代表应用或取得下游运行证据；验收程序仅编译检查，不能据此声称运行通过。
- 单人本机显式保存，无账户、云同步、协作；不复制上游实现。
- 无地图、路线最优解、天气、订票或远程协作，地址正确性由人确认。
