# 架构与契约

## 运行边界
Python标准库HTTP+SQLite，本机127.0.0.1；--data-dir独立目录，--demo仅新库首次初始化。GET只读，所有错误JSON为{error:{code,message}}，失败零写入，未知ID404not_found。输入类型先校验；事务保存；UI文本转义，无第三方资源。
## 数据与规则
trips(id,title,start_date)，stops(id,trip_id,day,position,name,address,notes,visited)。day只1或2；position连续0基，插入末尾。move以新position在事务内重排该天，未知/越界拒绝。trip首日严格ISO有效日期；name/title1..120，address1..300，notes0..2000。
## 接口
GET /api/health；GET /api/state -> {trips,stops}；GET /api/stops?trip_id=&day= -> {stops}按position排序；POST /api/trips {title,start_date}->201；POST /api/stops {trip_id,day,name,address,notes}->201；POST /api/stops/move {id,position}->200；POST /api/stops/visit {id}->200切换visited。400 invalid_day/invalid_position/invalid_date/invalid_name。
## 交互
行程切换、第一天/第二天标签、地点地址及上下移按钮、已到访开关。边界按钮禁用但服务仍校验；无坐标也可完成计划。
## 来源与推断
只借鉴行程/地点/天的关系；目标手工地址文本与日内顺序，不接地图、导航、实时交通或预订。
