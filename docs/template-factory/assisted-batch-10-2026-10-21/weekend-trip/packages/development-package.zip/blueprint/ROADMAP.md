# 阶段与验收

## P0 · 核心可用

把地点安排进两天行程，调整参观顺序并标记已到访，离线回查地址和安排。

| 用例 | 类型 | 行为 | 执行器 |
| --- | --- | --- | --- |
| A01 | positive | 创建2026-11-07开始的行程，day1添加博物馆和公园，day2添加咖啡馆。 | acceptance/probe.py |
| A02 | positive | 将公园移动到博物馆之前后，重读顺序一致，另一日不变。 | acceptance/probe.py |
| A03 | positive | 到访后可撤销；day3、越界移动、空地址拒绝且旧顺序不变。 | acceptance/probe.py |
| A04 | positive | 重启保留行程日期、地点地址、日内顺序和到访状态。 | acceptance/probe.py |
