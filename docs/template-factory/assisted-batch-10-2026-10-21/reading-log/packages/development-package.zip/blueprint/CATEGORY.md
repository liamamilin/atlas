# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_bb19507a62c84135bfb9d07d8c89283b@1

用书架管理待读书，记录已读页数，完成后进入已读列表并能按标题或作者找回。

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_reading_log_1

https://github.com/janeczku/calibre-web/blob/6e840acbda8d62fdd159bf3855c01872d629a914/cps/ub.py · 6e840acbda8d62fdd159bf3855c01872d629a914

code_observation: Shelf保存名称、所属用户及书籍关系；BookShelf保存book_id、order和shelf，支撑独立书架与成员关系。

GPL-3.0（根LICENSE；只研究，不复制实现）

https://github.com/janeczku/calibre-web/blob/6e840acbda8d62fdd159bf3855c01872d629a914/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S03 · ev_assisted_reading_log_2

https://github.com/janeczku/calibre-web/blob/6e840acbda8d62fdd159bf3855c01872d629a914/cps/ub.py · 6e840acbda8d62fdd159bf3855c01872d629a914

code_observation: ReadBook分别定义未读、完成和进行中状态，并关联book_id与user_id；不是本模板页数算法的运行证据。

GPL-3.0（根LICENSE；只研究，不复制实现）

https://github.com/janeczku/calibre-web/blob/6e840acbda8d62fdd159bf3855c01872d629a914/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S04 · ev_assisted_reading_log_design

https://github.com/janeczku/calibre-web/blob/6e840acbda8d62fdd159bf3855c01872d629a914/LICENSE · 6e840acbda8d62fdd159bf3855c01872d629a914

inference: 目标独立实现纸书/电子书元数据目录；每书只放一个书架，页数驱动状态；不搭建Calibre内容服务器或电子书阅读器。

GPL-3.0（根LICENSE；只研究，不复制实现）

https://github.com/janeczku/calibre-web/blob/6e840acbda8d62fdd159bf3855c01872d629a914/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## 待验证

- 证据独立审阅pending
- 上游not_run
- 辅助试用，非严格G1/T08；Codex研究与编写，证据独审pending，上游未运行。
- 本模板尚未开发代表应用或取得下游运行证据；验收程序仅编译检查，不能据此声称运行通过。
- 单人本机显式保存，无账户、云同步、协作；不复制上游实现。
- 不管理书籍文件/版权下载、读书社交、ISBN抓取或多书架关系。
