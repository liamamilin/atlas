# 架构与契约

## 运行边界
Python标准库HTTP+SQLite，本机127.0.0.1；--data-dir独立目录，--demo仅新库首次初始化。GET只读，所有错误JSON为{error:{code,message}}，失败零写入，未知ID404not_found。输入类型先校验；事务保存；UI文本转义，无第三方资源。
## 数据与规则
shelves(id,name UNIQUE)，books(id,shelf_id,title,author,total_pages,pages_read)。总页整数1..100000；已读0..total_pages，状态由0=>unread，等于总页=>finished，其余reading，百分比只显示1位小数。更新允许回退以更正误填。名称trim1..80，书名1..200、作者0..120。搜索标题/作者casefold包含匹配，q空返回全部；不做全文电子书搜索。
## 接口
GET /api/health；GET /api/state?shelf_id=&q=&status= -> {shelves,books:[{id,shelf_id,title,author,total_pages,pages_read,status,progress_percent}]}；POST /api/shelves {name}->201；POST /api/books {shelf_id,title,author,total_pages}->201（pages_read=0）；POST /api/books/progress {id,pages_read}->200。400 invalid_pages/invalid_name/invalid_status，重复书架409already_exists。
## 交互
书架筛选、书籍卡片、页数表单、状态徽标和完成列表。空书架提示先加书，不自动获取封面/ISBN；错误保留输入，不自动删书。
## 来源与推断
目标独立实现纸书/电子书元数据目录；每书只放一个书架，页数驱动状态；不搭建Calibre内容服务器或电子书阅读器。
