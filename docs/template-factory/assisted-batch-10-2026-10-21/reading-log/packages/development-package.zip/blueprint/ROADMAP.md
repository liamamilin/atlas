# 阶段与验收

## P0 · 核心可用

用书架管理待读书，记录已读页数，完成后进入已读列表并能按标题或作者找回。

| 用例 | 类型 | 行为 | 执行器 |
| --- | --- | --- | --- |
| A01 | positive | 在“周末”书架登记200页书，标题作者均可检索。 | acceptance/probe.py |
| A02 | positive | 更新50页显示25%，更新200页显示已读；从200改100返回在读50%。 | acceptance/probe.py |
| A03 | positive | 201或负数页拒绝且不改原书；不同书架筛选隔离；0总页拒绝。 | acceptance/probe.py |
| A04 | positive | 同目录重启保留书架、页数和派生状态。 | acceptance/probe.py |
