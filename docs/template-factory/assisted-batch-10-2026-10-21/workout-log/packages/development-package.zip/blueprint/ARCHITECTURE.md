# 架构与契约

## 运行边界
Python标准库HTTP+SQLite，本机127.0.0.1；--data-dir独立目录，--demo仅新库首次初始化。GET只读，所有错误JSON为{error:{code,message}}，失败零写入，未知ID404not_found。输入类型先校验；事务保存；UI文本转义，无第三方资源。
## 数据与规则
sessions(id,date UNIQUE,title)，sets(id,session_id,exercise,weight_minor,reps,position)。weight十进制字符串0..9999.99两位，存百分之一kg；reps整数1..1000；训练量=weight_minor*reps求和，显示除100，绝不把不同日累加进当前日。exercise trim1..100，用casefold分组。编辑保持所属训练日不变。
## 接口
GET /api/health；GET /api/state?session_id= -> {sessions,sets,summary:{volume_minor,total_sets}}；POST /api/sessions {date,title}->201；POST /api/sets {session_id,exercise,weight,reps}->201；POST /api/sets/update {id,exercise,weight,reps}->200。400 invalid_weight/invalid_reps/invalid_date/invalid_name，重复日期409already_exists。
## 交互
训练日选择器，逐组条目，单位kg、次数、kg·次清晰；编辑显式保存；空日提示开始记录而非推荐强度。
## 来源与推断
目标聚焦已完成的kg重量×次数日志，不给训练或健康建议，不自动生成运动计划。
