# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_bf0bf87b07d245dca990ea7ea1f1721a@1

逐组记录动作、重量和次数，按训练日回查训练量，纠正误填后重新汇总。

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_workout_log_1

https://github.com/wger-project/wger/blob/8eed3c6d8406f09874eda6e402fb68c52d6c8392/wger/manager/models/log.py · 8eed3c6d8406f09874eda6e402fb68c52d6c8392

code_observation: WorkoutLog为逐动作日志，具有UUID、日期和用户关联。

AGPL-3.0（LICENSE.txt；只研究，不复制实现）

https://github.com/wger-project/wger/blob/8eed3c6d8406f09874eda6e402fb68c52d6c8392/LICENSE.txt

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S03 · ev_assisted_workout_log_2

https://github.com/wger-project/wger/blob/8eed3c6d8406f09874eda6e402fb68c52d6c8392/wger/manager/models/log.py · 8eed3c6d8406f09874eda6e402fb68c52d6c8392

code_observation: weight_unit与两位小数weight分开记录，重量允许空值；目标首版固定kg并明确0kg含义。

AGPL-3.0（LICENSE.txt；只研究，不复制实现）

https://github.com/wger-project/wger/blob/8eed3c6d8406f09874eda6e402fb68c52d6c8392/LICENSE.txt

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S04 · ev_assisted_workout_log_design

https://github.com/wger-project/wger/blob/8eed3c6d8406f09874eda6e402fb68c52d6c8392/LICENSE · 8eed3c6d8406f09874eda6e402fb68c52d6c8392

inference: 目标聚焦已完成的kg重量×次数日志，不给训练或健康建议，不自动生成运动计划。

AGPL-3.0（LICENSE.txt；只研究，不复制实现）

https://github.com/wger-project/wger/blob/8eed3c6d8406f09874eda6e402fb68c52d6c8392/LICENSE.txt

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## 待验证

- 证据独立审阅pending
- 上游not_run
- 辅助试用，非严格G1/T08；Codex研究与编写，证据独审pending，上游未运行。
- 本模板尚未开发代表应用或取得下游运行证据；验收程序仅编译检查，不能据此声称运行通过。
- 单人本机显式保存，无账户、云同步、协作；不复制上游实现。
- 不含动作视频、身体指标、营养/康复建议、lb换算或器械联动。
