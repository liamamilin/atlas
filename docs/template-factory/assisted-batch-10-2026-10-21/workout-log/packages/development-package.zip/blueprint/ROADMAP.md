# 阶段与验收

## P0 · 核心可用

逐组记录动作、重量和次数，按训练日回查训练量，纠正误填后重新汇总。

| 用例 | 类型 | 行为 | 执行器 |
| --- | --- | --- | --- |
| A01 | positive | 登记卧推50kg×10次、50kg×8次，总训练量900kg·次。 | acceptance/probe.py |
| A02 | positive | 第一组改55kg×10次后合计950kg·次，第二日隔离。 | acceptance/probe.py |
| A03 | positive | 负重量、小数次数和非有限值拒绝，0kg可记自重但注明不含身体重量。 | acceptance/probe.py |
| A04 | positive | 重启保留每组数据和日汇总。 | acceptance/probe.py |
