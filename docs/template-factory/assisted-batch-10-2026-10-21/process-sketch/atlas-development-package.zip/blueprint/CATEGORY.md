# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_cd663b9f8fdb475e8382fb6fadd44ac9@1

用开始、处理、判断和结束节点画出小流程，连接步骤并移动节点时保持连接，保存后回看。

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_process_sketch_1

https://github.com/jgraph/drawio/blob/17b367b91dbab91804f852645788d7ffb46dcb79/src/main/webapp/mxgraph/src/model/mxGeometry.js · 17b367b91dbab91804f852645788d7ffb46dcb79

code_observation: mxGeometry区分顶点x/y宽高和边的端点/控制点，并说明连接状态与移动时控制点行为。

Apache-2.0（LICENSE；只研究，不复制实现）

https://github.com/jgraph/drawio/blob/17b367b91dbab91804f852645788d7ffb46dcb79/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S03 · ev_assisted_process_sketch_2

https://github.com/jgraph/drawio/blob/17b367b91dbab91804f852645788d7ffb46dcb79/src/main/webapp/mxgraph/src/model/mxGeometry.js · 17b367b91dbab91804f852645788d7ffb46dcb79

code_observation: translate对顶点位置及可用的sourcePoint/targetPoint平移；目标节点ID绑定的重算方式仍为独立设计。

Apache-2.0（LICENSE；只研究，不复制实现）

https://github.com/jgraph/drawio/blob/17b367b91dbab91804f852645788d7ffb46dcb79/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S04 · ev_assisted_process_sketch_design

https://github.com/jgraph/drawio/blob/17b367b91dbab91804f852645788d7ffb46dcb79/LICENSE · 17b367b91dbab91804f852645788d7ffb46dcb79

inference: 目标以SVG渲染少量流程节点，边持有节点ID，几何改变时派生中心端点；不复制mxGraph或提供完整BPMN。

Apache-2.0（LICENSE；只研究，不复制实现）

https://github.com/jgraph/drawio/blob/17b367b91dbab91804f852645788d7ffb46dcb79/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## 待验证

- 证据独立审阅pending
- 上游not_run
- 辅助试用，非严格G1/T08；Codex研究与编写，证据独审pending，上游未运行。
- 本模板尚未开发代表应用或取得下游运行证据；验收程序仅编译检查，不能据此声称运行通过。
- 单人本机显式保存，无账户、云同步、协作；不复制上游实现。
- 无图形智能布局、BPMN验证、协作、图片/PDF导出或工作流执行。
