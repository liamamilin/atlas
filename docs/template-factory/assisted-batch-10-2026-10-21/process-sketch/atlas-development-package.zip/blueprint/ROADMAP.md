# 阶段与验收

## P0 · 核心可用

用开始、处理、判断和结束节点画出小流程，连接步骤并移动节点时保持连接，保存后回看。

| 用例 | 类型 | 行为 | 执行器 |
| --- | --- | --- | --- |
| A01 | positive | 创建start、process、decision、end四节点并建立三条边，分支可标“是”。 | acceptance/probe.py |
| A02 | positive | 移动process节点后，边仍指向相同节点ID，UI端点按新几何重算。 | acceptance/probe.py |
| A03 | positive | 未知端点、自环、重复同端点同标签边拒绝；导出保留全部节点几何及边。 | acceptance/probe.py |
| A04 | positive | 重启保留节点位置、类型、标签和连接。 | acceptance/probe.py |
