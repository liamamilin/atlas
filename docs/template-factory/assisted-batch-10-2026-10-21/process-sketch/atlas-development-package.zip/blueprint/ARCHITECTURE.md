# 架构与契约

## 运行边界
Python标准库HTTP+SQLite，本机127.0.0.1；--data-dir独立目录，--demo仅新库首次初始化。GET只读，所有错误JSON为{error:{code,message}}，失败零写入，未知ID404not_found。输入类型先校验；事务保存；UI文本转义，无第三方资源。
## 数据与规则
diagrams(id,title)，nodes(id,diagram_id,kind start|process|decision|end,label,x,y)，edges(id,diagram_id,source_id,target_id,label)。节点默认尺寸120×60，decision绘菱形，start/end圆角；x/y整数0..1900，label1..80。边两端必须属于同图、不能自身、source+target+label唯一；允许回路但不解释为执行引擎。导出完整图结构JSON，不保存派生像素端点。
## 接口
GET /api/health；GET /api/state?diagram_id= -> {diagrams,nodes,edges}；GET /api/export?diagram_id= -> 同结构JSON；POST /api/diagrams {title}->201；POST /api/nodes {diagram_id,kind,label,x,y}->201；POST /api/nodes/move {id,x,y}->200；POST /api/edges {diagram_id,source_id,target_id,label}->201。400 invalid_kind/invalid_position/invalid_edge/invalid_name，409already_exists。
## 交互
提供类型选择、新增节点、连接起终点及标签表单；坐标编辑是必备无拖拽路径，SVG连线随移动更新。空图有示例提示，不执行图内文字或脚本。
## 来源与推断
目标以SVG渲染少量流程节点，边持有节点ID，几何改变时派生中心端点；不复制mxGraph或提供完整BPMN。
