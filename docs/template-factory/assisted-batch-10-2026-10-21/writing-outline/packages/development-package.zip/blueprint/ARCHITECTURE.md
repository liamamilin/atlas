# 架构与契约

## 运行边界
Python标准库HTTP+SQLite，本机127.0.0.1；--data-dir独立目录，--demo仅新库首次初始化。GET只读，所有错误JSON为{error:{code,message}}，失败零写入，未知ID404not_found。输入类型先校验；事务保存；UI文本转义，无第三方资源。
## 数据与规则
documents(id,title)，nodes(id,document_id,parent_id nullable,text,position,collapsed)。同级连续0基；新增在末尾；移动{parent_id,position}为最终同级序列的插入位置0..剩余长度，校验同文档且不能放自己/后代。整个子树保留ID；折叠只改标志。text1..500纯单行，document title1..120。导出所有节点preorder，每层2空格和“- ”。
## 接口
GET /api/health；GET /api/state?document_id= -> {documents,nodes}；GET /api/export?document_id= -> {text}；POST /api/documents {title}->201；POST /api/nodes {document_id,parent_id,text}->201；POST /api/nodes/move {id,parent_id,position}->200；POST /api/nodes/collapse {id}->200切换。400 invalid_name/invalid_parent/invalid_position，循环409cycle_detected。
## 交互
树形缩进、展开折叠、明确的移动目标下拉与同级位置，不依赖拖拽才可操作。导出预览含隐藏分支。只保存纯文本，不执行Markdown/HTML。
## 来源与推断
目标采用邻接表树和事务内移动，而非复用Logseq的图谱/同步栈；循环检测、折叠与文本格式均为目标设计。
