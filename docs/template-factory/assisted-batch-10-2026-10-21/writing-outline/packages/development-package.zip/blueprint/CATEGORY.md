# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_3e5d16480fde4032b759eac2dae15b44@1

把文章要点整理成可折叠的树，移动整个分支后保留子项及顺序，导出结构文本。

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_writing_outline_1

https://github.com/logseq/logseq/blob/e8c4c37ed43299f22ca36ef898466eae02f45416/deps/outliner/README.md · e8c4c37ed43299f22ca36ef898466eae02f45416

documentation: 仓库outliner子库说明提供大纲操作，列出datascript-report与pipeline命名空间及前端/命令行使用；未据此声称目标移动规则已在上游验证。

AGPL-3.0（LICENSE.md；只研究，不复制实现）

https://github.com/logseq/logseq/blob/e8c4c37ed43299f22ca36ef898466eae02f45416/LICENSE.md

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S03 · ev_assisted_writing_outline_design

https://github.com/logseq/logseq/blob/e8c4c37ed43299f22ca36ef898466eae02f45416/LICENSE · e8c4c37ed43299f22ca36ef898466eae02f45416

inference: 目标采用邻接表树和事务内移动，而非复用Logseq的图谱/同步栈；循环检测、折叠与文本格式均为目标设计。

AGPL-3.0（LICENSE.md；只研究，不复制实现）

https://github.com/logseq/logseq/blob/e8c4c37ed43299f22ca36ef898466eae02f45416/LICENSE.md

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## 待验证

- 证据独立审阅pending
- 上游not_run
- 辅助试用，非严格G1/T08；Codex研究与编写，证据独审pending，上游未运行。
- 本模板尚未开发代表应用或取得下游运行证据；验收程序仅编译检查，不能据此声称运行通过。
- 单人本机显式保存，无账户、云同步、协作；不复制上游实现。
- 无双向链接、图谱、多人编辑、附件、富文本或撤销栈。
