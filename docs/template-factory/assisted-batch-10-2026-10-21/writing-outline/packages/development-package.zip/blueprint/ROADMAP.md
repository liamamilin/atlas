# 阶段与验收

## P0 · 核心可用

把文章要点整理成可折叠的树，移动整个分支后保留子项及顺序，导出结构文本。

| 用例 | 类型 | 行为 | 执行器 |
| --- | --- | --- | --- |
| A01 | positive | 创建引言和正文，正文下添加论据，形成两层结构。 | acceptance/probe.py |
| A02 | positive | 把正文移到引言下，论据随整个子树移动；折叠只隐藏不删除。 | acceptance/probe.py |
| A03 | positive | 禁止移到自身或后代；导出每层两个空格，不因折叠丢子项。 | acceptance/probe.py |
| A04 | positive | 重启保留父子关系、同级顺序和折叠状态。 | acceptance/probe.py |
