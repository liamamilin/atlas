## Description

This library provides outliner operation related functionality. This library is
compatible with ClojureScript and with
node/[nbb-logseq](https://github.com/logseq/nbb-logseq) to respectively provide
frontend and commandline functionality.

## API

This library is under the parent namespace `logseq.outliner`. This library
provides two main namespaces: `logseq.outliner.datascript-report` and `logseq.outliner.pipeline`.

## Usage

See the frontend for cljs usage.

## Dev

This follows the practices that [the Logseq frontend
follows](/docs/dev-practices.md). Most of the same linters are used, with
configurations that are specific to this library. See [this library's CI
file](/.github/workflows/deps-outliner.yml) for linting examples.

### Setup

To run linters and tests, you'll want to install pnpm dependencies once:
```
pnpm install
```

This step is not needed if you're just running the frontend application.

### Testing

Testing is done with nbb-logseq and
[nbb-test-runner](https://github.com/nextjournal/nbb-test-runner). Some basic
usage:

```
# Run all tests
$ pnpm test
# List available options
$ pnpm test -H
# Run tests with :focus metadata flag
$ pnpm test -i focus
```

### Managing dependencies

See [standard nbb/cljs library advice in graph-parser](/deps/graph-parser/README.md#managing-dependencies).
