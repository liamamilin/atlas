# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享case r2的静态源码/文档观察与目标推断；无独立证据审阅通过、无上游运行。
ev_assisted_notes_container [code_observation]: Folder.notes查询按单一parent_id读取笔记；非includeDeleted时增加deleted_time=0条件，表明容器归属和软删除过滤是分开处理的。
ev_assisted_notes_design [inference]: 本场景采用扁平项目/收件箱、独立pinned/archived标记、保留项目的回收站与包含归档的全库正文搜索；这些目标取舍不宣称为Joplin原生置顶/归档能力。
ev_assisted_notes_docs [documentation]: REST API参考定义title、body和笔记本parent_id；说明改变parent_id可移动笔记，并提供search入口。
ev_assisted_notes_move [code_observation]: Note.new(parentId)将parentId写入新笔记的output.parent_id，确认新笔记的单一容器标识；该段不是移动实现，移动语义依据单独REST文档。
ev_assisted_notes_search [code_observation]: Note搜索路径分别处理deleted_time、parent_id条件，并在anywherePattern路径使用(title LIKE ? OR body LIKE ?)；只作该分支静态观察，不泛指全部搜索实现。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_805c99ffe8da4532817592bb466a505e@1

把会议结论和项目细节持续记入个人笔记库，按项目归档并管理活跃与过期笔记，使任一历史记录都能被可靠取回

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_notes_container

https://github.com/laurent22/joplin/blob/cf57e5932584c0fbd894d8510f1a31a4d41f2251/packages/lib/models/Folder.ts · cf57e5932584c0fbd894d8510f1a31a4d41f2251

code_observation: Folder.notes查询按单一parent_id读取笔记；非includeDeleted时增加deleted_time=0条件，表明容器归属和软删除过滤是分开处理的。

根LICENSE声明AGPL-3.0-or-later，子目录可例外；未穷尽文件级审计，不复制上游实现。

https://github.com/laurent22/joplin/blob/cf57e5932584c0fbd894d8510f1a31a4d41f2251/LICENSE

仅设计研究；Python应用全新实现；证据审阅pending、上游运行not_run

## S03 · ev_assisted_notes_design

https://github.com/laurent22/joplin/blob/cf57e5932584c0fbd894d8510f1a31a4d41f2251/LICENSE · cf57e5932584c0fbd894d8510f1a31a4d41f2251

inference: 本场景采用扁平项目/收件箱、独立pinned/archived标记、保留项目的回收站与包含归档的全库正文搜索；这些目标取舍不宣称为Joplin原生置顶/归档能力。

根LICENSE声明AGPL-3.0-or-later，子目录可例外；未穷尽文件级审计，不复制上游实现。

https://github.com/laurent22/joplin/blob/cf57e5932584c0fbd894d8510f1a31a4d41f2251/LICENSE

仅设计研究；Python应用全新实现；证据审阅pending、上游运行not_run

## S04 · ev_assisted_notes_docs

https://github.com/laurent22/joplin/blob/cf57e5932584c0fbd894d8510f1a31a4d41f2251/readme/api/references/rest_api.md · cf57e5932584c0fbd894d8510f1a31a4d41f2251

documentation: REST API参考定义title、body和笔记本parent_id；说明改变parent_id可移动笔记，并提供search入口。

根LICENSE声明AGPL-3.0-or-later，子目录可例外；未穷尽文件级审计，不复制上游实现。

https://github.com/laurent22/joplin/blob/cf57e5932584c0fbd894d8510f1a31a4d41f2251/LICENSE

仅设计研究；Python应用全新实现；证据审阅pending、上游运行not_run

## S05 · ev_assisted_notes_move

https://github.com/laurent22/joplin/blob/cf57e5932584c0fbd894d8510f1a31a4d41f2251/packages/lib/models/Note.ts · cf57e5932584c0fbd894d8510f1a31a4d41f2251

code_observation: Note.new(parentId)将parentId写入新笔记的output.parent_id，确认新笔记的单一容器标识；该段不是移动实现，移动语义依据单独REST文档。

根LICENSE声明AGPL-3.0-or-later，子目录可例外；未穷尽文件级审计，不复制上游实现。

https://github.com/laurent22/joplin/blob/cf57e5932584c0fbd894d8510f1a31a4d41f2251/LICENSE

仅设计研究；Python应用全新实现；证据审阅pending、上游运行not_run

## S06 · ev_assisted_notes_search

https://github.com/laurent22/joplin/blob/cf57e5932584c0fbd894d8510f1a31a4d41f2251/packages/lib/models/Note.ts · cf57e5932584c0fbd894d8510f1a31a4d41f2251

code_observation: Note搜索路径分别处理deleted_time、parent_id条件，并在anywherePattern路径使用(title LIKE ? OR body LIKE ?)；只作该分支静态观察，不泛指全部搜索实现。

根LICENSE声明AGPL-3.0-or-later，子目录可例外；未穷尽文件级审计，不复制上游实现。

https://github.com/laurent22/joplin/blob/cf57e5932584c0fbd894d8510f1a31a4d41f2251/LICENSE

仅设计研究；Python应用全新实现；证据审阅pending、上游运行not_run

## 待验证

- 上游未运行，独立证据审阅pending
- 置顶/归档是本场景设计，不宣称Joplin原生能力
- 只参考设计，不复制实现；根LICENSE AGPL-3.0-or-later与例外说明保留，文件级例外未穷尽审计
