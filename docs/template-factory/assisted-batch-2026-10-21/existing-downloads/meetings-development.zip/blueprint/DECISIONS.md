# 决策与默认值

## D01 · 正文存储与渲染？

UTF-8纯文本/Markdown原文，HTML转义显示；不执行正文HTML。

When to ask / 询问条件: 需要富文本或附件时再增加独立设计。

准确保存多行内容并避免脚本执行。

local trial default

## D02 · 归档与删除有什么区别？

归档仍在全库搜索；回收站可恢复、不自动过期、无永久删除。

When to ask / 询问条件: 用户要求保留期或永久清除时再明确确认。

找回历史与避免意外丢失。

local trial default

## D03 · 快速记录是否自动保存？

点击保存才写入，先进入收件箱；编辑用revision检测陈旧覆盖。

When to ask / 询问条件: 确需实时自动保存/多人协作时再评估。

可解释写入边界与冲突反馈。

local trial default
