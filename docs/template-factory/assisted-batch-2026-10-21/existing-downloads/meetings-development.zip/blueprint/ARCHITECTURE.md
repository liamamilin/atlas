# 架构与契约

## 默认实现
Python标准库http.server＋SQLite，服务端HTML表单；本机单人127.0.0.1，无账户、同步、外部服务或第三方依赖。全新实现，只参考Joplin固定代码，不复制实现/图标。

## 数据与生命周期
projects(id,name UNIQUE,created_at,is_default)，初建“收件箱”默认项目。notes(id,title,body,project_id REFERENCES projects,pinned,archived,trashed_at,revision,created_at,updated_at)。单一项目外键；正文必需非空、最多100000字符，标题可省略取首行，最长120字；保存UTF-8原文不改换行/表格，HTML输出转义而非执行。project创建名称1–80字符，重复409。
移动只改project_id；置顶与归档独立标记，回收保持原项目/正文/标记，不自动过期、不提供永久删除。默认活跃列表排除archived和trash；q非空的全库搜索包含归档但排除回收站；项目筛选可叠加。view=archive只归档，view=trash仅回收。查询仅标题/正文casefold子串，不提供索引全文或模糊语义。排序先pinned DESC，后选择标题或更新时间，再以id稳定打破平局。
每次成功编辑revision+1，POST编辑必须带当前revision，旧版本409保持原内容；HTML保留草稿并显示冲突说明，加载最新版本号，再次保存前用户须核对。动作事务化；GET无写入。

## API
GET /api/health；GET /api/state?project=<id>&q=<text>&view=active|archive|trash&sort=updated|title 返回projects与过滤notes；GET /api/notes/{id}返回完整原文状态（含trash，不恢复）。POST /api/projects {name}→201；POST /api/notes {title,body,project_id?}→201（省略项目到收件箱）；POST /api/notes/update {id,revision,title,body,project_id}→200；POST /api/notes/move {id,project_id}→200；POST /api/notes/pin|archive|trash|restore {id}→200。pin/archive切换对应标记；trash可恢复，已在回收站的笔记禁止其他编辑/移动。
400 invalid_body/invalid_title/invalid_project/invalid_name/bad_request，404 not_found，409 revision_conflict/already_exists；{error:{code,message}}。不以UI假状态代替数据库。

## 浏览器入口与恢复
GET / 首页项目侧栏、创建项目、快速记录、标题/正文搜索、排序和活跃/归档/回收视图。GET /note/{id}打开全文，提供项目移动、置顶、归档、回收及恢复动作；GET /note/{id}/edit回填标题/正文/项目并保留revision；保存成功303到全文，其他动作回全文或回收视图；失败400/409可读role=alert，原输入保留并可修正提交。快速捕获可不先选择项目；正文表单明确“点击保存才写入本机”。编辑非自动保存，不能宣称离开页面前未保存草稿已持久化。归档记录仍可从搜索打开，并可取消归档。项目仅创建不支持删除/整体归档。

## 范围
支持多行纯文本/Markdown表格原文，不渲染富文本、不自动提取行动项、不录音转写；项目可浏览，生命周期与全文回查构成完整核心。权限/计费/云端协作不适用本机首版。真实浏览器、真实重启另记录，HTTP程序不能冒充浏览器。
