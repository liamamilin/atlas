# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_435d92c3222644bd906e10a62e65737a@1

逐件记录自己的物品、所在房间与估值，搬动后仍能找到，并查看待搬物品数量和估值。

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_home_inventory_1

https://github.com/sysadminsmedia/homebox/blob/1fd28822634a3d5935c002d569559ef46530d4a0/backend/internal/data/ent/schema/entity.go · 1fd28822634a3d5935c002d569559ef46530d4a0

code_observation: Entity字段含notes、quantity、archived和asset_id；说明独立物品记录与归档状态。

AGPL-3.0（固定根LICENSE；仅研究，不复制实现）

https://github.com/sysadminsmedia/homebox/blob/1fd28822634a3d5935c002d569559ef46530d4a0/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S03 · ev_assisted_home_inventory_2

https://github.com/sysadminsmedia/homebox/blob/1fd28822634a3d5935c002d569559ef46530d4a0/backend/internal/data/ent/schema/entity.go · 1fd28822634a3d5935c002d569559ef46530d4a0

code_observation: Entity的parent和location边均Unique，代码注释说明沿父链解析位置；目标只采用单层位置，不复刻层级。

AGPL-3.0（固定根LICENSE；仅研究，不复制实现）

https://github.com/sysadminsmedia/homebox/blob/1fd28822634a3d5935c002d569559ef46530d4a0/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S04 · ev_assisted_home_inventory_design

https://github.com/sysadminsmedia/homebox/blob/1fd28822634a3d5935c002d569559ef46530d4a0/LICENSE · 1fd28822634a3d5935c002d569559ef46530d4a0

inference: 目标每行固定一件家庭物品、平面位置、整数分估值与筛选后汇总；与上游quantity浮点及层级实体不同，是明确的试用取舍。

AGPL-3.0（固定根LICENSE；仅研究，不复制实现）

https://github.com/sysadminsmedia/homebox/blob/1fd28822634a3d5935c002d569559ef46530d4a0/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## 待验证

- 证据独立审阅pending
- 上游not_run
- 照片/收据/附件、层级房间/箱子、保险证明、导出、家庭协作后置
- 估值不是理赔或市场估价；本机单人，不暴露公网
