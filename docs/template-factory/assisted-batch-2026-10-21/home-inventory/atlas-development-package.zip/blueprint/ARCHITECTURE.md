# 架构与契约

## 数据与范围
单人本机127.0.0.1，Python标准库HTTP+SQLite，服务端HTML表单，全新实现不复制Homebox代码。
locations(id,name UNIQUE)；items(id,name,location_id FK,value_minor INTEGER,notes,archived,revision)。一行一件，不引入数量/保险价值推断；值是用户估计的CNY金额，不是理赔证明。初始位置“未分类”，新建位置名称1–80；物品名1–120、备注0–2000，HTML始终转义。
金额非负、最多两位十进制、最大999999999.99，不接受NaN/指数/负数/三位小数；按整数分聚合。重复物品名允许，ID唯一。删除需求先用归档/恢复，不永久删除。修改必须当前revision，409保留输入；事务校验失败零写入。
## 接口
GET /api/health；GET /api/state?q=&location=&view=active|archive|all -> locations、items、summary{count,total_minor}（仅当前筛选结果）。搜索匹配name/notes，大小写无关；位置与搜索条件相交；默认active。
POST /api/locations {name} ->201 {id,name}；POST /api/items {name,location_id,value,notes} ->201；POST /api/items/update {id,revision,name,location_id,value,notes}->200；POST /api/items/archive {id}->200切换归档状态。item输出value_minor、revision，输入value为元字符串。400 invalid_name/invalid_value/invalid_location/bad_request；404 not_found；409 revision_conflict/already_exists，JSON{error:{code,message}}。
## UI与启动
首页清楚区分位置/搜索/视图和当前筛选的数量、估值。新增、编辑的每个输入有label；值错误保留原稿；成功再跳转。提供编辑入口、归档/恢复按钮和详情原文。显式保存、无自动保存。python3 app/serve.py --port 5276 --data-dir <目录>，默认examples/home-inventory-trial/data；GET不写入，--demo仅空库首次初始化。不接触原三个应用数据库。
