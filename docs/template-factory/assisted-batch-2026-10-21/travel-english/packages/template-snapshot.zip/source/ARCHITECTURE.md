# 架构与契约

## 课程与边界
单用户本机；课程内容全新编写，不复制LibreLingo课程/媒体。原创course-v1为中文提示→英文文本，三课每课三题，lesson顺序固定：directions（问路）、hotel（入住）、restaurant（点餐）。示例目标句Where is the station? / I have a reservation. / Water, please.；每题预先列出有限可接受变体。学习完整核心含应用拥有的语言课程、交互反馈、持续进度。仅文本初学练习，不宣称达到语言等级或代替教学。
## 数据和API
course_version + lessons/questions静态配置；attempts(id,lesson,question,input,correct,at)、mastered UNIQUE(course_version,question)、mistakes UNIQUE(course_version,question)。SQLite事务内写答题和正确集合；只按规范化后的有限答案匹配（strip/casefold/合并空格，不做模糊语义匹配）；空输入400invalid_answer不计错，未知题404，未解锁课409locked。
GET /api/course -> lessons,progress,next_lesson,mistakes；GET /api/lessons/{id} -> prompts，未作答不提前暴露答案；POST /api/answers {question_id,answer,submission_id} -> correct,acceptable_answers,progress。submission_id唯一幂等，同ID不同body409。只在本课三题均正确时解锁下一课；错题被正确回答才移除。GET不写进度，旧course_version不静默覆盖或清空。
## UI与验证
首页显示三课顺序和进度；题页label+输入+提交；即时成功/错误、可接受答案及重试按钮。错题重练有独立入口和空状态。未保存不能假称答对；网络错误留输入。测试非法题、空输入、错误不推进、首次正确幂等、解锁、复习和真实重启。本批仅导出，不运行应用。

## 原创题库与固定ID
课程题库在acceptance/COURSE.json；qid固定，英文答案接受表仅为文字匹配，不复制上游课程。每课下一题选择尚未答对的题，错题重练不改变课程顺序。接口lesson.questions输出id,prompt；/api/course.progress为{mastered_count,completed_lessons}，mistakes为question_id列表。POST /api/answers返回correct、acceptable_answers、progress；合法首次提交返回200。
