# 阶段与验收

## P0 · 核心可用

按固定三课练习必要英语短句，获得即时文字反馈，保存完成进度，并优先重练错误题。

| 用例 | 类型 | 行为 | 执行器 |
| --- | --- | --- | --- |
| A01 | positive | 固定three lesson ids/directions,hotel,restaurant，每课三题与明确可接受答案；未完成前不得解锁下一课。 | acceptance/probe.py |
| A02 | positive | 按strip+casefold+合并空格匹配；错误显示可接受答案但不计正确，正确一题只记一次。 | acceptance/probe.py |
| A03 | positive | 错题队列答对可移除；刷新重启保留课程版本、答题事件与唯一正确集合。 | acceptance/probe.py |
