# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_6db4af782bc548e69e0f48072069ed72@1

按固定三课练习必要英语短句，获得即时文字反馈，保存完成进度，并优先重练错误题。

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_travel_english_1

https://github.com/kantord/LibreLingo/blob/3c4bcfb3ef999ae48ee3d361afb0c4a5fa317dee/docs/courses/skill.md · 3c4bcfb3ef999ae48ee3d361afb0c4a5fa317dee

documentation: Skill文档说明课程Module下的Skill组织主题词句，并自动生成问题任务。

AGPL-3.0根LICENSE；课程及媒体可能另有许可证，本模板不复制上游课程/媒体

https://github.com/kantord/LibreLingo/blob/3c4bcfb3ef999ae48ee3d361afb0c4a5fa317dee/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S03 · ev_assisted_travel_english_2

https://github.com/kantord/LibreLingo/blob/3c4bcfb3ef999ae48ee3d361afb0c4a5fa317dee/docs/courses/challenge.md · 3c4bcfb3ef999ae48ee3d361afb0c4a5fa317dee

documentation: Challenge文档说明用户通过一系列问题任务学习，任务从Skill配置生成。

AGPL-3.0根LICENSE；课程及媒体可能另有许可证，本模板不复制上游课程/媒体

https://github.com/kantord/LibreLingo/blob/3c4bcfb3ef999ae48ee3d361afb0c4a5fa317dee/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S04 · ev_assisted_travel_english_design

https://github.com/kantord/LibreLingo/blob/3c4bcfb3ef999ae48ee3d361afb0c4a5fa317dee/LICENSE · 3c4bcfb3ef999ae48ee3d361afb0c4a5fa317dee

inference: 目标采用原创三课固定课程、文本匹配即时反馈和SQLite进度/错题记录；课程文档不证明上游运行或本目标的掌握度判断。归一化匹配不是自由语义或教学效果评估。

AGPL-3.0根LICENSE；课程及媒体可能另有许可证，本模板不复制上游课程/媒体

https://github.com/kantord/LibreLingo/blob/3c4bcfb3ef999ae48ee3d361afb0c4a5fa317dee/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## 待验证

- 证据独立审阅pending
- 上游not_run
- 模板未开发真实应用，未经过教学人员审阅，未做学习效果或独立证据审阅
- 语音、听力、自由对话、真实语义评分、SRS和多用户后置
- 上游归档且历史仓库重定向，只参考固定版本；不作为当前推荐部署项目
