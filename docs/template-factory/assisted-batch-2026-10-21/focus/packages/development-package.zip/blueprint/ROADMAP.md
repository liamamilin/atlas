# 阶段与验收

## P0 · 核心可用

选定写作目标，完成一轮25分钟专注，再主动进入5分钟休息，并留存真实完成记录。

| 用例 | 类型 | 行为 | 执行器 |
| --- | --- | --- | --- |
| A01 | positive | 25分钟默认、1–120分钟配置；暂停不耗时，恢复剩余。 | acceptance/probe.py |
| A02 | positive | 自然到期一次计数及原专注时长；休息仅显示提醒，不计专注。 | acceptance/probe.py |
| A03 | positive | 取消不记完成，同session完成幂等；刷新和重启保留状态与记录。 | acceptance/probe.py |
