# 决策与默认值

## D01 · 首版运行与数据边界？

单用户本机、独立SQLite；显式保存，无账户、云端和协作。

When to ask / 询问条件: 确需公网托管或多人数据时先确认，不自行扩展。

保护本地数据，避免默认外发。

assisted default

## D02 · 是否复刻上游？

目标用SQLite持久化wall-clock deadline和唯一session_id跨刷新结算；自然完成与取消分开计数，休息不计入专注，属于目标设计，未证明上游相同实现。

When to ask / 询问条件: 目标变化、破坏已有数据或需要引入上游实现/依赖时先确认。

不混淆来源事实与目标设计。

assisted default
