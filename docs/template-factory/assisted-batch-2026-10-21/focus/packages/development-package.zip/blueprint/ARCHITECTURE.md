# 架构与契约

## 数据与交互
单用户本机Python/SQLite+浏览器少量JS倒计时。sessions(id,goal,kind,duration_seconds,state,deadline,remaining_seconds,completed_at UNIQUE id)；focus/short-break状态区分。服务端UTC秒时间权威；暂停保存remaining并清空deadline，恢复deadline=now+remaining；UI仅渲染，不自行认定完成。GET只读取，POST settle在事务内以state=running条件原子结算，过期一次写入completed，不将skip计为成功；页面可轮询POST settle并幂等。
时长分钟1–120，goal1–160；可用10秒开发测试配置但生产UI默认不提供。自然focus完成计duration_seconds，取消不计；5分钟短休息手动启动；系统时钟大幅回拨显示状态提示，不保证跨设备时间一致。
## 接口
GET /api/state -> current,history,totals；POST /api/sessions {goal,minutes}；POST /api/sessions/{id}/pause|resume|cancel|settle；POST /api/break {minutes:5}。state idle/running/paused/completed/cancelled。非法转换409invalid_transition、非法时长400invalid_duration；不覆盖已完成会话。首版只能一个活动计时。提供可读大倒计时、目标、明确按钮及提醒文本，浏览器声音/通知权限拒绝不得阻断流程。
## 验证
用可注入时钟的真实服务专项跑pause/resume/duplicate settle，另跑缩短计时的浏览器旅程和实际重启；本批不开发此应用，以上为待实现合同，not_run。
