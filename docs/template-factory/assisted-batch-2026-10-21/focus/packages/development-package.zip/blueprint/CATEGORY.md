# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_4636cb92042a444da70ed81c0c131666@1

选定写作目标，完成一轮25分钟专注，再主动进入5分钟休息，并留存真实完成记录。

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_focus_1

https://github.com/Splode/pomotroid/blob/dda06e6bf412bebe5ef8668a4357c52d974dc874/src-tauri/src/timer/engine.rs · dda06e6bf412bebe5ef8668a4357c52d974dc874

code_observation: TimerCommand显式区分Start/Pause/Resume/Reset/Skip和Reconfigure；Complete事件含skipped布尔值。

MIT（根LICENSE）

https://github.com/Splode/pomotroid/blob/dda06e6bf412bebe5ef8668a4357c52d974dc874/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S03 · ev_assisted_focus_2

https://github.com/Splode/pomotroid/blob/dda06e6bf412bebe5ef8668a4357c52d974dc874/src-tauri/src/timer/sequence.rs · dda06e6bf412bebe5ef8668a4357c52d974dc874

code_observation: 文件注释定义work→short-break和长休息的轮次推进；目标只采用一轮专注加短休息。

MIT（根LICENSE）

https://github.com/Splode/pomotroid/blob/dda06e6bf412bebe5ef8668a4357c52d974dc874/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## S04 · ev_assisted_focus_design

https://github.com/Splode/pomotroid/blob/dda06e6bf412bebe5ef8668a4357c52d974dc874/LICENSE · dda06e6bf412bebe5ef8668a4357c52d974dc874

inference: 目标用SQLite持久化wall-clock deadline和唯一session_id跨刷新结算；自然完成与取消分开计数，休息不计入专注，属于目标设计，未证明上游相同实现。

MIT（根LICENSE）

https://github.com/Splode/pomotroid/blob/dda06e6bf412bebe5ef8668a4357c52d974dc874/LICENSE

只参考设计；不复制上游代码。独立审阅pending，上游运行not_run。

## 待验证

- 证据独立审阅pending
- 上游not_run
- 本批仅模板和验收程序，应用未实现/未运行
- 长休息周期、网站拦截、任务系统、声音/通知保证和跨设备同步后置
