# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_e7e1f70a65da44cb95ecf786e204d159@1

Deliver a localhost-only, single-user, Python-stdlib web application that persists named boards, user-named ordered columns and ordered cards (title + short description) in one SQLite file, treats a card's column membership as the card's state (no separate status field), supports column add/rename/reorder and card move/reorder, shows every column's full card list with per-column counts, and reads the whole structure back unchanged after a restart. P0 explicitly excludes accounts, collaboration, a separate status field, WIP limits, notifications, time reports and automation, and those concepts are rejected at the API boundary rather than merely omitted.

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_personal_kanban_1

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/README.md · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

documentation: Upstream README describes Kanboard as project management software that focuses on the Kanban methodology and states the application is in maintenance mode: the author is not actively developing any new major features, only small fixes are made, and pull requests for new features and bug fixes are accepted.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S03 · ev_assisted_personal_kanban_10

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Model/ColumnModel.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream remove() deletes a column row by id and its docblock states that the column and all associated tasks are removed, so upstream column deletion is destructive rather than a move of the cards elsewhere.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S04 · ev_assisted_personal_kanban_11

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Model/TaskPositionModel.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream movePosition() returns false for a position below 1, resolves the swimlane when none is given, skips closed tasks when onlyOpen is set, and then dispatches to exactly one of three branches - swimlane change, column change or same-column position change - so a card's placement is the only way its location changes.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S05 · ev_assisted_personal_kanban_12

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Model/TaskPositionModel.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream saveTaskPositions() lists the other tasks of the same column ordered by position then id, inserts the moved task when the requested position equals the running offset, rewrites every other task's position, and finally places the task at the bottom while normalising a bad position - the whole column is renumbered around the moved card.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S06 · ev_assisted_personal_kanban_13

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Model/TaskPositionModel.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream saveSwimlaneChange() performs the source-column rewrite, the target-column rewrite and the timestamp update inside one database transaction and returns the conjunction of the three results, i.e. a move commits as a single all-or-nothing unit.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S07 · ev_assisted_personal_kanban_14

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Model/TaskPositionModel.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream saveColumnChange() applies the same transaction pattern for a move between two columns: clear the source column, fill the target column, update the timestamps, and report success only when all three writes succeeded.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S08 · ev_assisted_personal_kanban_15

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Model/TaskPositionModel.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream saveTaskPosition() cancels the surrounding transaction when the row update affects no rows, which is how a failed mid-move write aborts the whole move instead of leaving a half-renumbered column.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S09 · ev_assisted_personal_kanban_16

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Model/TaskPositionModel.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream moveBottom() computes MAX(position)+1 over the tasks of the target column and writes column_id, position, date_moved and date_modification, so appending a card to a column is a position write and not a separate status flag.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S10 · ev_assisted_personal_kanban_17

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Model/TaskPositionModel.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream fireEvents() emits a distinct event for a swimlane change, a column change or a position change and carries src_column_id, dst_column_id, date_moved and the task's recurrence fields; in upstream the move is the state-change event of the card.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S11 · ev_assisted_personal_kanban_18

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Model/TaskCreationModel.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream prepare() defaults an empty column_id to the first column of the project, defaults an empty title to 'Untitled', stamps date_creation, date_modification and date_moved with the current time and computes position as the number of tasks in the column plus one.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S12 · ev_assisted_personal_kanban_19

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Model/TaskCreationModel.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream create() persists the task row first and only afterwards calls movePosition() when an explicit position greater than one was requested, i.e. inserting a card at a chosen slot is a create step followed by a position step.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S13 · ev_assisted_personal_kanban_2

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/README.md · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

documentation: Upstream README links the official website, a feature list, the change log, a forum and the documentation pages for requirements, installation, upgrade and Docker use, i.e. upstream is a full server product with its own documentation and deployment story, not a local single-user tool.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S14 · ev_assisted_personal_kanban_20

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Model/TaskModificationModel.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream update() applies the changed fields to the task row and fires the modification events only when the write succeeded; the card's text fields are edited independently of its column and position.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S15 · ev_assisted_personal_kanban_21

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Model/TaskModificationModel.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream prepare() converts date_due and date_started through the date parser, removes the id field, resets the date, score and time fields and stamps date_modification - upstream tasks carry due/start dates and recurrence counters, which the pinned P0 scenario deliberately excludes.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S16 · ev_assisted_personal_kanban_22

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Controller/TaskMovePositionController.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream TaskMovePositionController::save() reads a JSON body with column_id, position and swimlane_id, checks a move permission on the project role, calls movePosition() with the project id, the task id and those three values, and then redirects back to the task view.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S17 · ev_assisted_personal_kanban_23

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Template/board/table_column.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: The upstream board template renders one table header cell per column carrying data-column-id, the escaped column title and a per-column dropdown, so the column order of the board surface is exactly the column position order.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S18 · ev_assisted_personal_kanban_24

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Template/board/table_column.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: The upstream column header renders the score, the visible task count and - when a task_limit is set - the total across swimlanes, i.e. upstream already shows a per-column card count next to the column title.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S19 · ev_assisted_personal_kanban_25

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Template/board/table_column.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: The upstream task count block is rendered only when the count is non-empty and is preceded by an ui-helper-hidden-accessible 'Task count' text, i.e. upstream labels the column count for assistive technology.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S20 · ev_assisted_personal_kanban_26

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Template/board/table_column.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: The upstream column dropdown offers 'Close all tasks in this column and this swimlane' only when the column holds tasks, showing that upstream treats the column as the container whose content can be closed in bulk - a batch operation outside the pinned P0 scenario.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S21 · ev_assisted_personal_kanban_3

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/README.md · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

documentation: Upstream README names Frederic Guillot as main developer, points at the contributor list and states that the project is distributed under the MIT License.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S22 · ev_assisted_personal_kanban_4

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

documentation: The pinned upstream LICENSE is the MIT License (MIT), copyright (c) Frederic Guillot, with the standard grant, the notice requirement and the warranty disclaimer.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S23 · ev_assisted_personal_kanban_5

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Model/ColumnModel.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream create() persists a new column for a project with title, task_limit (a WIP cap), description and hide_in_dashboard, and sets position to getLastColumnPosition(project_id) + 1, so a newly added column is appended at the end of the board rather than inserted at an arbitrary slot.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S24 · ev_assisted_personal_kanban_6

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Model/ColumnModel.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream update() rewrites the column title, task_limit, hide_in_dashboard and description in place and never touches the column position, so renaming a column is independent of the column order.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S25 · ev_assisted_personal_kanban_7

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Model/ColumnModel.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream changePosition() rejects a position below 1 or above the number of columns of the project, then renumbers the sibling columns ascending by their current position and finally writes the requested position on the moved column, returning false if any single update fails - reordering is a bounded, all-or-nothing rewrite of the sibling positions.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S26 · ev_assisted_personal_kanban_8

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Model/ColumnModel.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream getAll() returns the columns of a project ordered ascending by position, which is the mechanism behind the left-to-right column order of the board surface.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S27 · ev_assisted_personal_kanban_9

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/app/Model/ColumnModel.php · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

code_observation: Upstream getAllWithTaskCount() returns the columns ordered by position together with a per-column count of open tasks (is_active='1') and of closed tasks (is_active='0'), i.e. upstream derives the column card counts from the task table itself.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S28 · ev_assisted_personal_kanban_design

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE · e4fb64e972b0ae255a92cf4b7b03489846ebbffc

inference: Evidence classes are kept separate. (1) code_observation = behaviour read directly from the pinned upstream files at the cited lines (for example upstream renumbers a column around a moved card inside one transaction, upstream bounds a column reorder by the number of columns, upstream renders a per-column task count). (2) documentation = claims read from upstream README.md and LICENSE and from leaf.md; leaf.md describes the Kanban Task Board type in general terms and explicitly separates the defining core (board, card, position-as-state) from standard and optional capabilities. (3) target design inference = every statement about the local Python/SQLite target in this blueprint, including the data model, the API surface, the validation bounds, the error codes, the UI and the probe, is my own design derived from the pinned scenario plus the leaf's defining core; it is not an upstream capability and upstream code was not copied. (4) not_run upstream status = the pinned Kanboard snapshot was read as text only; it was never installed, started or exercised, so no upstream runtime behaviour, upstream database schema or upstream performance figure is asserted anywhere here. The target's own runtime verification is likewise not_run: no server was started and no probe case was executed while writing this blueprint. Upstream-only concepts visible in the evidence (swimlanes, task_limit as a WIP cap, tags, score, priority, recurrence counters, bulk creation, project-role permissions, markdown tooltips) were read as evidence of the category's standard capabilities and are deliberately kept out of the target P0; the target rejects them at the API boundary instead of ignoring them.

MIT

https://github.com/kanboard/kanboard/blob/e4fb64e972b0ae255a92cf4b7b03489846ebbffc/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## 待验证

- 辅助静态独审通过，不代表运行通过
- 上游not_run
- Runtime verification status: not_run. No target server was started, no HTTP request was issued and no probe case was executed while producing this blueprint; the acceptance criteria state what must hold, not what was observed.
- Upstream status: not_run. The pinned Kanboard snapshot was read as source text only - it was not installed, started or exercised - so no upstream runtime behaviour, upstream database schema or upstream performance characteristic is asserted here.
- Only the eight pinned upstream files were read; the rest of the upstream tree (routing, migrations, templates, tests) is outside the evidence set, so claims about upstream beyond these files are not made.
- Restart durability is specified but not demonstrated: the probe cannot stop or start the server, so the cross-process restart check exists only as an operator procedure in README.md and is not claimed as executed.
- The probe compares API-level shapes only; it asserts nothing about the HTML surface, so the accessibility, Post/Redirect/Get and focus requirements of the UI are reviewed by hand rather than machine-checked.
- Drag-and-drop is deliberately out of P0: the UI exposes movement through buttons and a select, so pointer-only drag affordances, live drag feedback and cross-column drag previews are not covered.
- The target stores no due dates, recurrence rules, assignees, labels, priorities, attachments, comments, checklists, activity history or archive, so the leaf's 'card detail' and 'standard capabilities' layers are absent by design in P0.
- Deletion is destructive without archive or undo, so a mistaken board deletion cannot be recovered in this P0 build (decision D5).
- The HTTP server is single-threaded and the probe runs sequentially, so concurrent writers, lock contention and busy_timeout behaviour are not exercised.
- No authentication, TLS, per-board permissions or multi-user isolation: the process must stay on the loopback interface.
- Column rename has no per-column history and card edits record no change log, so 'the position confirmed in the card's history' from the leaf is not implemented in P0.
- The upstream MIT licence covers the pinned reference files only; no upstream source was copied into the target, and a file-level licence audit of the upstream tree was not performed.
