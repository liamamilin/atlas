# 辅助试用范围

Deliver a localhost-only, single-user, Python-stdlib web application that persists named boards, user-named ordered columns and ordered cards (title + short description) in one SQLite file, treats a card's column membership as the card's state (no separate status field), supports column add/rename/reorder and card move/reorder, shows every column's full card list with per-column counts, and reads the whole structure back unchanged after a restart. P0 explicitly excludes accounts, collaboration, a separate status field, WIP limits, notifications, time reports and automation, and those concepts are rejected at the API boundary rather than merely omitted.

- Runtime verification status: not_run. No target server was started, no HTTP request was issued and no probe case was executed while producing this blueprint; the acceptance criteria state what must hold, not what was observed.
- Upstream status: not_run. The pinned Kanboard snapshot was read as source text only - it was not installed, started or exercised - so no upstream runtime behaviour, upstream database schema or upstream performance characteristic is asserted here.
- Only the eight pinned upstream files were read; the rest of the upstream tree (routing, migrations, templates, tests) is outside the evidence set, so claims about upstream beyond these files are not made.
- Restart durability is specified but not demonstrated: the probe cannot stop or start the server, so the cross-process restart check exists only as an operator procedure in README.md and is not claimed as executed.
- The probe compares API-level shapes only; it asserts nothing about the HTML surface, so the accessibility, Post/Redirect/Get and focus requirements of the UI are reviewed by hand rather than machine-checked.
- Drag-and-drop is deliberately out of P0: the UI exposes movement through buttons and a select, so pointer-only drag affordances, live drag feedback and cross-column drag previews are not covered.
- The target stores no due dates, recurrence rules, assignees, labels, priorities, attachments, comments, checklists, activity history or archive, so the leaf's 'card detail' and 'standard capabilities' layers are absent by design in P0.
- Deletion is destructive without archive or undo, so a mistaken board deletion cannot be recovered in this P0 build (decision D5).
- The HTTP server is single-threaded and the probe runs sequentially, so concurrent writers, lock contention and busy_timeout behaviour are not exercised.
- No authentication, TLS, per-board permissions or multi-user isolation: the process must stay on the loopback interface.
- Column rename has no per-column history and card edits record no change log, so 'the position confirmed in the card's history' from the leaf is not implemented in P0.
- The upstream MIT licence covers the pinned reference files only; no upstream source was copied into the target, and a file-level licence audit of the upstream tree was not performed.

OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。模板先于应用；仅代表场景后续开发应用。严格G1/T08不因本包通过。