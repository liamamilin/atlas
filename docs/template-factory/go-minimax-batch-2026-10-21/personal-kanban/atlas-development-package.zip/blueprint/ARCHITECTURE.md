# 架构与契约

# Architecture - Personal Project Board (个人小项目看板)

## 1. Scope and non-goals
P0 scope: one local, single-user process that stores named boards; every board holds user-named columns in a user-defined order; every column holds ordered cards; a card carries a title and a short description; a card's column membership IS its state; column order and card order are persisted and shown; the whole structure is read back unchanged after a restart.

Rejected at the API boundary (422 FORBIDDEN_FIELD) and absent from the schema: accounts and login, roles and permissions, multi-user collaboration, a separate status/state field, WIP limits, swimlanes, due/start dates, recurrence, notifications, time tracking and reports, automation, templates, search/filter, archive, secondary views, external integrations.

## 2. Runtime, files and start instructions
- Python 3.9+, standard library only (http.server, sqlite3, json, urllib.parse, argparse).
- Start: `python3 app.py --host 127.0.0.1 --port 8765 --data-dir ./data`
  - `--host` default 127.0.0.1 (loopback only), `--port` default 8765, `--data-dir` default ./data.
  - Env override: `PERSONAL_KANBAN_DATA_DIR`.
  - Startup order: create the data directory if missing; open `<data-dir>/kanban.sqlite3`; apply the schema with `CREATE TABLE IF NOT EXISTS` (PRAGMA user_version = 1); `PRAGMA foreign_keys=ON`, `PRAGMA journal_mode=WAL`, `PRAGMA busy_timeout=5000`; print `Personal Project Board listening on http://127.0.0.1:8765/`.
  - Shutdown: SIGINT / Ctrl-C closes the connection and checkpoints the WAL; committed data is not lost.
- Target file layout: `app.py`, `personal_board/db.py` (schema and connection), `personal_board/service.py` (transactional domain logic), `personal_board/api.py` (JSON endpoints), `personal_board/web.py` (HTML endpoints), `personal_board/server.py` (router), `probe.py`, `README.md`.
- Storage: exactly one SQLite file `<data-dir>/kanban.sqlite3` (plus `-wal` / `-shm` sidecars). No other state is kept in memory across restarts.
- No authentication and no TLS: the process binds loopback only and is single-user (decision D1).

## 3. Data model (SQLite, one file, PRAGMA user_version = 1)
boards
  id          INTEGER PRIMARY KEY AUTOINCREMENT
  name        TEXT    NOT NULL   -- trimmed, 1..120 chars
  created_at  INTEGER NOT NULL   -- UTC epoch seconds
  updated_at  INTEGER NOT NULL

columns
  id          INTEGER PRIMARY KEY AUTOINCREMENT
  board_id    INTEGER NOT NULL REFERENCES boards(id) ON DELETE CASCADE
  name        TEXT    NOT NULL   -- trimmed, 1..120 chars, unique per board (case-insensitive)
  position    INTEGER NOT NULL   -- 1..N inside the board
  created_at  INTEGER NOT NULL
  updated_at  INTEGER NOT NULL
  UNIQUE (board_id, position)

cards
  id          INTEGER PRIMARY KEY AUTOINCREMENT
  board_id    INTEGER NOT NULL REFERENCES boards(id) ON DELETE CASCADE
  column_id   INTEGER NOT NULL REFERENCES columns(id) ON DELETE CASCADE
  position    INTEGER NOT NULL   -- 1..N inside the column
  title       TEXT    NOT NULL   -- trimmed, 1..200 chars
  description TEXT    NOT NULL DEFAULT ''   -- 0..500 chars
  created_at  INTEGER NOT NULL
  updated_at  INTEGER NOT NULL
  moved_at    INTEGER NOT NULL   -- last time the card changed column or position
  UNIQUE (column_id, position)

Invariants after every committed write:
- the columns of a board form exactly the permutation 1..N of their positions;
- the cards of a column form exactly the permutation 1..N of their positions;
- a card's board_id always equals the board_id of its column;
- no status, state, priority, assignee, date or recurrence column exists anywhere.

## 4. HTTP API (JSON, UTF-8, Content-Type application/json)
Error envelope for every non-2xx answer:
  {"error": {"code": "POSITION_OUT_OF_RANGE", "message": "position must be between 1 and 3", "field": "position", "details": {"min": 1, "max": 3}}}

Health
  GET /api/health -> 200 {"status": "ok", "schema_version": 1, "data_dir": "/abs/path"}

Boards
  GET /api/boards -> 200 {"boards": [{"id": 1, "name": "Home", "created_at": 1760000000, "updated_at": 1760000000, "column_count": 3, "card_count": 4}]}
  POST /api/boards
    request  {"name": "Home", "columns": ["待办", "进行中"]}   # name required, columns optional
    response 201 {"board": {"id": 1, "name": "Home", "created_at": ..., "updated_at": ..., "column_count": 2, "card_count": 0},
                   "columns": [{"id": 1, "name": "待办", "position": 1, "card_count": 0, "created_at": ..., "updated_at": ...}]}
  GET /api/boards/{board_id} -> 200
    {"board": {"id": 1, "name": "Home", "created_at": ..., "updated_at": ..., "column_count": 2, "card_count": 3},
     "columns": [{"id": 1, "name": "待办", "position": 1, "card_count": 2,
                  "cards": [{"id": 11, "board_id": 1, "column_id": 1, "position": 1, "title": "...", "description": "...",
                             "created_at": ..., "updated_at": ..., "moved_at": ...}]}]}
  PATCH /api/boards/{board_id} request {"name": "..."} -> 200 {"board": {...}}
  DELETE /api/boards/{board_id} -> 204 (cascades to that board's columns and cards)

Columns
  POST /api/boards/{board_id}/columns request {"name": "..."} -> 201 {"column": {"id": 3, "board_id": 1, "name": "...", "position": 3, "card_count": 0, "created_at": ..., "updated_at": ...}}
  GET /api/columns/{column_id} -> 200 {"column": {...}}
  PATCH /api/columns/{column_id} request {"name": "..."} -> 200 {"column": {...}}
  PUT /api/columns/{column_id}/position request {"position": 2} -> 200
    {"column": {...}, "columns": [{"id": 1, "name": "待办", "position": 1}, {"id": 3, "name": "完成", "position": 2}]}
  DELETE /api/columns/{column_id} -> 204 | 409 COLUMN_NOT_EMPTY | 409 LAST_COLUMN

Cards
  POST /api/boards/{board_id}/cards
    request  {"title": "...", "description": "...", "column_id": 1, "position": 2}
             # title and column_id required; description optional (default ""); position optional (default: append at the bottom)
    response 201 {"card": {"id": 11, "board_id": 1, "column_id": 1, "position": 2, "title": "...", "description": "...", "created_at": ..., "updated_at": ..., "moved_at": ...}}
  GET /api/cards/{card_id} -> 200 {"card": {...}}
  PATCH /api/cards/{card_id} request {"title": "...", "description": "..."} -> 200 {"card": {...}}
  POST /api/cards/{card_id}/move request {"column_id": 2, "position": 1} -> 200
    {"card": {...},
     "columns": [{"id": 1, "name": "待办", "position": 1, "card_count": 1, "card_ids": [12]},
                 {"id": 2, "name": "进行中", "position": 2, "card_count": 2, "card_ids": [11, 13]}]}
  DELETE /api/cards/{card_id} -> 204

## 5. Validation bounds, allowed keys and error codes
Field bounds
  board.name          trimmed, 1..120 chars            -> 422 NAME_REQUIRED / NAME_TOO_LONG
  column.name         trimmed, 1..120 chars            -> 422 NAME_REQUIRED / NAME_TOO_LONG
  column.name         unique per board, case-insensitive-> 409 DUPLICATE_COLUMN_NAME
  card.title          trimmed, 1..200 chars            -> 422 TITLE_REQUIRED / TITLE_TOO_LONG
  card.description    0..500 chars, default ""        -> 422 DESCRIPTION_TOO_LONG
  card.column_id      required on create               -> 422 COLUMN_REQUIRED
                      must exist                       -> 404 COLUMN_NOT_FOUND
                      must belong to the board in the path -> 422 COLUMN_BOARD_MISMATCH
  card.position       optional on create, 1..(count+1) -> 422 POSITION_OUT_OF_RANGE
  move.position       1..(target count after removal + 1) -> 422 POSITION_OUT_OF_RANGE
  column.position     1..number of columns of the board-> 422 POSITION_OUT_OF_RANGE

Allowed request keys (any other key is rejected)
  POST /api/boards                 name, columns
  PATCH /api/boards/{id}           name
  POST /api/boards/{id}/columns    name
  PATCH /api/columns/{id}          name
  PUT  /api/columns/{id}/position   position
  POST /api/boards/{id}/cards      title, description, column_id, position
  PATCH /api/cards/{id}            title, description
  POST /api/cards/{id}/move        column_id, position

Forbidden keys (P0 guard, checked before any write) -> 422 FORBIDDEN_FIELD:
  status, state, workflow_status, is_active, closed, completed, archived,
  assignee, owner, owner_id, member, members, priority, score, tags, tag, label, labels,
  color, color_id, due_date, date_due, start_date, date_started, deadline, end_date,
  recurrence, recurrence_status, recurrence_trigger, recurrence_factor, recurrence_timeframe,
  recurrence_basedate, repeat, every, remind, reminder, notification, notifications, notify,
  wip_limit, task_limit, limit, swimlane, swimlane_id, time_estimated, time_spent, duration,
  estimate, checklist, checklists, comment, comments, attachment, attachments, subtask, subtasks,
  template, templates, rule, rules, automation, external_id, external_provider, email, password,
  username, role, roles, permission, permissions, created_at, updated_at, moved_at
  Any other unknown key -> 422 UNKNOWN_FIELD.
  column_id inside PATCH /api/cards/{id} -> 422 COLUMN_CHANGE_REQUIRES_MOVE.
  position inside PATCH /api/cards/{id} -> 422 POSITION_CHANGE_REQUIRES_MOVE.

HTTP status codes
  200 OK, 201 Created, 204 No Content, 303 See Other (UI redirect),
  400 MALFORMED_JSON (body is not valid JSON) / 400 INVALID_BODY (body is not a JSON object),
  404 NOT_FOUND (unknown route), 404 BOARD_NOT_FOUND, 404 COLUMN_NOT_FOUND, 404 CARD_NOT_FOUND,
  405 METHOD_NOT_ALLOWED (with an Allow header),
  409 DUPLICATE_COLUMN_NAME, 409 COLUMN_NOT_EMPTY, 409 LAST_COLUMN,
  422 NAME_REQUIRED, NAME_TOO_LONG, TITLE_REQUIRED, TITLE_TOO_LONG, DESCRIPTION_TOO_LONG,
      COLUMN_REQUIRED, POSITION_OUT_OF_RANGE, FORBIDDEN_FIELD, UNKNOWN_FIELD,
      COLUMN_CHANGE_REQUIRES_MOVE, POSITION_CHANGE_REQUIRES_MOVE, COLUMN_BOARD_MISMATCH,
  500 INTERNAL_ERROR (transaction rolled back, nothing written)

## 6. Ordering rules and atomic failure semantics
Ordering
- The columns of a board are ordered by position ascending; positions are a contiguous 1..N.
- The cards of a column are ordered by position ascending; positions are a contiguous 1..N.
- Card creation without `position` appends at the bottom of the column; with `position` the card is inserted at that slot and the column is renumbered around it.
- Move: POST /api/cards/{id}/move with (column_id, position) puts the card in the 1-based slot `position` of the target column and removes it from the source column; the source column is renumbered to 1..(M-1) and the target column to 1..N in the same transaction. The board's total card count never changes.
- Column reorder: PUT /api/columns/{id}/position with 1 <= position <= number of columns of the board; the other columns shift and all are renumbered to 1..N.
- Deleting a column removes it and renumbers the remaining columns of that board to 1..N.

Atomicity
- Every mutating request runs inside exactly one SQLite transaction (BEGIN IMMEDIATE ... COMMIT); there is no multi-transaction request.
- Validation runs before the transaction opens. A rejected request opens no transaction and writes nothing (the zero-write guarantee the probe checks).
- Any exception during the write phase rolls the transaction back: the database is exactly as it was before the request and the client receives 500 INTERNAL_ERROR. A move that fails half way cannot leave a half-renumbered column.
- Position rewrites are staged inside the same transaction: the affected rows first receive temporary negative positions (`-id`), then the final 1..N positions are assigned. The UNIQUE (board_id, position) and UNIQUE (column_id, position) constraints are therefore never violated mid-flight and no intermediate order is observable.
- Deleting a board cascades to its columns and cards in the same transaction.
- No partial success is possible: a request either commits every row it touched or none.

## 7. Dates, timestamps and recurrence
- The only dates in the target are the three server-set integers created_at, updated_at, moved_at on boards, columns and cards. Unit: UTC epoch seconds, resolution 1 second.
- Clients never supply timestamps; created_at, updated_at and moved_at are in the forbidden key list and are rejected with 422 FORBIDDEN_FIELD.
- updated_at is bumped on every accepted change of that record and is non-decreasing (>=) because of the 1-second resolution; updated_at >= created_at always holds. moved_at changes only when a card changes column or position, so a plain edit leaves moved_at untouched and a move sets moved_at >= created_at.
- The target stores NO due date, start date or deadline, and NO recurrence rule (P0 excludes both). The recurrence rule of this target is therefore: none exists and none can be created - every date or recurrence key (due_date, date_due, start_date, date_started, deadline, end_date, recurrence, recurrence_status, recurrence_trigger, recurrence_factor, recurrence_timeframe, recurrence_basedate, repeat, every, remind, reminder) is rejected with 422 FORBIDDEN_FIELD before any write. Upstream Kanboard does carry recurrence fields; they are deliberately not carried over (decision D4).

## 8. UI (server-rendered HTML, no JavaScript required)
- GET / - boards home: a list of boards (name, column count, card count) and a create-board form (name plus optional one-column-per-line column names).
- GET /board/{id} - the board surface: columns left to right; each column shows its name, its card count and its cards top to bottom (title and short description), with a card form, a rename form, reorder buttons and a delete button; each card shows an edit form, up/down buttons, a move-to-column select and a delete button.
- All UI mutations are HTML forms POSTing to `/ui/...` handlers and answered with `303 See Other` back to the referring page (Post/Redirect/Get). The UI and the JSON API share one service layer, so both obey the same validation, ordering and transaction rules.
- UI routes: POST /ui/boards, POST /ui/boards/{id}/rename, POST /ui/boards/{id}/delete, POST /ui/boards/{id}/columns, POST /ui/columns/{id}/rename, POST /ui/columns/{id}/position, POST /ui/columns/{id}/delete, POST /ui/boards/{id}/cards, POST /ui/cards/{id}/update, POST /ui/cards/{id}/move, POST /ui/cards/{id}/delete.
- Accessibility: `<!DOCTYPE html>` with lang="zh-CN"; one `<h1>` per page; `<header>`, `<nav>` and `<main>` landmarks; every input has a `<label for>`; `required` and `maxlength` on inputs; every action is a `<button type="submit">` (no click-only controls); cards are `<ol>` items so the sequence is announced; each column is an `<h2>` section whose heading text carries the count; results and errors are announced in a `<div role="status">` / `role="alert">` region after the redirect; a visible focus outline is kept; state is never conveyed by colour alone (the column name carries it); every move is reachable from the keyboard via up/down buttons and a select, so there is no drag-only interaction.

## 9. Acceptance mapping (probe.py --case A01..A05)
  A01 boards            -> feature 1: create/list/read/rename/delete + 7 rejected writes, each followed by a zero-write re-read
  A02 columns           -> feature 2: seed/add/rename/reorder, delete guards, 7 rejected writes with zero-write re-reads
  A03 cards             -> feature 3: create/read/edit, 12 rejected writes with a full board-state comparison before and after
  A04 movement          -> feature 4: cross-column move, in-column reorder, out-of-range/unknown/cross-board rejections, board total unchanged
  A05 read model        -> feature 5: exact per-column card lists, counts, contiguous positions, stable second read, date edges
  Each case creates its own disposable board and deletes only the records it created; a restart check is an operator procedure in README.md because the probe cannot stop or start the server.

## 10. Decision points for the user (change before building if you disagree)
  D1 loopback-only binding with no authentication (single-user local tool); exposing the port to a LAN would give every reachable host full write access.
  D2 a new board starts with zero columns; optional `columns: [...]` seeds user-named columns; there are no hidden default columns and no implicit first column.
  D3 column names are unique per board (case-insensitive); card titles may repeat.
  D4 no dates and no recurrence at all - rejected with FORBIDDEN_FIELD rather than accepted and ignored.
  D5 deletion is destructive and unarchived: a column must be empty, a board must keep one column, deleting a board cascades; there is no undo.
  D6 movement is a dedicated endpoint (POST /api/cards/{id}/move); PATCH on a card can change only title and description.
  D7 UI labels in zh-CN, API keys and error codes in English.
  D8 no drag-and-drop JavaScript in P0; a later drag layer can reuse the same move endpoint without an API change.
