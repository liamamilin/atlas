# 决策与默认值

## D01 · 首版运行与数据边界？

单用户本机、独立SQLite；显式保存，无账户、云端和协作。

When to ask / 询问条件: 确需公网托管或多人数据时先确认，不自行扩展。

保护本地数据，避免默认外发。

assisted default

## D02 · 是否复刻上游？

Evidence classes are kept separate. (1) code_observation = behaviour read directly from the pinned upstream files at the cited lines (for example upstream renumbers a column around a moved card inside one transaction, upstream bounds a column reorder by the number of columns, upstream renders a per-column task count). (2) documentation = claims read from upstream README.md and LICENSE and from leaf.md; leaf.md describes the Kanban Task Board type in general terms and explicitly separates the defining core (board, card, position-as-state) from standard and optional capabilities. (3) target design inference = every statement about the local Python/SQLite target in this blueprint, including the data model, the API surface, the validation bounds, the error codes, the UI and the probe, is my own design derived from the pinned scenario plus the leaf's defining core; it is not an upstream capability and upstream code was not copied. (4) not_run upstream status = the pinned Kanboard snapshot was read as text only; it was never installed, started or exercised, so no upstream runtime behaviour, upstream database schema or upstream performance figure is asserted anywhere here. The target's own runtime verification is likewise not_run: no server was started and no probe case was executed while writing this blueprint. Upstream-only concepts visible in the evidence (swimlanes, task_limit as a WIP cap, tags, score, priority, recurrence counters, bulk creation, project-role permissions, markdown tooltips) were read as evidence of the category's standard capabilities and are deliberately kept out of the target P0; the target rejects them at the API boundary instead of ignoring them.

When to ask / 询问条件: 目标变化、破坏已有数据或需要引入上游实现/依赖时先确认。

不混淆来源事实与目标设计。

assisted default
