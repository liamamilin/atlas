## workflow

### 0
"1. Operator starts the process with `python3 app.py --data-dir ./data --host 127.0.0.1 --port
8765`; the data directory and the SQLite file are created on first run and the startup banner prints
the local URL."

### 1
"2. The user opens `GET /` (boards home) and creates a named board, optionally seeding user-named
columns (for example 待办 / 进行中 / 完成) in one step; the board is stored with zero hidden default
columns."

### 2
"3. The user adds further columns, renames a column in place, and reorders columns to match the real
workflow; the column order is stored as a contiguous 1..N position sequence and is always rendered
left to right."

### 3
"4. The user creates a card with a title and a short description inside a chosen column; the card is
appended at the bottom of that column unless an explicit slot is given."

### 4
"5. The user edits a card's title or description; editing never changes the card's column, position
or moved timestamp."

### 5
"6. The user moves a card to another column (this is the state change - there is no status field)
and reorders cards inside a column; the source column and target column are renumbered to contiguous
1..N in one transaction."

### 6
"7. The user reads the board surface: columns left to right, each column showing its full ordered
card list and its card count, with the board total equal to the sum of the column counts."

### 7
"8. The user restarts the process against the same `--data-dir` and sees the same boards, the same
column order and the same card order, because every write is committed to `<data-
dir>/kanban.sqlite3`."

### 8
"9. The acceptance probe (one disposable board per case, deleting only what it created) exercises
the same journey over the JSON API and asserts the zero-write behaviour of every rejected request."

## acceptance

### 0
"The probe runs against a live target with `python3 probe.py --base-url http://127.0.0.1:8765 --case
A01` (or `--case all`, repeatable `--case` flags) and exits 0 only when every selected case passes;
the five cases A01..A05 map one-to-one onto the five features."

### 1
"A01 proves board behaviour: POST /api/boards creates exactly one board (201 with id, name,
created_at, updated_at, column_count, card_count), GET /api/boards grows by exactly one entry and
carries the same name and counts, GET /api/boards/{id} returns the same board with an empty column
list, PATCH renames without changing the id, and DELETE removes exactly that board."

### 2
"A02 proves column behaviour: seeded columns keep their names and order with positions 1..3, a new
column is appended at position 4, a rename keeps the position, a reorder persists the new order with
positions exactly 1..4 and names still attached to the same ids, and deleting an empty column
renumbers the remaining columns to 1..N."

### 3
"A03 proves card behaviour: a card is created with title, description, column and position 1, a
second card gets position 2, the board's card_count and the per-column card_count equal the real
number of cards, and PATCH changes only title/description (position, column and moved_at
unchanged)."

### 4
"Every rejected request in A01..A04 is followed by a re-read that proves zero writes: the
board/column/card counts, the column order, the card order, the card positions and each card's
updated_at are byte-for-byte the same before and after the rejection (board_state() comparison)."

### 5
"Negative cases are exact: blank or over-long name, blank or over-long title, over-long description,
missing column, unknown column (404 COLUMN_NOT_FOUND), a column of another board (422
COLUMN_BOARD_MISMATCH), position 0 or position beyond the last slot (422 POSITION_OUT_OF_RANGE),
duplicate column name (409 DUPLICATE_COLUMN_NAME), deleting a non-empty column (409
COLUMN_NOT_EMPTY), deleting the last column (409 LAST_COLUMN), malformed JSON body (400
MALFORMED_JSON), and forbidden P0 keys such as status, assignee, due_date, recurrence_trigger,
task_limit (422 FORBIDDEN_FIELD) or colour (422 UNKNOWN_FIELD)."

### 6
"A04 proves position-as-state: moving a card to another column renumbers the source column to 1..M-1
and the target column to 1..N, an in-column reorder swaps the two cards and their positions, the
board's total card count is unchanged by every move, moved_at never precedes created_at, and a no-op
move leaves the column order untouched."

### 7
"A05 proves the read model and the date edges: GET /api/boards/{id} returns the columns in position
order, each with its full ordered card list, a card_count equal to the length of that list,
contiguous card positions starting at 1, a board card_count equal to the sum of the column counts,
the expected exact set of card titles per column, an identical snapshot on a second read, and
created_at <= updated_at and created_at <= moved_at for every card inside the probe's write window."

### 8
"Cross-process restart durability is specified in README.md as an operator procedure (stop the
process, start it again with the same --data-dir, re-read the board) because the probe cannot stop
or start the server; the blueprint claims that step was not executed, and the whole runtime
verification of this target is not_run."

### 9
"The probe only uses records it created in its own disposable board and deletes only those records;
it never deletes pre-existing user data, and it asserts only behaviour documented in this
architecture - no upstream Kanboard behaviour is asserted."

## observations

### 0
["documentation", "README.md", 4, 14, "Upstream README describes Kanboard as project management
software that focuses on the Kanban methodology and states the application is in maintenance mode:
the author is not actively developing any new major features, only small fixes are made, and pull
requests for new features and bug fixes are accepted."]

### 1
["documentation", "README.md", 19, 27, "Upstream README links the official website, a feature list,
the change log, a forum and the documentation pages for requirements, installation, upgrade and
Docker use, i.e. upstream is a full server product with its own documentation and deployment story,
not a local single-user tool."]

### 2
["documentation", "README.md", 29, 34, "Upstream README names Frederic Guillot as main developer,
points at the contributor list and states that the project is distributed under the MIT License."]

### 3
["documentation", "LICENSE", 1, 21, "The pinned upstream LICENSE is the MIT License (MIT), copyright
(c) Frederic Guillot, with the standard grant, the notice requirement and the warranty disclaimer."]

### 4
["code_observation", "app/Model/ColumnModel.php", 183, 195, "Upstream create() persists a new column
for a project with title, task_limit (a WIP cap), description and hide_in_dashboard, and sets
position to getLastColumnPosition(project_id) + 1, so a newly added column is appended at the end of
the board rather than inserted at an arbitrary slot."]

### 5
["code_observation", "app/Model/ColumnModel.php", 208, 216, "Upstream update() rewrites the column
title, task_limit, hide_in_dashboard and description in place and never touches the column position,
so renaming a column is independent of the column order."]

### 6
["code_observation", "app/Model/ColumnModel.php", 239, 261, "Upstream changePosition() rejects a
position below 1 or above the number of columns of the project, then renumbers the sibling columns
ascending by their current position and finally writes the requested position on the moved column,
returning false if any single update fails - reordering is a bounded, all-or-nothing rewrite of the
sibling positions."]

### 7
["code_observation", "app/Model/ColumnModel.php", 118, 121, "Upstream getAll() returns the columns
of a project ordered ascending by position, which is the mechanism behind the left-to-right column
order of the board surface."]

### 8
["code_observation", "app/Model/ColumnModel.php", 147, 156, "Upstream getAllWithTaskCount() returns
the columns ordered by position together with a per-column count of open tasks (is_active='1') and
of closed tasks (is_active='0'), i.e. upstream derives the column card counts from the task table
itself."]

### 9
["code_observation", "app/Model/ColumnModel.php", 225, 228, "Upstream remove() deletes a column row
by id and its docblock states that the column and all associated tasks are removed, so upstream
column deletion is destructive rather than a move of the cards elsewhere."]

### 10
["code_observation", "app/Model/TaskPositionModel.php", 66, 97, "Upstream movePosition() returns
false for a position below 1, resolves the swimlane when none is given, skips closed tasks when
onlyOpen is set, and then dispatches to exactly one of three branches - swimlane change, column
change or same-column position change - so a card's placement is the only way its location
changes."]

### 11
["code_observation", "app/Model/TaskPositionModel.php", 177, 215, "Upstream saveTaskPositions()
lists the other tasks of the same column ordered by position then id, inserts the moved task when
the requested position equals the running offset, rewrites every other task's position, and finally
places the task at the bottom while normalising a bad position - the whole column is renumbered
around the moved card."]

### 12
["code_observation", "app/Model/TaskPositionModel.php", 112, 121, "Upstream saveSwimlaneChange()
performs the source-column rewrite, the target-column rewrite and the timestamp update inside one
database transaction and returns the conjunction of the three results, i.e. a move commits as a
single all-or-nothing unit."]

### 13
["code_observation", "app/Model/TaskPositionModel.php", 135, 144, "Upstream saveColumnChange()
applies the same transaction pattern for a move between two columns: clear the source column, fill
the target column, update the timestamps, and report success only when all three writes succeeded."]

### 14
["code_observation", "app/Model/TaskPositionModel.php", 244, 258, "Upstream saveTaskPosition()
cancels the surrounding transaction when the row update affects no rows, which is how a failed mid-
move write aborts the whole move instead of leaving a half-renumbered column."]

### 15
["code_observation", "app/Model/TaskPositionModel.php", 15, 51, "Upstream moveBottom() computes
MAX(position)+1 over the tasks of the target column and writes column_id, position, date_moved and
date_modification, so appending a card to a column is a position write and not a separate status
flag."]

### 16
["code_observation", "app/Model/TaskPositionModel.php", 269, 313, "Upstream fireEvents() emits a
distinct event for a swimlane change, a column change or a position change and carries
src_column_id, dst_column_id, date_moved and the task's recurrence fields; in upstream the move is
the state-change event of the card."]

### 17
["code_observation", "app/Model/TaskCreationModel.php", 61, 93, "Upstream prepare() defaults an
empty column_id to the first column of the project, defaults an empty title to 'Untitled', stamps
date_creation, date_modification and date_moved with the current time and computes position as the
number of tasks in the column plus one."]

### 18
["code_observation", "app/Model/TaskCreationModel.php", 22, 53, "Upstream create() persists the task
row first and only afterwards calls movePosition() when an explicit position greater than one was
requested, i.e. inserting a card at a chosen slot is a create step followed by a position step."]

### 19
["code_observation", "app/Model/TaskModificationModel.php", 23, 41, "Upstream update() applies the
changed fields to the task row and fires the modification events only when the write succeeded; the
card's text fields are edited independently of its column and position."]

### 20
["code_observation", "app/Model/TaskModificationModel.php", 105, 117, "Upstream prepare() converts
date_due and date_started through the date parser, removes the id field, resets the date, score and
time fields and stamps date_modification - upstream tasks carry due/start dates and recurrence
counters, which the pinned P0 scenario deliberately excludes."]

### 21
["code_observation", "app/Controller/TaskMovePositionController.php", 33, 52, "Upstream
TaskMovePositionController::save() reads a JSON body with column_id, position and swimlane_id,
checks a move permission on the project role, calls movePosition() with the project id, the task id
and those three values, and then redirects back to the task view."]

### 22
["code_observation", "app/Template/board/table_column.php", 5, 27, "The upstream board template
renders one table header cell per column carrying data-column-id, the escaped column title and a
per-column dropdown, so the column order of the board surface is exactly the column position
order."]

### 23
["code_observation", "app/Template/board/table_column.php", 88, 120, "The upstream column header
renders the score, the visible task count and - when a task_limit is set - the total across
swimlanes, i.e. upstream already shows a per-column card count next to the column title."]

### 24
["code_observation", "app/Template/board/table_column.php", 105, 119, "The upstream task count block
is rendered only when the count is non-empty and is preceded by an ui-helper-hidden-accessible 'Task
count' text, i.e. upstream labels the column count for assistive technology."]

### 25
["code_observation", "app/Template/board/table_column.php", 39, 43, "The upstream column dropdown
offers 'Close all tasks in this column and this swimlane' only when the column holds tasks, showing
that upstream treats the column as the container whose content can be closed in bulk - a batch
operation outside the pinned P0 scenario."]

## features

### 0
"Named boards with durable local storage (create, list, read, rename, delete)"

### 1
"User-named ordered columns (add, rename, reorder, guarded delete)"

### 2
"Cards with a title and a short description (create, read, edit)"

### 3
"Movement as state: cross-column move and in-column reorder with contiguous renumbering"

### 4
"Board read model: columns in order, full per-column card lists and per-column counts"

## goals

### 0
"A POST /api/boards with a 1..120 character name creates exactly one board row and answers 201 with
id, name, created_at, updated_at, column_count and card_count; GET /api/boards then lists that board
once with the same counts, GET /api/boards/{id} returns the same board with an empty column list,
and after the process is restarted with the same --data-dir the same board id, name and counts are
read back unchanged."

### 1
"Columns can be appended, renamed in place and reordered: after every accepted change the board's
columns are exactly the contiguous permutation 1..N of their positions, GET /api/boards/{id} returns
them in that order with every name still attached to the same column id, deleting an empty column
renumbers the remaining columns to 1..N, and deleting a non-empty column (409 COLUMN_NOT_EMPTY) or
the last column of a board (409 LAST_COLUMN) is rejected without writing."

### 2
"A card can be created in a chosen column with a required title of 1..200 characters and an optional
description of at most 500 characters, is appended at the bottom of that column unless an explicit
slot is requested, and PATCH can change only the title and the description - never the column, the
position or moved_at; a rejected card write (blank or over-long title, over-long description,
missing or unknown column, forbidden key such as status, due_date or recurrence_trigger, unknown key
such as colour) leaves the card set, the card order, the per-column counts and every card's
updated_at exactly unchanged."

### 3
"POST /api/cards/{id}/move with (column_id, position) places the card in the 1-based slot position
of the target column, renumbers the source column to 1..M-1 and the target column to 1..N inside one
transaction, keeps the board's total card count unchanged and bumps moved_at, while an out-of-range
position, an unknown column, a column belonging to another board and an unknown card are all
rejected without any write."

### 4
"GET /api/boards/{id} returns the board, its columns in position order and for every column the
complete ordered list of its cards plus a card_count equal to the length of that list, so that the
column counts sum to the board card_count, every card list carries contiguous positions starting at
1, the expected card titles appear exactly in the expected columns, and two consecutive reads return
an identical snapshot."

## gaps

### 0
"Runtime verification status: not_run. No target server was started, no HTTP request was issued and
no probe case was executed while producing this blueprint; the acceptance criteria state what must
hold, not what was observed."

### 1
"Upstream status: not_run. The pinned Kanboard snapshot was read as source text only - it was not
installed, started or exercised - so no upstream runtime behaviour, upstream database schema or
upstream performance characteristic is asserted here."

### 2
"Only the eight pinned upstream files were read; the rest of the upstream tree (routing, migrations,
templates, tests) is outside the evidence set, so claims about upstream beyond these files are not
made."

### 3
"Restart durability is specified but not demonstrated: the probe cannot stop or start the server, so
the cross-process restart check exists only as an operator procedure in README.md and is not claimed
as executed."

### 4
"The probe compares API-level shapes only; it asserts nothing about the HTML surface, so the
accessibility, Post/Redirect/Get and focus requirements of the UI are reviewed by hand rather than
machine-checked."

### 5
"Drag-and-drop is deliberately out of P0: the UI exposes movement through buttons and a select, so
pointer-only drag affordances, live drag feedback and cross-column drag previews are not covered."

### 6
"The target stores no due dates, recurrence rules, assignees, labels, priorities, attachments,
comments, checklists, activity history or archive, so the leaf's 'card detail' and 'standard
capabilities' layers are absent by design in P0."

### 7
"Deletion is destructive without archive or undo, so a mistaken board deletion cannot be recovered
in this P0 build (decision D5)."

### 8
"The HTTP server is single-threaded and the probe runs sequentially, so concurrent writers, lock
contention and busy_timeout behaviour are not exercised."

### 9
"No authentication, TLS, per-board permissions or multi-user isolation: the process must stay on the
loopback interface."

### 10
"Column rename has no per-column history and card edits record no change log, so 'the position
confirmed in the card's history' from the leaf is not implemented in P0."

### 11
"The upstream MIT licence covers the pinned reference files only; no upstream source was copied into
the target, and a file-level licence audit of the upstream tree was not performed."
