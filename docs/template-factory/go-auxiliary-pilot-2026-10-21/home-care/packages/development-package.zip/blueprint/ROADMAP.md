# 阶段与验收

## P0 · 核心可用

Create the home and its equipment, define every-N-day care plans anchored to them, see exactly which tasks are due or overdue as of a date, record a completion with a note, advance the next due date from the actual completion date, and retrieve care history by home or equipment.

| 用例 | 类型 | 行为 | 执行器 |
| --- | --- | --- | --- |
| A01 | positive | In a dedicated data directory, create the single home, add an equipment record under it, and prove duplicate-home and invalid-equipment requests return 409, 422, or 404 without changing stored records. | acceptance/probe.py |
| A02 | positive | Create plans with interval_days in 1..3650 and verify GET /api/tasks/due returns the exact overdue, due, and upcoming sets at the as_of and horizon_days boundaries while invalid plans write nothing. | acceptance/probe.py |
| A03 | positive | Record a completion and note in one atomic call and verify due_on becomes max(previous last_completed_on, completed_on) plus interval_days across leap-day, month-end, and year-end examples, with invalid completions leaving no trace. | acceptance/probe.py |
| A04 | positive | Retrieve completions filtered by home and equipment in documented descending order with plan and equipment names and notes, and reject invalid filters without writes. | acceptance/probe.py |
| A05 | positive | Load GET / and assert a dependency-free, labelled, keyboard-accessible HTML shell exposes home, equipment, plan, due, completion, and history workflows, while unknown routes and methods return documented JSON errors. | acceptance/probe.py |
