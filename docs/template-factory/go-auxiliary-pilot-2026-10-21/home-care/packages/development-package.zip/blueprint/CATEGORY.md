# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_802f9221599a491781b3dafa4f27a033@1

Create the home and its equipment, define every-N-day care plans anchored to them, see exactly which tasks are due or overdue as of a date, record a completion with a note, advance the next due date from the actual completion date, and retrieve care history by home or equipment.

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_home_care_1

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/README.md · ca69a88f998dec25c1e285121e428a4f7621dc68

documentation: Document claim: micasa describes itself as home maintenance from the terminal, a local tool rather than a hosted multi-tenant service.

Apache-2.0

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S03 · ev_assisted_home_care_10

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/internal/data/store_servicelog.go · ca69a88f998dec25c1e285121e428a4f7621dc68

code_observation: Code observation: CreateServiceLog runs in a transaction, creates the service log, then syncs the parent maintenance item.

Apache-2.0

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S04 · ev_assisted_home_care_11

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/internal/data/validation.go · ca69a88f998dec25c1e285121e428a4f7621dc68

code_observation: Code observation: ComputeNextDue returns an explicit due date when set, otherwise adds interval months to the last service date.

Apache-2.0

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S05 · ev_assisted_home_care_12

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/internal/data/validation.go · ca69a88f998dec25c1e285121e428a4f7621dc68

code_observation: Code observation: AddMonths clamps the day to the target month end, avoiding the Jan 31 plus one month overflow.

Apache-2.0

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S06 · ev_assisted_home_care_13

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/internal/data/validation.go · ca69a88f998dec25c1e285121e428a4f7621dc68

code_observation: Code observation: interval parsing accepts years and months, not days.

Apache-2.0

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S07 · ev_assisted_home_care_14

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/internal/data/dashboard.go · ca69a88f998dec25c1e285121e428a4f7621dc68

code_observation: Code observation: scheduled maintenance is defined as interval months greater than zero or an explicit due date.

Apache-2.0

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S08 · ev_assisted_home_care_15

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/README.md · ca69a88f998dec25c1e285121e428a4f7621dc68

documentation: Document claim: the upstream is pure Go using SQLite and a terminal UI; this target does not copy or run that implementation.

Apache-2.0

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S09 · ev_assisted_home_care_2

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/README.md · ca69a88f998dec25c1e285121e428a4f7621dc68

documentation: Document claim: the upstream advertises schedules, due dates, and full history.

Apache-2.0

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S10 · ev_assisted_home_care_3

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/internal/data/models.go · ca69a88f998dec25c1e285121e428a4f7621dc68

code_observation: Code observation: HouseProfile stores address, year built, systems, and other attributes; no explicit multi-home ownership table is observed in the selected files.

Apache-2.0

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S11 · ev_assisted_home_care_4

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/internal/data/models.go · ca69a88f998dec25c1e285121e428a4f7621dc68

code_observation: Code observation: Appliance stores make, model, serial, warranty, and location, with no home_id field observed.

Apache-2.0

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S12 · ev_assisted_home_care_5

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/internal/data/models.go · ca69a88f998dec25c1e285121e428a4f7621dc68

code_observation: Code observation: MaintenanceItem has an optional ApplianceID, category, season, interval months, last serviced date, and due date.

Apache-2.0

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S13 · ev_assisted_home_care_6

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/internal/data/models.go · ca69a88f998dec25c1e285121e428a4f7621dc68

code_observation: Code observation: ServiceLogEntry belongs to a maintenance item and stores serviced_at, optional vendor and cost, notes, and timestamps.

Apache-2.0

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S14 · ev_assisted_home_care_7

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/internal/data/store_house.go · ca69a88f998dec25c1e285121e428a4f7621dc68

code_observation: Code observation: CreateHouseProfile counts existing profiles and rejects a second row, implementing one house profile.

Apache-2.0

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S15 · ev_assisted_home_care_8

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/internal/data/store_maintenance.go · ca69a88f998dec25c1e285121e428a4f7621dc68

code_observation: Code observation: ListMaintenanceByAppliance filters maintenance items by appliance id, showing an equipment-anchored query path.

Apache-2.0

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S16 · ev_assisted_home_care_9

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/internal/data/store_servicelog.go · ca69a88f998dec25c1e285121e428a4f7621dc68

code_observation: Code observation: syncLastServiced sets LastServicedAt to the most recent non-deleted serviced_at.

Apache-2.0

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S17 · ev_assisted_home_care_design

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/LICENSE · ca69a88f998dec25c1e285121e428a4f7621dc68

inference: Target design inference, not an upstream claim: the pinned research makes the home the subject and requires recurring work plus a durable completion record. Upstream code corroborates that abstract shape but realizes recurrence in months, keeps one house profile, links maintenance to an optional appliance, and does not show an explicit appliance-to-home foreign key in the selected files. The target therefore makes the home anchor explicit through home_id on equipment and plans, uses every-N-days recurrence from the scenario, and keeps only the home, equipment, plan, completion, and history slice. It does not copy upstream code, schema, or UI. Upstream status: not_run; no upstream build, test, server, TUI, or database was started.

Apache-2.0

https://github.com/micasa-dev/micasa/blob/ca69a88f998dec25c1e285121e428a4f7621dc68/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## 待验证

- 辅助静态独审通过，不代表运行通过
- 上游not_run
- Upstream status: not_run. The repository was read as evidence only; no build, test, server, TUI, or database was executed, so no upstream behavior is runtime-verified.
- Runtime verification is not_run for the target too. The probe and architecture are authored artifacts; no server was started and no acceptance case was executed in this task.
- Single-home and single-user by design; no multi-property, accounts, authentication, sharing, or remote access.
- No notifications, email, SMS, push, calendar sync, or background scheduler; due work is pull-based through the API and UI.
- No costs, vendors, receipts, photos, manuals, warranties, projects, quotes, incidents, documents, or LLM features; those upstream surfaces are intentionally out of scope.
- Every-N-days recurrence differs from upstream interval months; no compatibility with upstream databases, APIs, or schema is claimed.
- No delete, undo, archive, or restore endpoints; completion history is append-only and test records remain until the disposable data directory is discarded.
- Validation is strict and date-only; natural-language dates and timezone conversion are unsupported. Server local date can differ by one day from a client in another timezone.
- The UI is a minimal single-page client, not a polished product; no internationalization, offline cache, or mobile-native behavior.
- Schema v1 has no migration path. Changing entities later needs an explicit migration or a new disposable database.
- Concurrency is sized for one user; SQLite WAL and busy_timeout reduce but do not eliminate lock contention.
- User decision points: confirm one-home scope, the default due date of creation day when no anchor is provided, latest-completion rollover for backdated entries, strict date-only input, and the absence of delete and defect-tracking features.
- Restart durability may be described as an operator stop and start step in README; it was not run and is not claimed as verified.
