# 产品定义

Home Care Ledger

A single homeowner keeping care records for their own home on a local machine, with no accounts, notifications, or multi-property operation.

Create the home and its equipment, define every-N-day care plans anchored to them, see exactly which tasks are due or overdue as of a date, record a completion with a note, advance the next due date from the actual completion date, and retrieve care history by home or equipment.

1. Start the local server against a disposable data directory; initialize the SQLite schema on first start.
2. Create the single home with POST /api/home, then add equipment records with POST /api/equipment anchored by home_id.
3. Create care plans with POST /api/plans using interval_days and an optional equipment anchor.
4. Query GET /api/tasks/due with an explicit as_of and horizon_days to see overdue, due, and upcoming work.
5. Record a completion and note with POST /api/plans/{id}/completions; the same transaction updates the plan next due date.
6. Read GET /api/plans/{id}/completions or GET /api/history filtered by home_id and equipment_id.
7. Use GET / for the basic accessible single-page UI; all actions remain available through the documented JSON API.

- A fresh database has no home; POST /api/home creates exactly one record with id home, and a second POST returns 409 HOME_EXISTS without mutating the stored home.
- POST /api/equipment under the existing home returns 201 and round-trips through list and detail; blank names, invalid categories, and unknown homes return 422 or 404 and add no equipment row.
- POST /api/plans enforces interval_days 1..3650 and mutual exclusion of last_completed_on and first_due_on; GET /api/tasks/due returns exact overdue, due, and upcoming sets at as_of and horizon_days boundaries, while invalid requests write nothing.
- A completion with note inserts one history row and atomically sets due_on to max(previous last_completed_on, completed_on) plus interval_days; leap-day, month-end, year-end, future-date, oversize-note, and unknown-plan failures leave both plan and completions unchanged.
- GET /api/history filters by home and equipment and returns documented fields in descending completion order; invalid filters write nothing; GET / is dependency-free accessible HTML and unknown routes or methods return documented JSON errors.

- R01 A single homeowner keeping care records for their own home on a local machine, with no accounts, notifications, or multi-property operation.: Create the home and its equipment, define every-N-day care plans anchored to them, see exactly which tasks are due or overdue as of a date, record a completion with a note, advance the next due date from the actual completion date, and retrieve care history by home or equipment.

| ID | 能力 | 阶段 | 适用性 | 理由 | 来源 | 验收 |
| --- | --- | --- | --- | --- | --- | --- |
| F01 | Home and equipment anchor | P0 | current required | In a dedicated data directory, create the single home, add an equipment record under it, and prove duplicate-home and invalid-equipment requests return 409, 422, or 404 without changing stored records. | S01, S02, S03, S04, S05, S06, S07, S08, S09, S10, S11, S12, S13, S14, S15, S16, S17 | A01 |
| F02 | Every-N-day plan and due queue | P0 | current required | Create plans with interval_days in 1..3650 and verify GET /api/tasks/due returns the exact overdue, due, and upcoming sets at the as_of and horizon_days boundaries while invalid plans write nothing. | S01, S02, S03, S04, S05, S06, S07, S08, S09, S10, S11, S12, S13, S14, S15, S16, S17 | A02 |
| F03 | Completion and next-due rollover | P0 | current required | Record a completion and note in one atomic call and verify due_on becomes max(previous last_completed_on, completed_on) plus interval_days across leap-day, month-end, and year-end examples, with invalid completions leaving no trace. | S01, S02, S03, S04, S05, S06, S07, S08, S09, S10, S11, S12, S13, S14, S15, S16, S17 | A03 |
| F04 | Anchored care history | P0 | current required | Retrieve completions filtered by home and equipment in documented descending order with plan and equipment names and notes, and reject invalid filters without writes. | S01, S02, S03, S04, S05, S06, S07, S08, S09, S10, S11, S12, S13, S14, S15, S16, S17 | A04 |
| F05 | Accessible localhost UI | P0 | current required | Load GET / and assert a dependency-free, labelled, keyboard-accessible HTML shell exposes home, equipment, plan, due, completion, and history workflows, while unknown routes and methods return documented JSON errors. | S01, S02, S03, S04, S05, S06, S07, S08, S09, S10, S11, S12, S13, S14, S15, S16, S17 | A05 |
