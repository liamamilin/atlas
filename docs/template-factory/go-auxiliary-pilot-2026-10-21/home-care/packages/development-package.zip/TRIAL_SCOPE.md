# 辅助试用范围

Create the home and its equipment, define every-N-day care plans anchored to them, see exactly which tasks are due or overdue as of a date, record a completion with a note, advance the next due date from the actual completion date, and retrieve care history by home or equipment.

- Upstream status: not_run. The repository was read as evidence only; no build, test, server, TUI, or database was executed, so no upstream behavior is runtime-verified.
- Runtime verification is not_run for the target too. The probe and architecture are authored artifacts; no server was started and no acceptance case was executed in this task.
- Single-home and single-user by design; no multi-property, accounts, authentication, sharing, or remote access.
- No notifications, email, SMS, push, calendar sync, or background scheduler; due work is pull-based through the API and UI.
- No costs, vendors, receipts, photos, manuals, warranties, projects, quotes, incidents, documents, or LLM features; those upstream surfaces are intentionally out of scope.
- Every-N-days recurrence differs from upstream interval months; no compatibility with upstream databases, APIs, or schema is claimed.
- No delete, undo, archive, or restore endpoints; completion history is append-only and test records remain until the disposable data directory is discarded.
- Validation is strict and date-only; natural-language dates and timezone conversion are unsupported. Server local date can differ by one day from a client in another timezone.
- The UI is a minimal single-page client, not a polished product; no internationalization, offline cache, or mobile-native behavior.
- Schema v1 has no migration path. Changing entities later needs an explicit migration or a new disposable database.
- Concurrency is sized for one user; SQLite WAL and busy_timeout reduce but do not eliminate lock contention.
- User decision points: confirm one-home scope, the default due date of creation day when no anchor is provided, latest-completion rollover for backdated entries, strict date-only input, and the absence of delete and defect-tracking features.
- Restart durability may be described as an operator stop and start step in README; it was not run and is not claimed as verified.

OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。模板先于应用；仅代表场景后续开发应用。严格G1/T08不因本包通过。