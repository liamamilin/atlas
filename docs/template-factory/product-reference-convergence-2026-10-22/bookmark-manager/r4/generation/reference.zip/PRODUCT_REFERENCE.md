# Bookmark Manager — Personal Link Library

Schema: `atlas.product-reference.v1`

## Product shape

- 受众 / Audience: An individual web user who meets pages faster than they can act — product pages, tutorials, documentation, inspiration, things to buy or revisit — keeps them on purpose, and comes back weeks or months later to use them.
- 价值 / Value: A durable, private, growing library of references: every saved link points at its live web page, can be filed into a simple owner-defined collection or left in an inbox, and can be found again by browsing or searching, so the owner returns to the original page instead of searching the web for it a second time.
- 交付形态 / Delivery profile: Single-owner, local-first web application with one personal library per browser profile. No account, server, collaboration, or sharing in the modeled boundary. Upstream repository evidence is a static reading of a pinned commit that was never installed, built, or run; no runtime behavior of that implementation is claimed.
- 边界 / Boundary: One owner deliberately saves external web page addresses. Each record stores the URL plus minimal owner-editable metadata, persists across sessions in that browser profile's local storage, and sits in exactly one owner-created collection or in the default inbox. The owner browses collections, searches their own records, reorders the current result set, edits or moves a record, and opens a record to the live page in a new tab. The library keeps the reference and its metadata only; page content stays on the web and is never consumed, rendered, or archived inside the product.
- 排除项 / Excluded: Accounts, sign-in, identity verification, and any multi-tenant access control；Collaboration, invited members, shared collections, and permissions beyond the single owner；Public profiles, public collection pages, social discovery, and follower networks；Cross-device or cross-browser synchronization; persistence is explicitly limited to one local browser profile；Browser extension, bookmarklet, mobile share target, bulk import from browsers or other services, and export；Preserved page copies, reader view, offline archives, and read-later queues；Automatic capture of browsing history or any record created without an explicit owner save；Pinning, archiving, unread flags, reminders, and manual ordering as core capabilities；Bulk edit, bulk move, multi-select, and selection-wide operations；Broken-link detection, link repair, and duplicate merge tooling beyond the save-time duplicate response；Deletion, trash, and restore flows in the core; removal semantics remain an open product question；Full-text search over page content, and search over anything other than the owner's own saved records；Tags as independently managed entities, tag hierarchies, tag counts, or tag rename and merge administration

## Roles

### owner
**Library owner**

- 数据范围 / Data scope: All records, collections, tags, and metadata in this browser profile's library. No other person's data exists inside the product boundary, and no role can read or modify another profile's library.
- 目标 / Goal: Save links with almost no friction, keep them organized in a way that makes personal sense, and find and reopen them later.

## Objects

### library
**Personal library**

- 字段 / Fields:
  1. 
    - 含义 / Meaning: Stable internal identifier for this browser profile's library; not a user-facing concept.
    - Name: id
  2. 
    - 含义 / Meaning: The single local browser profile that owns every record and collection in this library.
    - Name: owner_scope
  3. 
    - 含义 / Meaning: Identifier of the inbox collection that receives saves made without an explicit collection choice.
    - Name: default_collection_id
  4. 
    - 含义 / Meaning: Derived total of saved records, used to distinguish an empty library from an accumulating one.
    - Name: record_count
  5. 
    - 含义 / Meaning: Whether the library is readable and writable in local storage at the current moment; a failed read is surfaced rather than hidden.
    - Name: storage_state
- 关系 / Relations:
  1. 
    - 含义 / Meaning: Contains every collection, including the default inbox.
    - Object id: [collection](#collection)
  2. 
    - 含义 / Meaning: Holds every saved reference record for the owner.
    - Object id: [bookmark](#bookmark)
- 状态 / States:
  - empty
  - populated

### collection
**Collection**

- 字段 / Fields:
  1. 
    - 含义 / Meaning: Stable identifier for the collection; preserved across renames.
    - Name: id
  2. 
    - 含义 / Meaning: Owner-chosen label such as 待购, 家居改造, or 以后看看; nonblank and unique within the library after trimming and case folding.
    - Name: name
  3. 
    - 含义 / Meaning: True only for the inbox that receives saves made without an explicit collection choice; never user-renamed.
    - Name: is_default
  4. 
    - 含义 / Meaning: Time the collection was created; used for stable ordering in the sidebar.
    - Name: created_at
  5. 
    - 含义 / Meaning: Derived number of records currently filed in the collection, shown beside its name.
    - Name: record_count
- 关系 / Relations:
  1. 
    - 含义 / Meaning: Belongs to exactly one personal library.
    - Object id: [library](#library)
  2. 
    - 含义 / Meaning: Groups any number of records; a record is filed in at most one collection at a time.
    - Object id: [bookmark](#bookmark)
- 状态 / States:
  - empty
  - populated

### bookmark
**Bookmark record**

- 字段 / Fields:
  1. 
    - 含义 / Meaning: Stable internal identifier generated at save time; editing, moving, and renaming never change it.
    - Name: id
  2. 
    - 含义 / Meaning: The absolute http or https address of the external resource; the anchor that makes the record meaningful and the value opened when the owner returns to it.
    - Name: url
  3. 
    - 含义 / Meaning: Comparison key derived from the URL by trimming surrounding whitespace, lowercasing the host, and removing a trailing slash; used only to detect an existing record.
    - Name: url_key
  4. 
    - 含义 / Meaning: Owner-visible name; may be fetched, falls back to the hostname when absent, and stays editable.
    - Name: title
  5. 
    - 含义 / Meaning: Optional free-text note about why the page was kept; editable and never required to save.
    - Name: description
  6. 
    - 含义 / Meaning: Host portion derived from the URL, displayed for recognition and included in search.
    - Name: hostname
  7. 
    - 含义 / Meaning: Optional reference to a small site icon; absence or retrieval failure never blocks saving.
    - Name: favicon_ref
  8. 
    - 含义 / Meaning: Optional free-form string labels for recall and search; not a hierarchy and not a managed entity.
    - Name: tags
  9. 
    - 含义 / Meaning: Identifier of the single collection the record is filed in, including the default inbox.
    - Name: collection_id
  10. 
    - 含义 / Meaning: Time the record was first saved; never changed by later edits, moves, or opens.
    - Name: created_at
  11. 
    - 含义 / Meaning: Time the record's editable fields were last changed.
    - Name: updated_at
  12. 
    - 含义 / Meaning: Time the owner last opened the external page through the product; absent until the first open, and optional supporting metadata.
    - Name: last_opened_at
  13. 
    - 含义 / Meaning: Number of opens driven by the owner through the product; optional supporting metadata and never a substitute for the URL.
    - Name: open_count
- 关系 / Relations:
  1. 
    - 含义 / Meaning: Filed in exactly one collection; because the inbox is a real collection, no saved record is ever outside a collection.
    - Object id: [collection](#collection)
  2. 
    - 含义 / Meaning: Held in the owner's personal library and subject to that library's local persistence scope.
    - Object id: [library](#library)
- 状态 / States:
  - inbox
  - filed

## Actions

### a_save_bookmark
**Save a bookmark**

- 依据 / Basis:
  - [b_scenario](#b_scenario)
  - [b_leaf_core](#b_leaf_core)
  - [b_flow_save](#b_flow_save)
  - [b_flow_classify](#b_flow_classify)
  - [b_flow_inbox](#b_flow_inbox)
  - [b_up_local](#b_up_local)
  - [b_up_model](#b_up_model)
  - [b_design_collection](#b_design_collection)
  - [b_design_minimal](#b_design_minimal)
  - [b_design_local](#b_design_local)
  - [b_design_dedupe](#b_design_dedupe)
- 依赖 / Dependencies:
- 效果 / Effects:
  - A new record is created with a generated identifier, the submitted URL, a title, optional description and tags, the chosen collection or the default inbox, and a creation time.
  - The record appears immediately in the library and in its collection's record count; the library moves from empty to populated when this is the first record.
  - The record and its collection assignment are written to local storage and survive closing and reopening the application.
- 失败与恢复 / Failures and recovery:
  1. 
    - 条件 / Condition: The URL field is blank, is not an absolute address, or uses a scheme other than http or https.
    - 恢复 / Recovery: The owner corrects the URL and submits again, or cancels without creating a record.
    - 反馈 / Response: The save is refused and an inline message states that a valid http or https URL is required; entered title and description are preserved.
  2. 
    - 条件 / Condition: The normalized URL already belongs to an existing record in the library.
    - 恢复 / Recovery: The owner opens the existing record, files it differently, or cancels the save.
    - 反馈 / Response: No second record is created; the product identifies the existing record and offers to open or move it instead.
  3. 
    - 条件 / Condition: The chosen collection no longer exists at submission time.
    - 恢复 / Recovery: The owner selects the inbox or another existing collection and submits again.
    - 反馈 / Response: The save is refused with a message that the destination is unavailable and the form values are retained.
  4. 
    - 条件 / Condition: Writing to local storage fails or is unavailable.
    - 恢复 / Recovery: The owner retries the save or cancels the pending form; nothing is auto-exported.
    - 反馈 / Response: The record is not reported as saved; an error states that the library could not be updated while the form values remain intact.
- 对象 / Objects:
  - [bookmark](#bookmark)
  - [collection](#collection)
  - [library](#library)
- 前置条件 / Preconditions:
  - The owner explicitly invokes add from the library or the capture surface.
  - The URL field holds an absolute http or https address.
  - If a collection is chosen, that collection currently exists in the owner's library.
- 角色 / Roles:
  - [owner](#owner)
- 规则 / Rules:
  - [r_deliberate_capture](#r_deliberate_capture)
  - [r_url_anchor](#r_url_anchor)
  - [r_minimal_capture](#r_minimal_capture)
  - [r_inbox_default](#r_inbox_default)
  - [r_single_collection](#r_single_collection)
  - [r_url_identity](#r_url_identity)
  - [r_local_persistence](#r_local_persistence)
  - [r_private_single_owner](#r_private_single_owner)
- 入口 / Surfaces:
  - [s_home](#s_home)
  - [s_capture](#s_capture)
- 状态转换 / Transitions:
  1. 
    - 起始状态 / From:
    - Object id: [bookmark](#bookmark)
    - 目标状态 / To: inbox
  2. 
    - 起始状态 / From:
    - Object id: [bookmark](#bookmark)
    - 目标状态 / To: filed
  3. 
    - 起始状态 / From:
      - empty
    - Object id: [library](#library)
    - 目标状态 / To: populated
  4. 
    - 起始状态 / From:
      - empty
      - populated
    - Object id: [collection](#collection)
    - 目标状态 / To: populated

### a_edit_bookmark
**Edit a bookmark's details**

- 依据 / Basis:
  - [b_leaf_core](#b_leaf_core)
  - [b_flow_retrieve](#b_flow_retrieve)
  - [b_up_model](#b_up_model)
  - [b_design_minimal](#b_design_minimal)
  - [b_design_dedupe](#b_design_dedupe)
  - [b_design_tags](#b_design_tags)
- 依赖 / Dependencies:
  - a_save_bookmark
- 效果 / Effects:
  - Edited title, description, tags, URL, or collection replace the previous values while the record identifier and creation time are preserved.
  - When the collection changes, both collections' derived counts update.
  - The updated record persists across sessions and the library shows the new values immediately.
- 失败与恢复 / Failures and recovery:
  1. 
    - 条件 / Condition: The edited URL is blank, malformed, or not http or https.
    - 恢复 / Recovery: The owner restores a valid URL or cancels the edit.
    - 反馈 / Response: The edit is refused with an inline URL message and the existing record remains unchanged.
  2. 
    - 条件 / Condition: The edited URL normalizes to a different existing record.
    - 恢复 / Recovery: The owner opens the conflicting record, keeps the current URL, or cancels.
    - 反馈 / Response: The edit is refused with an explanation that another record already uses that address, and the original record is left intact.
  3. 
    - 条件 / Condition: The record is no longer present in local storage when the edit is submitted.
    - 恢复 / Recovery: The owner returns to the library and continues from the refreshed list.
    - 反馈 / Response: The edit is refused and the view refreshes with a notice that the record is gone.
- 对象 / Objects:
  - [bookmark](#bookmark)
  - [collection](#collection)
- 前置条件 / Preconditions:
  - The record exists in the owner's library.
  - The owner opens the edit form with the record's current URL, title, description, tags, and collection populated.
- 角色 / Roles:
  - [owner](#owner)
- 规则 / Rules:
  - [r_url_anchor](#r_url_anchor)
  - [r_url_identity](#r_url_identity)
  - [r_minimal_capture](#r_minimal_capture)
  - [r_single_collection](#r_single_collection)
  - [r_local_persistence](#r_local_persistence)
- 入口 / Surfaces:
  - [s_capture](#s_capture)
  - [s_record](#s_record)
- 状态转换 / Transitions:

### a_create_collection
**Create a collection**

- 依据 / Basis:
  - [b_flow_classify](#b_flow_classify)
  - [b_flow_inbox](#b_flow_inbox)
  - [b_design_collection](#b_design_collection)
  - [b_leaf_core](#b_leaf_core)
- 依赖 / Dependencies:
- 效果 / Effects:
  - A new empty collection is created with a generated identifier, the trimmed name, and a creation time.
  - The collection appears in the sidebar and in collection pickers, ready to receive records.
  - The new collection persists across sessions.
- 失败与恢复 / Failures and recovery:
  1. 
    - 条件 / Condition: The supplied name is blank or only whitespace.
    - 恢复 / Recovery: The owner enters a nonblank name and retries.
    - 反馈 / Response: Creation is refused and the name field indicates that a name is required.
  2. 
    - 条件 / Condition: A collection with the same normalized name already exists, including the inbox.
    - 恢复 / Recovery: The owner chooses a different name or selects the existing collection.
    - 反馈 / Response: Creation is refused with a message naming the existing collection; no duplicate structure is created.
  3. 
    - 条件 / Condition: Local storage rejects the new collection.
    - 恢复 / Recovery: The owner retries once storage is writable again.
    - 反馈 / Response: Creation is refused with an error and no sidebar entry is added.
- 对象 / Objects:
  - [collection](#collection)
- 前置条件 / Preconditions:
  - The owner supplies a name that is nonblank after trimming.
  - No existing collection, including the inbox, has the same name after trimming and case folding.
- 角色 / Roles:
  - [owner](#owner)
- 规则 / Rules:
  - [r_collection_naming](#r_collection_naming)
  - [r_single_collection](#r_single_collection)
  - [r_local_persistence](#r_local_persistence)
- 入口 / Surfaces:
  - [s_collections](#s_collections)
  - [s_capture](#s_capture)
- 状态转换 / Transitions:
  1. 
    - 起始状态 / From:
    - Object id: [collection](#collection)
    - 目标状态 / To: empty

### a_move_record
**Move a record to another collection**

- 依据 / Basis:
  - [b_scenario](#b_scenario)
  - [b_flow_classify](#b_flow_classify)
  - [b_flow_inbox](#b_flow_inbox)
  - [b_design_collection](#b_design_collection)
  - [b_design_local](#b_design_local)
- 依赖 / Dependencies:
  - a_save_bookmark
  - a_create_collection
- 效果 / Effects:
  - The record's collection assignment changes to the target collection while its identifier, URL, metadata, and creation time are preserved.
  - Both collections' derived counts update, the record leaves the previous collection's view, and appears in the target's view.
  - The new assignment persists after the application is reopened.
- 失败与恢复 / Failures and recovery:
  1. 
    - 条件 / Condition: The target collection no longer exists or cannot be resolved.
    - 恢复 / Recovery: The owner refreshes the collection list, chooses an existing collection, or leaves the record where it is.
    - 反馈 / Response: The move is refused, the record remains in its previous collection, and a message explains that the destination is unavailable.
  2. 
    - 条件 / Condition: The record itself is no longer present in local storage.
    - 恢复 / Recovery: The owner returns to the library and continues from the refreshed list.
    - 反馈 / Response: The move is refused and the stale view is refreshed with a notice.
  3. 
    - 条件 / Condition: The chosen target is the record's current collection.
    - 恢复 / Recovery: The owner selects a different collection or dismisses the control.
    - 反馈 / Response: The move is treated as a no-op and reported as such rather than as a success.
- 对象 / Objects:
  - [bookmark](#bookmark)
  - [collection](#collection)
- 前置条件 / Preconditions:
  - The record exists and is currently filed in a collection.
  - The target collection exists and differs from the record's current collection.
- 角色 / Roles:
  - [owner](#owner)
- 规则 / Rules:
  - [r_single_collection](#r_single_collection)
  - [r_inbox_default](#r_inbox_default)
  - [r_local_persistence](#r_local_persistence)
  - [r_organization_revisable](#r_organization_revisable)
- 入口 / Surfaces:
  - [s_record](#s_record)
  - [s_home](#s_home)
- 状态转换 / Transitions:
  1. 
    - 起始状态 / From:
      - inbox
      - filed
    - Object id: [bookmark](#bookmark)
    - 目标状态 / To: filed
  2. 
    - 起始状态 / From:
      - filed
    - Object id: [bookmark](#bookmark)
    - 目标状态 / To: inbox
  3. 
    - 起始状态 / From:
      - populated
    - Object id: [collection](#collection)
    - 目标状态 / To: empty
  4. 
    - 起始状态 / From:
      - empty
      - populated
    - Object id: [collection](#collection)
    - 目标状态 / To: populated

### a_open_record
**Open the original web page**

- 依据 / Basis:
  - [b_scenario](#b_scenario)
  - [b_leaf_core](#b_leaf_core)
  - [b_flow_return](#b_flow_return)
  - [b_up_open](#b_up_open)
  - [b_up_visit](#b_up_visit)
  - [b_design_open](#b_design_open)
  - [b_unknown_usage](#b_unknown_usage)
- 依赖 / Dependencies:
  - a_save_bookmark
- 效果 / Effects:
  - The external page opens in a new browser tab at exactly the stored URL, leaving the library view intact.
  - The record's last-opened time becomes the current time and its open count increases by one, if usage metadata is retained.
  - No page content is fetched, rendered, or stored by the library as a result of opening.
- 失败与恢复 / Failures and recovery:
  1. 
    - 条件 / Condition: The browser blocks the new tab or the external page cannot be reached.
    - 恢复 / Recovery: The owner retries opening, copies the URL, or edits the record if the address is wrong.
    - 反馈 / Response: The library remains usable and the owner receives a notice that the page could not be opened, with the URL still visible and copyable.
  2. 
    - 条件 / Condition: The record's URL is missing or malformed at open time.
    - 恢复 / Recovery: The owner edits the record to supply a valid URL.
    - 反馈 / Response: No tab is opened, the record is flagged as having an invalid address, and no open statistic is recorded.
- 对象 / Objects:
  - [bookmark](#bookmark)
- 前置条件 / Preconditions:
  - The record exists and holds an absolute http or https URL.
  - The owner explicitly chooses open from the library card or the record detail.
- 角色 / Roles:
  - [owner](#owner)
- 规则 / Rules:
  - [r_url_anchor](#r_url_anchor)
  - [r_no_content_copy](#r_no_content_copy)
  - [r_open_tracking](#r_open_tracking)
- 入口 / Surfaces:
  - [s_home](#s_home)
  - [s_record](#s_record)
- 状态转换 / Transitions:

### a_browse_collection
**Browse a collection or the inbox**

- 依据 / Basis:
  - [b_scenario](#b_scenario)
  - [b_flow_retrieve](#b_flow_retrieve)
  - [b_design_collection](#b_design_collection)
  - [b_up_tags](#b_up_tags)
  - [b_up_search](#b_up_search)
  - [b_up_sort](#b_up_sort)
- 依赖 / Dependencies:
  - a_save_bookmark
- 效果 / Effects:
  - The library list shows only records filed in the selected collection, ordered by the active sort with newest-added first by default.
  - The selected collection is visually identified and its record count is shown.
  - Selecting another collection replaces the browse scope without changing any record.
- 失败与恢复 / Failures and recovery:
  1. 
    - 条件 / Condition: The selected collection disappears because the view is stale or storage changed externally.
    - 恢复 / Recovery: The owner chooses another collection or refreshes the library.
    - 反馈 / Response: The list falls back to the default inbox with a notice that the requested collection is no longer available.
  2. 
    - 条件 / Condition: Local storage cannot be read while browsing.
    - 恢复 / Recovery: The owner retries once storage is readable again.
    - 反馈 / Response: The list shows an error state rather than an empty or partial collection presented as complete.
- 对象 / Objects:
  - [collection](#collection)
  - [bookmark](#bookmark)
- 前置条件 / Preconditions:
  - The owner selects a collection from the organization sidebar, including the default inbox.
  - The selected collection exists in the owner's library.
- 角色 / Roles:
  - [owner](#owner)
- 规则 / Rules:
  - [r_inbox_default](#r_inbox_default)
  - [r_single_collection](#r_single_collection)
  - [r_retrieval_scope](#r_retrieval_scope)
  - [r_default_order](#r_default_order)
- 入口 / Surfaces:
  - [s_collections](#s_collections)
  - [s_home](#s_home)
- 状态转换 / Transitions:

### a_search_records
**Search saved records**

- 依据 / Basis:
  - [b_scenario](#b_scenario)
  - [b_flow_retrieve](#b_flow_retrieve)
  - [b_leaf_core](#b_leaf_core)
  - [b_up_search](#b_up_search)
  - [b_design_search](#b_design_search)
  - [b_design_collection](#b_design_collection)
- 依赖 / Dependencies:
  - a_save_bookmark
- 效果 / Effects:
  - The result list narrows to records whose title, URL, hostname, description, or tags contain the query as a case-insensitive substring.
  - The query combines with the active collection scope, so results are the owner's records in that scope that also match the text.
  - Clearing the query restores the unfiltered collection list.
- 失败与恢复 / Failures and recovery:
  1. 
    - 条件 / Condition: No saved record matches the query in the active collection scope.
    - 恢复 / Recovery: The owner edits the query, clears it, or browses another collection.
    - 反馈 / Response: A no-results state names the query and the active collection and offers to clear the search or change collection.
  2. 
    - 条件 / Condition: Local storage cannot be read while searching.
    - 恢复 / Recovery: The owner retries after the storage error clears; the query text is preserved.
    - 反馈 / Response: The list shows an error state instead of silently presenting incomplete results.
- 对象 / Objects:
  - [bookmark](#bookmark)
- 前置条件 / Preconditions:
  - The owner enters a nonblank query in the library search field.
  - The library contains records; the owner does not need to browse a collection first.
- 角色 / Roles:
  - [owner](#owner)
- 规则 / Rules:
  - [r_retrieval_scope](#r_retrieval_scope)
  - [r_default_order](#r_default_order)
- 入口 / Surfaces:
  - [s_home](#s_home)
- 状态转换 / Transitions:

### a_sort_records
**Change record ordering**

- 依据 / Basis:
  - [b_up_sort](#b_up_sort)
  - [b_design_search](#b_design_search)
  - [b_design_open](#b_design_open)
- 依赖 / Dependencies:
  - a_save_bookmark
- 效果 / Effects:
  - The current result set is reordered without changing records, collection assignments, or search scope.
  - The chosen ordering stays active for the current view until changed or the session ends.
  - Ties fall back to newest-added order so the list stays deterministic.
- 失败与恢复 / Failures and recovery:
  1. 
    - 条件 / Condition: Usage metadata is absent for records that were never opened.
    - 恢复 / Recovery: The owner selects newest-added ordering or opens a record to populate usage metadata.
    - 反馈 / Response: Those records sort after records holding the selected usage value, with newest-added as the tie-breaker; no record is hidden.
  2. 
    - 条件 / Condition: The owner selects the ordering that is already active.
    - 恢复 / Recovery: The owner chooses another ordering or closes the control.
    - 反馈 / Response: The list stays unchanged and the current ordering remains identified as active.
- 对象 / Objects:
  - [bookmark](#bookmark)
- 前置条件 / Preconditions:
  - The library list is visible with at least one record.
  - The owner chooses one of the offered orderings: recently added, recently opened, or most opened.
- 角色 / Roles:
  - [owner](#owner)
- 规则 / Rules:
  - [r_default_order](#r_default_order)
  - [r_retrieval_scope](#r_retrieval_scope)
- 入口 / Surfaces:
  - [s_home](#s_home)
- 状态转换 / Transitions:

### a_fetch_metadata
**Fetch page title and description**

- 依据 / Basis:
  - [b_up_metadata](#b_up_metadata)
  - [b_design_metadata](#b_design_metadata)
  - [b_design_minimal](#b_design_minimal)
  - [b_unknown_metadata](#b_unknown_metadata)
- 依赖 / Dependencies:
- 效果 / Effects:
  - When the service succeeds, title and description fields are populated with returned values the owner may edit or clear.
  - A site icon may be attached if retrieval succeeds; failure leaves the record usable without an icon.
  - The URL and any already-entered fields remain available throughout the request.
- 失败与恢复 / Failures and recovery:
  1. 
    - 条件 / Condition: The metadata service is unreachable, rate-limited, returns no usable data, or the browser blocks the request.
    - 恢复 / Recovery: The owner types a title and description manually and saves, or retries the fetch.
    - 反馈 / Response: The form remains open with existing values unchanged and a non-blocking notice explains that details could not be fetched.
  2. 
    - 条件 / Condition: No URL has been entered yet.
    - 恢复 / Recovery: The owner enters a URL and retries.
    - 反馈 / Response: The metadata action is unavailable with an explanation that a URL is needed first.
- 对象 / Objects:
  - [bookmark](#bookmark)
- 前置条件 / Preconditions:
  - A valid http or https URL has been entered in the capture surface.
  - The owner explicitly requests metadata assistance; it never runs implicitly before save.
- 角色 / Roles:
  - [owner](#owner)
- 规则 / Rules:
  - [r_minimal_capture](#r_minimal_capture)
  - [r_private_single_owner](#r_private_single_owner)
- 入口 / Surfaces:
  - [s_capture](#s_capture)
- 状态转换 / Transitions:

### a_rename_collection
**Rename a collection**

- 依据 / Basis:
  - [b_flow_classify](#b_flow_classify)
  - [b_design_collection](#b_design_collection)
  - [b_leaf_core](#b_leaf_core)
  - [b_unknown_preset](#b_unknown_preset)
- 依赖 / Dependencies:
  - a_create_collection
- 效果 / Effects:
  - The collection keeps its identifier and record assignments while displaying the new name.
  - Records filed in the renamed collection remain filed there and remain findable by browsing it.
  - The new name persists across sessions.
- 失败与恢复 / Failures and recovery:
  1. 
    - 条件 / Condition: The new name is blank or duplicates another collection's normalized name.
    - 恢复 / Recovery: The owner supplies a different name or cancels the rename.
    - 反馈 / Response: The rename is refused with an inline explanation and the previous name remains in effect.
  2. 
    - 条件 / Condition: The collection is the default inbox.
    - 恢复 / Recovery: The owner renames another collection or creates a new one.
    - 反馈 / Response: The rename control is unavailable because the inbox is a fixed structural location rather than an owner-named collection.
  3. 
    - 条件 / Condition: The collection is no longer present in storage.
    - 恢复 / Recovery: The owner continues from the refreshed collection list.
    - 反馈 / Response: The rename is refused and the sidebar refreshes with a notice.
- 对象 / Objects:
  - [collection](#collection)
  - [bookmark](#bookmark)
- 前置条件 / Preconditions:
  - The collection exists and is not the default inbox.
  - The owner supplies a nonblank name distinct from every other collection after trimming and case folding.
- 角色 / Roles:
  - [owner](#owner)
- 规则 / Rules:
  - [r_collection_naming](#r_collection_naming)
  - [r_local_persistence](#r_local_persistence)
  - [r_single_collection](#r_single_collection)
  - [r_organization_revisable](#r_organization_revisable)
- 入口 / Surfaces:
  - [s_collections](#s_collections)
- 状态转换 / Transitions:

## Surfaces

### s_home
**Personal library**

- 操作 / Actions:
  - [a_save_bookmark](#a_save_bookmark)
  - [a_move_record](#a_move_record)
  - [a_open_record](#a_open_record)
  - [a_browse_collection](#a_browse_collection)
  - [a_search_records](#a_search_records)
  - [a_sort_records](#a_sort_records)
- 形态 / Kind: web
- 导航 / Navigation:
  - s_capture
  - s_record
  - s_collections
- 用途 / Purpose: Show the owner's records in the active collection, let the owner search, reorder, open, move, or start a save, and make an accumulating library feel navigable.
- 查询行为 / Query behavior:
  - 批量 / Bulk: Not provided: selection, bulk move, and bulk edit are outside the core boundary.
  - 导出 / Export: Not provided and no export format is defined; interoperability is outside this product boundary.
  - 筛选 / Filter: Exactly one collection at a time, including the default inbox; upstream-style tag checkboxes and multi-tag AND filtering are outside this boundary.
  - 分页 / Pagination: No pagination requirement is established; record volume is unknown and the core renders the loaded result set in one scrollable list.
  - 搜索 / Search: Case-insensitive substring match over title, URL, hostname, description, and tags of the owner's own records; an empty query applies no text filter.
  - 排序 / Sort: Newest-added descending by default, with optional recently-opened and most-opened orderings, each falling back to newest-added for ties.
- 角色 / Roles:
  - [owner](#owner)
- 区块 / Sections:
  - Top bar with product identity, search field, and primary add action
  - Active collection heading with record count and ordering control
  - Record list or grid showing title, hostname, description, tags, collection, and dates
  - Per-record actions for open, edit, and move
  - Empty, no-results, loading, and storage-error states
- 状态 / States:
  - 空数据 / Empty: No records exist: the view explains that saved links will accumulate here and offers the add action and the empty inbox; it never fabricates sample bookmarks.
  - 错误 / Error: Local storage cannot be read or written: a banner states that the library is unavailable or unsaved and offers retry; it never presents stale data as current.
  - 无权限 / Forbidden: Not applicable: the product has exactly one owner role and no shared or public view, so no other role can be denied access here.
  - 加载 / Loading: A first-load state explains that the local library is being read and shows a placeholder list without inventing records.
  - 无结果 / No results: The active query or collection scope yields no records: the view names the query and collection and offers to clear the search or switch collection.

### s_capture
**Add or edit bookmark**

- 操作 / Actions:
  - [a_save_bookmark](#a_save_bookmark)
  - [a_edit_bookmark](#a_edit_bookmark)
  - [a_create_collection](#a_create_collection)
  - [a_fetch_metadata](#a_fetch_metadata)
- 形态 / Kind: web
- 导航 / Navigation:
  - s_home
  - s_record
- 用途 / Purpose: Collect the minimum needed to keep a link quickly, optionally pull page details, choose or create a collection, and save or update one record without leaving the library.
- 查询行为 / Query behavior:
  - 批量 / Bulk: Not applicable: exactly one record can be saved or edited per submission.
  - 导出 / Export: Not applicable: the form neither imports nor exports data.
  - 筛选 / Filter: Not applicable: there is no result set to filter; the collection selector is an input choice, not a filter.
  - 分页 / Pagination: Not applicable: the form edits one record at a time.
  - 搜索 / Search: Not applicable: the capture form is not a search surface and has no result query.
  - 排序 / Sort: Not applicable: form fields are presented in a fixed task order.
- 角色 / Roles:
  - [owner](#owner)
- 区块 / Sections:
  - Heading that distinguishes adding from editing
  - URL field with metadata-fetch action and validation message
  - Title field with hostname fallback
  - Optional description field
  - Optional tags input
  - Collection selector with inline create-new option, defaulting to the inbox
  - Submit and cancel actions
- 状态 / States:
  - 空数据 / Empty: A new save form starts blank except for the default inbox selection and a URL placeholder; there are no prefilled sample records or invented collections.
  - 错误 / Error: Validation messages appear inline next to the affected fields; a storage failure appears as a form-level error with all values retained.
  - 无权限 / Forbidden: Not applicable: only the owner can reach the capture surface, so no permission-denied state exists.
  - 加载 / Loading: While metadata is being fetched the form stays open with a progress indicator and the owner's entered values preserved; manual entry remains possible.
  - 无结果 / No results: Not applicable: this is a form rather than a result list, so absent metadata is shown as an empty optional field instead of a search-result emptiness.

### s_collections
**Organization sidebar**

- 操作 / Actions:
  - [a_create_collection](#a_create_collection)
  - [a_browse_collection](#a_browse_collection)
  - [a_rename_collection](#a_rename_collection)
- 形态 / Kind: web
- 导航 / Navigation:
  - s_home
- 用途 / Purpose: Act as the library's structural map: expose the inbox and every owner-created collection with counts, support browsing into one, and allow creating or renaming collections.
- 查询行为 / Query behavior:
  - 批量 / Bulk: Not applicable: collection operations act on one collection at a time.
  - 导出 / Export: Not applicable: the sidebar has no export action.
  - 筛选 / Filter: Not applicable: it exposes all collections; narrowing happens in the library list.
  - 分页 / Pagination: Not applicable at this boundary's scale; the collection count is small and no paging is defined.
  - 搜索 / Search: Not applicable: the sidebar is a short structural list, not a searchable result set.
  - 排序 / Sort: Collections follow a stable sidebar order; free-text queries never re-rank them.
- 角色 / Roles:
  - [owner](#owner)
- 区块 / Sections:
  - Default inbox entry with record count
  - Owner-created collection list with record counts
  - Create-collection control and name validation
  - Rename control for non-default collections
- 状态 / States:
  - 空数据 / Empty: Only the default inbox exists; the sidebar explains that the owner may create the first collection and offers the create control.
  - 错误 / Error: Collections cannot be read: the sidebar shows an error with retry and the library falls back to the inbox only.
  - 无权限 / Forbidden: Not applicable: there is no non-owner role and no sharing, so no collection is hidden for permission reasons.
  - 加载 / Loading: The sidebar shows a compact placeholder until collections are read from local storage.
  - 无结果 / No results: Not applicable: an empty collection is a valid destination and is shown with a zero count rather than treated as a failed result.

### s_record
**Record detail**

- 操作 / Actions:
  - [a_edit_bookmark](#a_edit_bookmark)
  - [a_move_record](#a_move_record)
  - [a_open_record](#a_open_record)
- 形态 / Kind: web
- 导航 / Navigation:
  - s_capture
  - s_home
- 用途 / Purpose: Show one record's identity and metadata, with returning to the live page as the primary action and the ability to edit or move the record.
- 查询行为 / Query behavior:
  - 批量 / Bulk: Not applicable: actions apply to the selected record only.
  - 导出 / Export: Not applicable: no export action exists on the record detail.
  - 筛选 / Filter: Not applicable: there is no result set to filter, only a collection assignment to change.
  - 分页 / Pagination: Not applicable: one record is shown at a time.
  - 搜索 / Search: Not applicable: the detail view shows one record; search belongs to the library surface.
  - 排序 / Sort: Not applicable: a single record has no ordering.
- 角色 / Roles:
  - [owner](#owner)
- 区块 / Sections:
  - Title, hostname, and optional favicon
  - Full URL with the open action
  - Description and optional tags
  - Current collection and move control
  - Created and last-opened timestamps plus optional open count
- 状态 / States:
  - 空数据 / Empty: Not applicable: the detail surface opens only for an existing record, so there is no empty-record variant.
  - 错误 / Error: If the record is no longer present in local storage, the panel closes with a notice and the library refreshes.
  - 无权限 / Forbidden: Not applicable: only the single owner can open a record, and no record is shared or restricted.
  - 加载 / Loading: Not applicable in the core because the record is already in the loaded list; if a refresh is required, a short loading label is shown rather than a blank panel.
  - 无结果 / No results: Not applicable: the surface presents one selected record and has no result set.

## Journeys

### j_capture_return
**Save now, return later**

- 完成条件 / Completion: A deliberately saved link survives the session, is visible in the personal library, and can be reopened at its original address without the product recreating or hosting the page.
- 目标 / Goal: Keep a page met during browsing with almost no interruption, then come back to the live page when the owner actually needs it.
- 恢复 / Recovery: If metadata or icon retrieval fails, the owner saves with only the URL and a derived title. If opening fails, the URL stays visible for copying or correction. If storage fails, the form stays populated and the save can be retried.
- 角色 / Roles:
  - [owner](#owner)
- 步骤 / Steps:
  1. 
    - Action id: [a_save_bookmark](#a_save_bookmark)
    - Role id: [owner](#owner)
    - 成功结果 / Success: The add action opens the capture form with the URL field ready and the inbox preselected.
    - Surface id: [s_home](#s_home)
  2. 
    - Action id: [a_save_bookmark](#a_save_bookmark)
    - Role id: [owner](#owner)
    - 成功结果 / Success: With only a URL entered, the record is saved into the inbox with a hostname-derived title and appears in the library immediately.
    - Surface id: [s_capture](#s_capture)
  3. 
    - Action id: [a_open_record](#a_open_record)
    - Role id: [owner](#owner)
    - 成功结果 / Success: The saved record is still listed in a later session, and opening it launches the original page in a new tab while the library stays open.
    - Surface id: [s_home](#s_home)

### j_triage_inbox
**Triage the inbox into collections**

- 完成条件 / Completion: The library's organization is entirely owner-defined, records can be refiled indefinitely, and collection assignments are durable rather than session state.
- 目标 / Goal: Turn an unsorted accumulation into a personally meaningful structure by creating a collection and moving saved records into it, with the result surviving restart.
- 恢复 / Recovery: If a collection name is blank or collides, creation is refused with an explanation and the inbox stays intact. If a move target is missing, the record stays where it was and the owner can retry from a refreshed sidebar.
- 角色 / Roles:
  - [owner](#owner)
- 步骤 / Steps:
  1. 
    - Action id: [a_browse_collection](#a_browse_collection)
    - Role id: [owner](#owner)
    - 成功结果 / Success: The owner opens the inbox and sees the records saved without an explicit collection.
    - Surface id: [s_collections](#s_collections)
  2. 
    - Action id: [a_create_collection](#a_create_collection)
    - Role id: [owner](#owner)
    - 成功结果 / Success: A new named collection such as 待购 or 家居改造 is created empty and appears in the sidebar.
    - Surface id: [s_collections](#s_collections)
  3. 
    - Action id: [a_move_record](#a_move_record)
    - Role id: [owner](#owner)
    - 成功结果 / Success: The chosen record moves from the inbox to the new collection and both counts update.
    - Surface id: [s_record](#s_record)
  4. 
    - Action id: [a_edit_bookmark](#a_edit_bookmark)
    - Role id: [owner](#owner)
    - 成功结果 / Success: The owner adds a clarifying title or description without changing the record's identity or collection.
    - Surface id: [s_capture](#s_capture)
  5. 
    - Action id: [a_browse_collection](#a_browse_collection)
    - Role id: [owner](#owner)
    - 成功结果 / Success: After reopening the application, the collection still contains the moved record and the inbox no longer lists it.
    - Surface id: [s_collections](#s_collections)

### j_find_known_link
**Find a link remembered only vaguely**

- 完成条件 / Completion: The owner finds a record they already chose to keep and reaches the live resource; the product behaves as a retrieval tool for known references, not as a search engine for unseen pages.
- 目标 / Goal: Locate a previously saved page from a remembered word, domain, or rough filing location and return to it.
- 恢复 / Recovery: A no-results state preserves the query and active collection and offers to clear or broaden it. If the URL is broken, the record stays in the library with its stored address available for correction.
- 角色 / Roles:
  - [owner](#owner)
- 步骤 / Steps:
  1. 
    - Action id: [a_search_records](#a_search_records)
    - Role id: [owner](#owner)
    - 成功结果 / Success: A remembered word from the title, domain, description, or tag narrows the library to candidate records.
    - Surface id: [s_home](#s_home)
  2. 
    - Action id: [a_browse_collection](#a_browse_collection)
    - Role id: [owner](#owner)
    - 成功结果 / Success: If several candidates remain, browsing the likely collection reduces the list to the relevant records.
    - Surface id: [s_collections](#s_collections)
  3. 
    - Action id: [a_open_record](#a_open_record)
    - Role id: [owner](#owner)
    - 成功结果 / Success: The owner identifies the intended record and opens the original page, while the library keeps the record for future retrieval.
    - Surface id: [s_home](#s_home)

## Rules

### r_deliberate_capture
**Records enter the library only through an explicit owner save action; browsing activity is never converted into records automatically, and no background process may append to the library on its own.**

- 依据 / Basis:
  - [b_leaf_core](#b_leaf_core)
  - [b_flow_save](#b_flow_save)
  - [b_up_local](#b_up_local)
- 对象 / Objects:
  - [bookmark](#bookmark)
  - [library](#library)
- 说明 / Statement: Records enter the library only through an explicit owner save action; browsing activity is never converted into records automatically, and no background process may append to the library on its own.

### r_url_anchor
**Every record is anchored to an absolute http or https URL; the record is a reference to content owned by the external site, not a copy of that content.**

- 依据 / Basis:
  - [b_scenario](#b_scenario)
  - [b_leaf_core](#b_leaf_core)
  - [b_flow_return](#b_flow_return)
  - [b_up_model](#b_up_model)
- 对象 / Objects:
  - [bookmark](#bookmark)
- 说明 / Statement: Every record is anchored to an absolute http or https URL; the record is a reference to content owned by the external site, not a copy of that content.

### r_local_persistence
**Saved records, their metadata, and their collection assignments persist across sessions in the owner's local browser storage; they are not confined to a single page session, and persistence is explicitly limited to that one browser profile.**

- 依据 / Basis:
  - [b_scenario](#b_scenario)
  - [b_leaf_core](#b_leaf_core)
  - [b_flow_retrieve](#b_flow_retrieve)
  - [b_up_local](#b_up_local)
  - [b_design_local](#b_design_local)
  - [b_unknown_persistence](#b_unknown_persistence)
- 对象 / Objects:
  - [library](#library)
  - [bookmark](#bookmark)
  - [collection](#collection)
- 说明 / Statement: Saved records, their metadata, and their collection assignments persist across sessions in the owner's local browser storage; they are not confined to a single page session, and persistence is explicitly limited to that one browser profile.

### r_inbox_default
**The library always contains one default inbox; a save without a collection choice lands there, and the owner can later move the record into any collection or back to the inbox.**

- 依据 / Basis:
  - [b_flow_inbox](#b_flow_inbox)
  - [b_flow_classify](#b_flow_classify)
  - [b_design_collection](#b_design_collection)
- 对象 / Objects:
  - [collection](#collection)
  - [bookmark](#bookmark)
- 说明 / Statement: The library always contains one default inbox; a save without a collection choice lands there, and the owner can later move the record into any collection or back to the inbox.

### r_single_collection
**A record is filed in exactly one collection at a time; organization is a single-level, owner-controlled structure, while tags remain optional free-form labels rather than a second hierarchy.**

- 依据 / Basis:
  - [b_flow_classify](#b_flow_classify)
  - [b_leaf_core](#b_leaf_core)
  - [b_design_collection](#b_design_collection)
  - [b_design_tags](#b_design_tags)
- 对象 / Objects:
  - [bookmark](#bookmark)
  - [collection](#collection)
- 说明 / Statement: A record is filed in exactly one collection at a time; organization is a single-level, owner-controlled structure, while tags remain optional free-form labels rather than a second hierarchy.

### r_url_identity
**The library keeps one record per normalized URL: comparison trims surrounding whitespace, lowercases the host, and removes a trailing slash; a matching save is reported together with the existing record instead of creating a second entry.**

- 依据 / Basis:
  - [b_leaf_core](#b_leaf_core)
  - [b_up_dedupe](#b_up_dedupe)
  - [b_design_dedupe](#b_design_dedupe)
  - [b_unknown_dedupe](#b_unknown_dedupe)
- 对象 / Objects:
  - [bookmark](#bookmark)
  - [library](#library)
- 说明 / Statement: The library keeps one record per normalized URL: comparison trims surrounding whitespace, lowercases the host, and removes a trailing slash; a matching save is reported together with the existing record instead of creating a second entry.

### r_retrieval_scope
**Retrieval operates only on the owner's own saved records: search matches title, URL, hostname, description, and tags as case-insensitive substrings, and collection browsing narrows that same set; results never include pages the owner has not saved.**

- 依据 / Basis:
  - [b_scenario](#b_scenario)
  - [b_flow_retrieve](#b_flow_retrieve)
  - [b_up_search](#b_up_search)
  - [b_design_search](#b_design_search)
- 对象 / Objects:
  - [bookmark](#bookmark)
  - [collection](#collection)
- 说明 / Statement: Retrieval operates only on the owner's own saved records: search matches title, URL, hostname, description, and tags as case-insensitive substrings, and collection browsing narrows that same set; results never include pages the owner has not saved.

### r_default_order
**The default order is newest-added first; optional recently-opened and most-opened orderings apply only to the current result set and fall back to newest-added for ties so no record disappears.**

- 依据 / Basis:
  - [b_up_sort](#b_up_sort)
  - [b_design_search](#b_design_search)
  - [b_design_open](#b_design_open)
- 对象 / Objects:
  - [bookmark](#bookmark)
- 说明 / Statement: The default order is newest-added first; optional recently-opened and most-opened orderings apply only to the current result set and fall back to newest-added for ties so no record disappears.

### r_minimal_capture
**Only the URL is required to save; the title may be fetched or derived from the hostname, and description, tags, and an explicit collection choice are optional so capture costs seconds. Length ceilings for URL, title, description, and tags are not fixed by the available evidence.**

- 依据 / Basis:
  - [b_scenario](#b_scenario)
  - [b_flow_save](#b_flow_save)
  - [b_design_minimal](#b_design_minimal)
  - [b_unknown_limits](#b_unknown_limits)
- 对象 / Objects:
  - [bookmark](#bookmark)
  - [collection](#collection)
- 说明 / Statement: Only the URL is required to save; the title may be fetched or derived from the hostname, and description, tags, and an explicit collection choice are optional so capture costs seconds. Length ceilings for URL, title, description, and tags are not fixed by the available evidence.

### r_open_tracking
**Opening a record launches its URL in a new browser tab with noopener and noreferrer semantics and leaves the library view in place; a successful open updates last-opened time and open count, while a failed open updates neither.**

- 依据 / Basis:
  - [b_flow_return](#b_flow_return)
  - [b_up_open](#b_up_open)
  - [b_up_visit](#b_up_visit)
  - [b_design_open](#b_design_open)
  - [b_unknown_usage](#b_unknown_usage)
- 对象 / Objects:
  - [bookmark](#bookmark)
- 说明 / Statement: Opening a record launches its URL in a new browser tab with noopener and noreferrer semantics and leaves the library view in place; a successful open updates last-opened time and open count, while a failed open updates neither.

### r_private_single_owner
**The library is private to one owner in one local browser profile, with no accounts, collaborators, public pages, or tracking; any third-party metadata request is an explicit, disclosed, optional action rather than a silent side effect of saving.**

- 依据 / Basis:
  - [b_leaf_core](#b_leaf_core)
  - [b_scenario](#b_scenario)
  - [b_up_local](#b_up_local)
  - [b_design_local](#b_design_local)
  - [b_design_metadata](#b_design_metadata)
- 对象 / Objects:
  - [library](#library)
  - [bookmark](#bookmark)
- 说明 / Statement: The library is private to one owner in one local browser profile, with no accounts, collaborators, public pages, or tracking; any third-party metadata request is an explicit, disclosed, optional action rather than a silent side effect of saving.

### r_no_content_copy
**The product does not fetch, render, or persist the referenced page's body as a library object; there is no reader view, preserved snapshot, or read-later queue in the boundary, so the library guarantees the reference rather than the content.**

- 依据 / Basis:
  - [b_leaf_core](#b_leaf_core)
  - [b_flow_return](#b_flow_return)
  - [b_design_open](#b_design_open)
  - [b_design_removal](#b_design_removal)
- 对象 / Objects:
  - [bookmark](#bookmark)
- 说明 / Statement: The product does not fetch, render, or persist the referenced page's body as a library object; there is no reader view, preserved snapshot, or read-later queue in the boundary, so the library guarantees the reference rather than the content.

### r_collection_naming
**Collection names are trimmed, nonblank, and unique after case folding; the default inbox is fixed and cannot be renamed or recreated as an owner collection, so every collection is an unambiguous navigation target.**

- 依据 / Basis:
  - [b_flow_classify](#b_flow_classify)
  - [b_design_collection](#b_design_collection)
  - [b_unknown_preset](#b_unknown_preset)
- 对象 / Objects:
  - [collection](#collection)
- 说明 / Statement: Collection names are trimmed, nonblank, and unique after case folding; the default inbox is fixed and cannot be renamed or recreated as an owner collection, so every collection is an unambiguous navigation target.

### r_organization_revisable
**Organization stays revisable: a record can be moved or edited at any time, and renaming a collection preserves its records and identifier; the product never imposes a structure the owner did not choose.**

- 依据 / Basis:
  - [b_leaf_core](#b_leaf_core)
  - [b_flow_classify](#b_flow_classify)
  - [b_flow_retrieve](#b_flow_retrieve)
  - [b_design_collection](#b_design_collection)
- 对象 / Objects:
  - [bookmark](#bookmark)
  - [collection](#collection)
- 说明 / Statement: Organization stays revisable: a record can be moved or edited at any time, and renaming a collection preserves its records and identifier; the product never imposes a structure the owner did not choose.

## Assertions

### as_save_url_only
**as_save_url_only**

- 操作 / Actions:
  - [a_save_bookmark](#a_save_bookmark)
- 给定 / Given: The owner has a valid URL for a page they have not saved before.
- 旅程 / Journeys:
  - [j_capture_return](#j_capture_return)
- 负向检查 / Negative check: The save must not require a description, tag, or explicit collection, must not create more than one record, and must not store a copy of the page content.
- 规则 / Rules:
  - [r_deliberate_capture](#r_deliberate_capture)
  - [r_minimal_capture](#r_minimal_capture)
  - [r_inbox_default](#r_inbox_default)
  - [r_url_anchor](#r_url_anchor)
  - [r_local_persistence](#r_local_persistence)
- 则 / Then: One record is created in the default inbox with a hostname-derived title, appears immediately in the library, and remains after the application is reopened.
- 当 / When: The owner submits the save form with only the URL entered and leaves description, tags, and collection untouched.

### as_save_invalid_url
**as_save_invalid_url**

- 操作 / Actions:
  - [a_save_bookmark](#a_save_bookmark)
- 给定 / Given: The owner opens the capture form.
- 旅程 / Journeys:
  - [j_capture_return](#j_capture_return)
- 负向检查 / Negative check: No record may be created, no partial library entry may appear, and the form must not discard the owner's other input.
- 规则 / Rules:
  - [r_url_anchor](#r_url_anchor)
  - [r_minimal_capture](#r_minimal_capture)
- 则 / Then: The form stays open, an inline message states that a valid http or https URL is required, and previously entered text is preserved.
- 当 / When: The owner submits with a blank URL or an address that is not an absolute http or https URL.

### as_save_duplicate_url
**as_save_duplicate_url**

- 操作 / Actions:
  - [a_save_bookmark](#a_save_bookmark)
  - [a_edit_bookmark](#a_edit_bookmark)
- 给定 / Given: The library already contains a record for a URL, including a version differing only by surrounding whitespace, host casing, or a trailing slash.
- 旅程 / Journeys:
  - [j_capture_return](#j_capture_return)
- 负向检查 / Negative check: A second record must not be silently created, and the existing record's metadata must not be overwritten by the duplicate attempt.
- 规则 / Rules:
  - [r_url_identity](#r_url_identity)
- 则 / Then: The product identifies the existing record and offers to open or move it, and the library still contains exactly one record for that normalized address.
- 当 / When: The owner tries to save that address again.

### as_save_to_named_collection
**as_save_to_named_collection**

- 操作 / Actions:
  - [a_save_bookmark](#a_save_bookmark)
- 给定 / Given: At least one owner-created collection exists and the owner is saving a new link.
- 旅程 / Journeys:
  - [j_capture_return](#j_capture_return)
  - [j_triage_inbox](#j_triage_inbox)
- 负向检查 / Negative check: The record must not remain in the inbox after a successful save and must not be filed in both collections at once.
- 规则 / Rules:
  - [r_inbox_default](#r_inbox_default)
  - [r_single_collection](#r_single_collection)
- 则 / Then: The record is created in the selected collection, appears in that collection's view, and is absent from the default inbox.
- 当 / When: The owner selects that collection in the capture form and submits a valid URL.

### as_save_private_local
**as_save_private_local**

- 操作 / Actions:
  - [a_save_bookmark](#a_save_bookmark)
- 给定 / Given: A browser profile whose local library is empty or already contains records, with no account created in the product.
- 旅程 / Journeys:
  - [j_capture_return](#j_capture_return)
- 负向检查 / Negative check: Saving must not require or create an account, must not transmit the library contents to a server, and must not make the record visible to any other person.
- 规则 / Rules:
  - [r_private_single_owner](#r_private_single_owner)
  - [r_local_persistence](#r_local_persistence)
- 则 / Then: The record is written only to that profile's local storage, the library remains reachable without signing in, and no shareable or public address for the record is produced.
- 当 / When: The owner saves a link that already exists nowhere in the library.

### as_no_implicit_capture
**as_no_implicit_capture**

- 操作 / Actions:
  - [a_save_bookmark](#a_save_bookmark)
- 给定 / Given: The owner's library contains a known number of records.
- 旅程 / Journeys:
  - [j_capture_return](#j_capture_return)
- 负向检查 / Negative check: The product must not convert browsing activity, page visits, or application use into any record without an explicit owner save.
- 规则 / Rules:
  - [r_deliberate_capture](#r_deliberate_capture)
- 则 / Then: The record count and contents stay exactly as they were, and nothing appears in the inbox.
- 当 / When: The owner opens the library, browses pages elsewhere, or leaves the application idle without invoking save.

### as_edit_preserves_identity
**as_edit_preserves_identity**

- 操作 / Actions:
  - [a_edit_bookmark](#a_edit_bookmark)
- 给定 / Given: A record exists with a title, description, tags, collection, and creation time.
- 旅程 / Journeys:
  - [j_triage_inbox](#j_triage_inbox)
- 负向检查 / Negative check: Editing must not create a replacement record, reset usage metadata unexpectedly, or lose the record's collection assignment.
- 规则 / Rules:
  - [r_local_persistence](#r_local_persistence)
  - [r_single_collection](#r_single_collection)
  - [r_url_anchor](#r_url_anchor)
- 则 / Then: The updated values are shown and persisted, the record keeps its identifier and original creation time, and collection counts reflect any move.
- 当 / When: The owner edits the title, description, tags, URL, or collection and saves.

### as_create_collection_unique
**as_create_collection_unique**

- 操作 / Actions:
  - [a_create_collection](#a_create_collection)
- 给定 / Given: The library already has an inbox and may have other collections.
- 旅程 / Journeys:
  - [j_triage_inbox](#j_triage_inbox)
- 负向检查 / Negative check: A blank name or a case-variant duplicate must not create a second collection or silently replace the existing one.
- 规则 / Rules:
  - [r_collection_naming](#r_collection_naming)
  - [r_local_persistence](#r_local_persistence)
- 则 / Then: A new empty collection with a stable identifier appears in the sidebar and collection pickers and persists after reopening.
- 当 / When: The owner creates a collection with a nonblank name that does not collide after trimming and case folding.

### as_move_record_persists
**as_move_record_persists**

- 操作 / Actions:
  - [a_move_record](#a_move_record)
- 给定 / Given: A record is in the inbox and an owner-created collection exists.
- 旅程 / Journeys:
  - [j_triage_inbox](#j_triage_inbox)
- 负向检查 / Negative check: The move must not duplicate the record, change its URL or creation time, or silently revert on reload.
- 规则 / Rules:
  - [r_single_collection](#r_single_collection)
  - [r_inbox_default](#r_inbox_default)
  - [r_local_persistence](#r_local_persistence)
- 则 / Then: The record leaves the inbox view, appears under the target collection, both counts change, and the assignment survives closing and reopening the application.
- 当 / When: The owner moves the record from the inbox to that collection.

### as_move_missing_target
**as_move_missing_target**

- 操作 / Actions:
  - [a_move_record](#a_move_record)
- 给定 / Given: A record is displayed with a collection assignment.
- 旅程 / Journeys:
  - [j_triage_inbox](#j_triage_inbox)
- 负向检查 / Negative check: The record must not be left in an unresolvable collection and the library must not report a false success.
- 规则 / Rules:
  - [r_single_collection](#r_single_collection)
- 则 / Then: The move is refused, the record remains in its previous collection, and the owner sees that the destination is unavailable.
- 当 / When: The owner attempts to move it to a collection that no longer exists in storage.

### as_open_external_page
**as_open_external_page**

- 操作 / Actions:
  - [a_open_record](#a_open_record)
- 给定 / Given: A saved record exists with a valid URL.
- 旅程 / Journeys:
  - [j_capture_return](#j_capture_return)
  - [j_find_known_link](#j_find_known_link)
- 负向检查 / Negative check: The application must not navigate away from the library, render the page as its own content, or open a different URL than the one stored.
- 规则 / Rules:
  - [r_url_anchor](#r_url_anchor)
  - [r_no_content_copy](#r_no_content_copy)
  - [r_open_tracking](#r_open_tracking)
- 则 / Then: The original page opens in a new browser tab, the library remains in its current view, and the record's last-opened time and optional open count are updated.
- 当 / When: The owner chooses open from the library card or the record detail.

### as_open_failure_no_stat
**as_open_failure_no_stat**

- 操作 / Actions:
  - [a_open_record](#a_open_record)
- 给定 / Given: A record exists whose external page cannot be opened or whose URL has become invalid.
- 旅程 / Journeys:
  - [j_find_known_link](#j_find_known_link)
- 负向检查 / Negative check: A failed open must not increment the open count, update the last-opened time, or remove the record from the library.
- 规则 / Rules:
  - [r_open_tracking](#r_open_tracking)
  - [r_url_anchor](#r_url_anchor)
- 则 / Then: The library stays usable and the owner sees that the page could not be opened, with the stored URL still available for copying or correction.
- 当 / When: The owner attempts to open it.

### as_browse_collection_scope
**as_browse_collection_scope**

- 操作 / Actions:
  - [a_browse_collection](#a_browse_collection)
- 给定 / Given: The owner's library contains records split across the inbox and one or more collections.
- 旅程 / Journeys:
  - [j_triage_inbox](#j_triage_inbox)
  - [j_find_known_link](#j_find_known_link)
- 负向检查 / Negative check: Records from other collections must not be mixed into the result set, and selecting a collection must not modify any record.
- 规则 / Rules:
  - [r_single_collection](#r_single_collection)
  - [r_retrieval_scope](#r_retrieval_scope)
  - [r_inbox_default](#r_inbox_default)
  - [r_default_order](#r_default_order)
- 则 / Then: The list shows only records in that collection, identifies the active collection, and keeps the active search and sort applied within it.
- 当 / When: The owner selects one collection in the organization sidebar.

### as_search_across_fields
**as_search_across_fields**

- 操作 / Actions:
  - [a_search_records](#a_search_records)
- 给定 / Given: The library contains records whose titles, URLs, hostnames, descriptions, and tags differ from one another.
- 旅程 / Journeys:
  - [j_find_known_link](#j_find_known_link)
- 负向检查 / Negative check: Search must not be limited to titles alone, must not be case-sensitive, and must not return records the owner never saved.
- 规则 / Rules:
  - [r_retrieval_scope](#r_retrieval_scope)
- 则 / Then: The matching record is included in the result list, showing case-insensitive substring search across the stated fields within the active collection.
- 当 / When: The owner enters a word that appears only in a URL, hostname, description, or tag, with any casing.

### as_search_no_results
**as_search_no_results**

- 操作 / Actions:
  - [a_search_records](#a_search_records)
- 给定 / Given: The owner is viewing a collection with saved records.
- 旅程 / Journeys:
  - [j_find_known_link](#j_find_known_link)
- 负向检查 / Negative check: The product must not show unrelated records, silently broaden to another collection, or lose the query text until the owner clears it.
- 规则 / Rules:
  - [r_retrieval_scope](#r_retrieval_scope)
- 则 / Then: A no-results state names the active query and collection and offers to clear the search or change collection.
- 当 / When: The owner enters a query that matches none of them.

### as_sort_with_usage_metadata
**as_sort_with_usage_metadata**

- 操作 / Actions:
  - [a_sort_records](#a_sort_records)
- 给定 / Given: A result set contains records with differing creation times and differing open counts, including records never opened.
- 旅程 / Journeys:
  - [j_find_known_link](#j_find_known_link)
- 负向检查 / Negative check: Sorting must not hide records, alter their collection assignment, or change the active search scope.
- 规则 / Rules:
  - [r_default_order](#r_default_order)
  - [r_retrieval_scope](#r_retrieval_scope)
- 则 / Then: The visible result set is reordered consistently, records without usage values fall after those with values, and ties resolve to newest-added.
- 当 / When: The owner switches between newest-added, recently-opened, and most-opened orderings.

### as_metadata_failure_nonblocking
**as_metadata_failure_nonblocking**

- 操作 / Actions:
  - [a_fetch_metadata](#a_fetch_metadata)
  - [a_save_bookmark](#a_save_bookmark)
- 给定 / Given: The owner has entered a URL in the capture form and requests metadata assistance.
- 旅程 / Journeys:
  - [j_capture_return](#j_capture_return)
- 负向检查 / Negative check: Metadata failure must not block saving, must not clear the URL, and must not create a record by itself.
- 规则 / Rules:
  - [r_minimal_capture](#r_minimal_capture)
  - [r_private_single_owner](#r_private_single_owner)
- 则 / Then: The form remains open with the owner's values intact and a non-blocking notice explains the failure; the owner can type a title and save normally.
- 当 / When: The external metadata service is unavailable, rate-limited, or returns no usable title or description.

### as_metadata_request_disclosed
**as_metadata_request_disclosed**

- 操作 / Actions:
  - [a_fetch_metadata](#a_fetch_metadata)
- 给定 / Given: The owner is filling the capture form for a URL they intend to keep.
- 旅程 / Journeys:
  - [j_capture_return](#j_capture_return)
- 负向检查 / Negative check: The product must not contact a third-party metadata service as an undisclosed side effect of typing a URL, opening the form, or saving.
- 规则 / Rules:
  - [r_private_single_owner](#r_private_single_owner)
- 则 / Then: The request is an explicit owner action, the interface states before or during the request that an external service may be contacted, and declining or failing it leaves manual entry fully usable.
- 当 / When: The owner invokes metadata assistance for that URL.

### as_rename_collection_preserves_records
**as_rename_collection_preserves_records**

- 操作 / Actions:
  - [a_rename_collection](#a_rename_collection)
- 给定 / Given: A non-default collection contains records and has a name.
- 旅程 / Journeys:
  - [j_triage_inbox](#j_triage_inbox)
- 负向检查 / Negative check: Renaming must not move records out of the collection, create a second collection, or allow the inbox to be renamed.
- 规则 / Rules:
  - [r_collection_naming](#r_collection_naming)
  - [r_organization_revisable](#r_organization_revisable)
  - [r_local_persistence](#r_local_persistence)
- 则 / Then: The collection displays the new name while retaining its identifier and all filed records, and the new name persists after reopening.
- 当 / When: The owner renames it to another nonblank, non-duplicate name.

### as_move_refile_revisable
**as_move_refile_revisable**

- 操作 / Actions:
  - [a_move_record](#a_move_record)
- 给定 / Given: A record is filed in an owner-created collection that holds several records.
- 旅程 / Journeys:
  - [j_triage_inbox](#j_triage_inbox)
- 负向检查 / Negative check: The move must not be restricted to a single refiling, must not leave the record in two collections at once or in none, and must not lose either collection's eligibility to receive the record again.
- 规则 / Rules:
  - [r_organization_revisable](#r_organization_revisable)
  - [r_single_collection](#r_single_collection)
- 则 / Then: Each move succeeds, the record is shown only in its current collection, its identifier, URL, and creation time are unchanged, and the resulting assignment persists after the application is reopened.
- 当 / When: The owner moves that record to another existing collection and later moves it again, including back to the inbox.

## Scope options

### core_personal_library
**Core personal library**

- 依赖 / Dependencies:
- 额外操作 / Extra actions:
- 旅程 / Journeys:
  - [j_capture_return](#j_capture_return)
  - [j_triage_inbox](#j_triage_inbox)
  - [j_find_known_link](#j_find_known_link)
- 理由 / Rationale: The irreducible product: deterministic save from a URL, durable local records, an inbox plus owner-created collections, single-record move and edit, collection browsing and cross-field search, and return to the original page. Every element traces to the fixed scenario or the leaf's defining core; nothing here comes from upstream feature breadth. Shipping this slice alone yields a usable private library.

### metadata_assistance
**Optional metadata assistance**

- 依赖 / Dependencies:
  - core_personal_library
- 额外操作 / Extra actions:
  - [a_fetch_metadata](#a_fetch_metadata)
- 旅程 / Journeys:
  - [j_capture_return](#j_capture_return)
- 理由 / Rationale: Fetched titles and descriptions reduce typing but must never be a save precondition, because the scenario requires keeping a link before deciding to process it. This slice adds only the explicitly invoked fetch, must disclose any third-party request, and must leave manual entry fully usable when the service fails.

### organization_refinement
**Collection renaming**

- 依赖 / Dependencies:
  - core_personal_library
- 额外操作 / Extra actions:
  - [a_rename_collection](#a_rename_collection)
- 旅程 / Journeys:
  - [j_triage_inbox](#j_triage_inbox)
- 理由 / Rationale: A lightweight structural-maintenance capability separated from the core because the scenario requires creating and moving, not renaming. When added it must preserve record membership and identifiers and must never allow the fixed inbox to be renamed.

### retrieval_refinement
**Usage-based ordering**

- 依赖 / Dependencies:
  - core_personal_library
- 额外操作 / Extra actions:
  - [a_sort_records](#a_sort_records)
- 旅程 / Journeys:
  - [j_find_known_link](#j_find_known_link)
- 理由 / Rationale: Newest-added ordering suffices for a young collection; recently-opened and most-opened orderings help a large accumulated library. They stay optional because the scenario asks to find a link rather than to control sorting, and retained open statistics carry unresolved privacy questions.

## Basis

### b_scenario
**The product exists so a person can retain an external page seen but not processable now, and later find it again and return to the original page.**

- 依赖 / Dependencies:
- 形态 / Kind: requirement
- 来源 / Sources:
  - [scenario](#scenario)
- 说明 / Statement: The product exists so a person can retain an external page seen but not processable now, and later find it again and return to the original page.

### b_leaf_core
**A bookmark manager is defined by four properties: records anchored to an external address, deliberate capture rather than automatic logging, a persistent accumulating personal library, and owner-controlled organization and retrieval. The form of organization is an implementation choice.**

- 依赖 / Dependencies:
- 形态 / Kind: requirement
- 来源 / Sources:
  - [leaf-definition](#leaf-definition)
- 说明 / Statement: A bookmark manager is defined by four properties: records anchored to an external address, deliberate capture rather than automatic logging, a persistent accumulating personal library, and owner-controlled organization and retrieval. The form of organization is an implementation choice.

### b_flow_save
**The first actor step is an explicit save of a page the user wants to remember, made while browsing and without requiring immediate processing.**

- 依赖 / Dependencies:
  - b_scenario
- 形态 / Kind: requirement
- 来源 / Sources:
  - [flow-1](#flow-1)
- 说明 / Statement: The first actor step is an explicit save of a page the user wants to remember, made while browsing and without requiring immediate processing.

### b_flow_classify
**At save time the user may choose one simple category such as 待购, 家居改造, or 以后看看, and the user can create categories and move existing records between them.**

- 依赖 / Dependencies:
  - b_leaf_core
- 形态 / Kind: requirement
- 来源 / Sources:
  - [flow-2](#flow-2)
- 说明 / Statement: At save time the user may choose one simple category such as 待购, 家居改造, or 以后看看, and the user can create categories and move existing records between them.

### b_flow_inbox
**An unsorted link may first enter a default category and be moved to a better place later.**

- 依赖 / Dependencies:
  - b_flow_classify
- 形态 / Kind: requirement
- 来源 / Sources:
  - [flow-3](#flow-3)
- 说明 / Statement: An unsorted link may first enter a default category and be moved to a better place later.

### b_flow_retrieve
**When ready to act, the user opens the personal library and locates the earlier link by browsing categories or by keyword search, both scoped to records they already saved.**

- 依赖 / Dependencies:
  - b_scenario
- 形态 / Kind: requirement
- 来源 / Sources:
  - [flow-4](#flow-4)
- 说明 / Statement: When ready to act, the user opens the personal library and locates the earlier link by browsing categories or by keyword search, both scoped to records they already saved.

### b_flow_return
**The final actor step is opening a record and returning to the original page to continue buying, reading, or referencing; the application does not take over content consumption.**

- 依赖 / Dependencies:
  - b_leaf_core
- 形态 / Kind: requirement
- 来源 / Sources:
  - [flow-5](#flow-5)
- 说明 / Statement: The final actor step is opening a record and returning to the original page to continue buying, reading, or referencing; the application does not take over content consumption.

### b_up_local
**At the pinned commit the README describes the application as privacy-focused and local-first, storing bookmarks in browser IndexedDB with no accounts, servers, or tracking, and the declared store is a Dexie database named BookmarkDB with one bookmarks table. This is static document and code evidence only, not a runtime claim.**

- 依赖 / Dependencies:
- 形态 / Kind: upstream_observation
- 来源 / Sources:
  - [source-2](#source-2)
  - [source-4](#source-4)
- 说明 / Statement: At the pinned commit the README describes the application as privacy-focused and local-first, storing bookmarks in browser IndexedDB with no accounts, servers, or tracking, and the declared store is a Dexie database named BookmarkDB with one bookmarks table. This is static document and code evidence only, not a runtime claim.

### b_up_model
**The upstream Bookmark type contains id, title, url, hostname, favicon, description, tags string array, isPinned, isArchived, visitCount, createdAt, and visitedAt; it has no collection or folder field, no separate tag entity, no deletion marker, and no manual ordering field.**

- 依赖 / Dependencies:
- 形态 / Kind: upstream_observation
- 来源 / Sources:
  - [source-4](#source-4)
- 说明 / Statement: The upstream Bookmark type contains id, title, url, hostname, favicon, description, tags string array, isPinned, isArchived, visitCount, createdAt, and visitedAt; it has no collection or folder field, no separate tag entity, no deletion marker, and no manual ordering field.

### b_up_tags
**Upstream organization is tag-only: sidebar tag counts are aggregated from each record's tags array and sorted alphabetically, tags are filtered as multi-select AND with a reset action, and no collection creation, naming, or move interface appears in the observed files.**

- 依赖 / Dependencies:
- 形态 / Kind: upstream_observation
- 来源 / Sources:
  - [source-3](#source-3)
  - [source-4](#source-4)
- 说明 / Statement: Upstream organization is tag-only: sidebar tag counts are aggregated from each record's tags array and sorted alphabetically, tags are filtered as multi-select AND with a reset action, and no collection creation, naming, or move interface appears in the observed files.

### b_up_search
**The upstream search field matches only the record title as a lowercased substring, with a placeholder explicitly saying search by title; URL, hostname, description, and tags are not searched. The library is split into Home and Archived tabs.**

- 依赖 / Dependencies:
- 形态 / Kind: upstream_observation
- 来源 / Sources:
  - [source-3](#source-3)
  - [source-4](#source-4)
- 说明 / Statement: The upstream search field matches only the record title as a lowercased substring, with a placeholder explicitly saying search by title; URL, hostname, description, and tags are not searched. The library is split into Home and Archived tabs.

### b_up_capture_cost
**Upstream save validation requires a valid http or https URL, a title of at most 100 characters, a required description of at most 280 characters, and one to five tags of at most 30 characters each; the URL input additionally hard-caps entry at 100 characters while the validation schema sets no URL length limit.**

- 依赖 / Dependencies:
- 形态 / Kind: upstream_observation
- 来源 / Sources:
  - [source-3](#source-3)
- 说明 / Statement: Upstream save validation requires a valid http or https URL, a title of at most 100 characters, a required description of at most 280 characters, and one to five tags of at most 30 characters each; the URL input additionally hard-caps entry at 100 characters while the validation schema sets no URL length limit.

### b_up_metadata
**Upstream metadata retrieval is a manually triggered button that calls api.microlink.io for title, description, and logo, then proxies the logo through images.weserv.nl and a Google favicon endpoint; failures are only logged to the console and the form remains manually fillable.**

- 依赖 / Dependencies:
- 形态 / Kind: upstream_observation
- 来源 / Sources:
  - [source-3](#source-3)
- 说明 / Statement: Upstream metadata retrieval is a manually triggered button that calls api.microlink.io for title, description, and logo, then proxies the logo through images.weserv.nl and a Google favicon endpoint; failures are only logged to the console and the form remains manually fillable.

### b_up_open
**The upstream Visit action calls window.open with the record URL in a new tab using noopener and noreferrer, and also serves Copy URL from the same overflow menu; the card title is not itself a link, so opening requires the menu.**

- 依赖 / Dependencies:
- 形态 / Kind: upstream_observation
- 来源 / Sources:
  - [source-3](#source-3)
- 说明 / Statement: The upstream Visit action calls window.open with the record URL in a new tab using noopener and noreferrer, and also serves Copy URL from the same overflow menu; the card title is not itself a link, so opening requires the menu.

### b_up_visit
**The same Visit action sets visitedAt to the current time and increments visitCount before writing the record back to IndexedDB; no other observed action changes those values.**

- 依赖 / Dependencies:
- 形态 / Kind: upstream_observation
- 来源 / Sources:
  - [source-3](#source-3)
- 说明 / Statement: The same Visit action sets visitedAt to the current time and increments visitCount before writing the record back to IndexedDB; no other observed action changes those values.

### b_up_sort
**Upstream sorting places pinned records first, then applies the chosen strategy: recently visited by visitedAt descending, most visited by visitCount descending, with createdAt descending as the fallback and newest-added as the default.**

- 依赖 / Dependencies:
- 形态 / Kind: upstream_observation
- 来源 / Sources:
  - [source-3](#source-3)
  - [source-4](#source-4)
- 说明 / Statement: Upstream sorting places pinned records first, then applies the chosen strategy: recently visited by visitedAt descending, most visited by visitCount descending, with createdAt descending as the fallback and newest-added as the default.

### b_up_archive_delete
**Upstream offers Home and Archived tabs, toggles isArchived while clearing the pin on archive, and exposes deletion only for archived records: the record is removed from IndexedDB immediately and a toast Undo re-inserts it. There is no trash view, and unarchived records cannot be deleted from the observed interface.**

- 依赖 / Dependencies:
- 形态 / Kind: upstream_observation
- 来源 / Sources:
  - [source-3](#source-3)
  - [source-4](#source-4)
- 说明 / Statement: Upstream offers Home and Archived tabs, toggles isArchived while clearing the pin on archive, and exposes deletion only for archived records: the record is removed from IndexedDB immediately and a toast Undo re-inserts it. There is no trash view, and unarchived records cannot be deleted from the observed interface.

### b_up_dedupe
**Upstream record identifiers are random values created at save time and the primary key is that identifier rather than the URL; the observed save path performs no same-URL lookup, so duplicate addresses can coexist and no merge logic appears in the observed files.**

- 依赖 / Dependencies:
- 形态 / Kind: upstream_observation
- 来源 / Sources:
  - [source-3](#source-3)
  - [source-4](#source-4)
- 说明 / Statement: Upstream record identifiers are random values created at save time and the primary key is that identifier rather than the URL; the observed save path performs no same-URL lookup, so duplicate addresses can coexist and no merge logic appears in the observed files.

### b_design_collection
**Design proposal: organize the product with one optional level of owner-created collections plus a mandatory default inbox, because the scenario speaks of 归类, moving between 归类, and a 默认归类, while the upstream tag-only model cannot express an unsorted waiting area. Tags stay optional labels rather than a second navigation structure.**

- 依赖 / Dependencies:
  - b_flow_classify
  - b_flow_inbox
- 形态 / Kind: design_inference
- 来源 / Sources:
  - [scenario](#scenario)
  - [flow-2](#flow-2)
  - [flow-3](#flow-3)
  - [source-4](#source-4)
- 说明 / Statement: Design proposal: organize the product with one optional level of owner-created collections plus a mandatory default inbox, because the scenario speaks of 归类, moving between 归类, and a 默认归类, while the upstream tag-only model cannot express an unsorted waiting area. Tags stay optional labels rather than a second navigation structure.

### b_design_minimal
**Design proposal: require only the URL to save; derive the title from fetched metadata or the hostname, and leave description, tags, and explicit collection optional, because the scenario is about capture before processing. This deliberately relaxes the upstream requirement for a description and at least one tag.**

- 依赖 / Dependencies:
  - b_flow_save
- 形态 / Kind: design_inference
- 来源 / Sources:
  - [flow-1](#flow-1)
  - [source-3](#source-3)
- 说明 / Statement: Design proposal: require only the URL to save; derive the title from fetched metadata or the hostname, and leave description, tags, and explicit collection optional, because the scenario is about capture before processing. This deliberately relaxes the upstream requirement for a description and at least one tag.

### b_design_local
**Design proposal: persist the single-owner library in local browser storage and state explicitly that it is scoped to one browser profile. No account system is introduced, and cross-device synchronization is excluded rather than implied by the word persistent.**

- 依赖 / Dependencies:
  - b_up_local
- 形态 / Kind: design_inference
- 来源 / Sources:
  - [scenario](#scenario)
  - [source-2](#source-2)
  - [source-4](#source-4)
- 说明 / Statement: Design proposal: persist the single-owner library in local browser storage and state explicitly that it is scoped to one browser profile. No account system is introduced, and cross-device synchronization is excluded rather than implied by the word persistent.

### b_design_open
**Design proposal: make opening the original page a directly visible primary action on the record and its detail view rather than a hidden menu item, keep the library open behind the new tab, and let opening update optional usage metadata without changing the record's filing state.**

- 依赖 / Dependencies:
  - b_flow_return
  - b_up_open
- 形态 / Kind: design_inference
- 来源 / Sources:
  - [flow-5](#flow-5)
  - [source-3](#source-3)
- 说明 / Statement: Design proposal: make opening the original page a directly visible primary action on the record and its detail view rather than a hidden menu item, keep the library open behind the new tab, and let opening update optional usage metadata without changing the record's filing state.

### b_design_search
**Design proposal: search titles, URLs, hostnames, descriptions, and tags together, combine the query with one active collection, and default to newest-added ordering with optional recently-opened and most-opened orderings. This broadens the upstream title-only search because users often remember a domain or a phrase from the description.**

- 依赖 / Dependencies:
  - b_flow_retrieve
  - b_up_search
- 形态 / Kind: design_inference
- 来源 / Sources:
  - [flow-4](#flow-4)
  - [source-3](#source-3)
- 说明 / Statement: Design proposal: search titles, URLs, hostnames, descriptions, and tags together, combine the query with one active collection, and default to newest-added ordering with optional recently-opened and most-opened orderings. This broadens the upstream title-only search because users often remember a domain or a phrase from the description.

### b_design_dedupe
**Design proposal: prevent a second record for the same normalized URL and route the owner to the existing record, using trimming, host lowercasing, and trailing-slash removal as the baseline. The upstream model uses a random primary key and contains no duplicate check.**

- 依赖 / Dependencies:
  - b_leaf_core
  - b_up_dedupe
- 形态 / Kind: design_inference
- 来源 / Sources:
  - [leaf-definition](#leaf-definition)
  - [source-3](#source-3)
  - [source-4](#source-4)
- 说明 / Statement: Design proposal: prevent a second record for the same normalized URL and route the owner to the existing record, using trimming, host lowercasing, and trailing-slash removal as the baseline. The upstream model uses a random primary key and contains no duplicate check.

### b_design_metadata
**Design proposal: treat metadata fetch as an optional, explicitly invoked convenience that discloses any third-party request and never blocks manual entry or saving. The upstream use of microlink and weserv is reference only, not a required dependency.**

- 依赖 / Dependencies:
  - b_up_metadata
  - b_design_minimal
- 形态 / Kind: design_inference
- 来源 / Sources:
  - [flow-1](#flow-1)
  - [source-3](#source-3)
- 说明 / Statement: Design proposal: treat metadata fetch as an optional, explicitly invoked convenience that discloses any third-party request and never blocks manual entry or saving. The upstream use of microlink and weserv is reference only, not a required dependency.

### b_design_limits
**Design proposal: do not carry the upstream field length ceilings or the 100-character URL input cap into the product definition, because they are implementation details unsupported by the scenario; the new product's limits remain open pending product confirmation.**

- 依赖 / Dependencies:
  - b_up_capture_cost
- 形态 / Kind: design_inference
- 来源 / Sources:
  - [source-3](#source-3)
- 说明 / Statement: Design proposal: do not carry the upstream field length ceilings or the 100-character URL input cap into the product definition, because they are implementation details unsupported by the scenario; the new product's limits remain open pending product confirmation.

### b_design_tags
**Design proposal: keep tags as optional free-form string labels on records, usable for recall and search, without a tag sidebar, tag counts, or tag administration, because the scenario's organizing axis is a single collection and upstream tag-only navigation would compete with it.**

- 依赖 / Dependencies:
  - b_up_tags
  - b_flow_classify
- 形态 / Kind: design_inference
- 来源 / Sources:
  - [flow-2](#flow-2)
  - [source-3](#source-3)
- 说明 / Statement: Design proposal: keep tags as optional free-form string labels on records, usable for recall and search, without a tag sidebar, tag counts, or tag administration, because the scenario's organizing axis is a single collection and upstream tag-only navigation would compete with it.

### b_design_no_archive
**Design proposal: leave pinning, archiving, unread flags, and read-later state out of the core, because archive is easily mistaken for another collection and the scenario defines a single organizing axis with no clutter-management step.**

- 依赖 / Dependencies:
  - b_up_archive_delete
  - b_design_collection
- 形态 / Kind: design_inference
- 来源 / Sources:
  - [source-3](#source-3)
- 说明 / Statement: Design proposal: leave pinning, archiving, unread flags, and read-later state out of the core, because archive is easily mistaken for another collection and the scenario defines a single organizing axis with no clutter-management step.

### b_design_removal
**Design proposal: keep deletion out of the core flow; if removal is later added it must be recoverable and clearly distinct from collection organization, rather than copying the upstream coupling of archive with immediate physical delete and toast undo.**

- 依赖 / Dependencies:
  - b_up_archive_delete
- 形态 / Kind: design_inference
- 来源 / Sources:
  - [source-3](#source-3)
- 说明 / Statement: Design proposal: keep deletion out of the core flow; if removal is later added it must be recoverable and clearly distinct from collection organization, rather than copying the upstream coupling of archive with immediate physical delete and toast undo.

### b_unknown_runtime
**Unknown and not_run: the pinned upstream application was never installed, built, started, or operated in a browser. Every upstream statement is a static reading of five files, and runtime behavior such as real persistence, metadata-service responses, or interaction details is not established.**

- 依赖 / Dependencies:
- 形态 / Kind: unknown
- 来源 / Sources:
  - [source-1](#source-1)
  - [source-2](#source-2)
  - [source-3](#source-3)
  - [source-4](#source-4)
  - [source-5](#source-5)
- 说明 / Statement: Unknown and not_run: the pinned upstream application was never installed, built, started, or operated in a browser. Every upstream statement is a static reading of five files, and runtime behavior such as real persistence, metadata-service responses, or interaction details is not established.

### b_unknown_coverage
**Unknown: the snapshot covers only LICENSE, README.md, src/App.tsrx, src/includes/store.ts, and src/includes/utils.ts. Missing package manifest, entry module, components, and styles mean the repository as a whole cannot be claimed to lack import/export, sync, sharing, trash, deduplication, tag management, or routing.**

- 依赖 / Dependencies:
- 形态 / Kind: unknown
- 来源 / Sources:
  - [source-1](#source-1)
  - [source-2](#source-2)
  - [source-3](#source-3)
  - [source-4](#source-4)
  - [source-5](#source-5)
- 说明 / Statement: Unknown: the snapshot covers only LICENSE, README.md, src/App.tsrx, src/includes/store.ts, and src/includes/utils.ts. Missing package manifest, entry module, components, and styles mean the repository as a whole cannot be claimed to lack import/export, sync, sharing, trash, deduplication, tag management, or routing.

### b_unknown_build
**Unknown: no dependency manifest, lockfile, entry module, or build configuration is available, and framework, styling, database, and validation version compatibility was not verified, so whether the pinned commit builds or runs is unestablished.**

- 依赖 / Dependencies:
- 形态 / Kind: unknown
- 来源 / Sources:
  - [source-1](#source-1)
  - [source-2](#source-2)
- 说明 / Statement: Unknown: no dependency manifest, lockfile, entry module, or build configuration is available, and framework, styling, database, and validation version compatibility was not verified, so whether the pinned commit builds or runs is unestablished.

### b_unknown_persistence
**Unknown: persistence across reloads, browser restarts, private windows, and storage eviction is inferred from IndexedDB usage in the upstream code but was not tested. The new reference requires persistence while limiting it to one local browser profile.**

- 依赖 / Dependencies:
  - b_up_local
- 形态 / Kind: unknown
- 来源 / Sources:
  - [source-4](#source-4)
- 说明 / Statement: Unknown: persistence across reloads, browser restarts, private windows, and storage eviction is inferred from IndexedDB usage in the upstream code but was not tested. The new reference requires persistence while limiting it to one local browser profile.

### b_unknown_metadata
**Unknown: success rate, rate limits, cross-origin behavior, response fields, and privacy impact of external metadata and icon services were not tested, and whether the new product should call any third party at all remains a product decision.**

- 依赖 / Dependencies:
  - b_up_metadata
- 形态 / Kind: unknown
- 来源 / Sources:
  - [source-3](#source-3)
- 说明 / Statement: Unknown: success rate, rate limits, cross-origin behavior, response fields, and privacy impact of external metadata and icon services were not tested, and whether the new product should call any third party at all remains a product decision.

### b_unknown_dedupe
**Unknown: beyond trimming whitespace, lowercasing the host, and removing a trailing slash, the comparison surface is undefined; query strings, fragments, and case-sensitive paths have no agreed treatment, and the upstream code offers no deduplication logic to reference.**

- 依赖 / Dependencies:
  - b_up_dedupe
- 形态 / Kind: unknown
- 来源 / Sources:
  - [source-3](#source-3)
  - [source-4](#source-4)
- 说明 / Statement: Unknown: beyond trimming whitespace, lowercasing the host, and removing a trailing slash, the comparison surface is undefined; query strings, fragments, and case-sensitive paths have no agreed treatment, and the upstream code offers no deduplication logic to reference.

### b_unknown_volume
**Unknown: expected library size, search latency targets, index requirements, and whether pagination or virtualized rendering is needed have no source data, so the reference specifies no pagination behavior.**

- 依赖 / Dependencies:
- 形态 / Kind: unknown
- 来源 / Sources:
  - [leaf-definition](#leaf-definition)
- 说明 / Statement: Unknown: expected library size, search latency targets, index requirements, and whether pagination or virtualized rendering is needed have no source data, so the reference specifies no pagination behavior.

### b_unknown_removal
**Unknown: removal of saved links is not described by the scenario. Deletion and trash are excluded from the core; upstream permits deletion only for archived records and removes them immediately with a toast undo.**

- 依赖 / Dependencies:
- 形态 / Kind: unknown
- 来源 / Sources:
  - [scenario](#scenario)
  - [source-3](#source-3)
- 说明 / Statement: Unknown: removal of saved links is not described by the scenario. Deletion and trash are excluded from the core; upstream permits deletion only for archived records and removes them immediately with a toast undo.

### b_unknown_cross_device
**Unknown: the scenario requires persistence across sessions but does not confirm cross-device or cross-browser access. The leaf's category discussion mentions multi-device use, while this fixed product shape limits persistence to one local browser profile and excludes synchronization.**

- 依赖 / Dependencies:
  - b_design_local
- 形态 / Kind: unknown
- 来源 / Sources:
  - [scenario](#scenario)
  - [leaf-definition](#leaf-definition)
  - [source-2](#source-2)
- 说明 / Statement: Unknown: the scenario requires persistence across sessions but does not confirm cross-device or cross-browser access. The leaf's category discussion mentions multi-device use, while this fixed product shape limits persistence to one local browser profile and excludes synchronization.

### b_unknown_localization
**Unknown: interface language, date formatting, time-zone display, and whether the Chinese collection names are examples only remain undecided; upstream strings are English and dates are hard-coded to the en-IN locale with day and abbreviated month.**

- 依赖 / Dependencies:
- 形态 / Kind: unknown
- 来源 / Sources:
  - [source-5](#source-5)
- 说明 / Statement: Unknown: interface language, date formatting, time-zone display, and whether the Chinese collection names are examples only remain undecided; upstream strings are English and dates are hard-coded to the en-IN locale with day and abbreviated month.

### b_unknown_preset
**Unknown: whether 待购, 家居改造, and 以后看看 should exist as first-run sample collections or be created by the owner is not settled; the design baseline starts with an empty library plus a default inbox and treats those names as examples.**

- 依赖 / Dependencies:
  - b_design_collection
- 形态 / Kind: unknown
- 来源 / Sources:
  - [flow-2](#flow-2)
  - [flow-3](#flow-3)
- 说明 / Statement: Unknown: whether 待购, 家居改造, and 以后看看 should exist as first-run sample collections or be created by the owner is not settled; the design baseline starts with an empty library plus a default inbox and treats those names as examples.

### b_unknown_limits
**Unknown: no evidence establishes desired maximum lengths for URL, title, description, or tags, nor a maximum tag count or record count, so the reference imposes no such ceiling and validates only that the URL is an absolute http or https address.**

- 依赖 / Dependencies:
  - b_up_capture_cost
- 形态 / Kind: unknown
- 来源 / Sources:
  - [source-3](#source-3)
- 说明 / Statement: Unknown: no evidence establishes desired maximum lengths for URL, title, description, or tags, nor a maximum tag count or record count, so the reference imposes no such ceiling and validates only that the URL is an absolute http or https address.

### b_unknown_usage
**Unknown: whether retaining open counts and last-opened times is acceptable is not confirmed; upstream records both and sorts by them, while the scenario only asks to return to the page.**

- 依赖 / Dependencies:
  - b_up_visit
- 形态 / Kind: unknown
- 来源 / Sources:
  - [scenario](#scenario)
  - [source-3](#source-3)
- 说明 / Statement: Unknown: whether retaining open counts and last-opened times is acceptable is not confirmed; upstream records both and sorts by them, while the scenario only asks to return to the page.

## Gaps

### g_upstream_not_run
**The upstream snapshot records upstream_status and application_runtime_status as not_run: dependencies were not installed, the project was not built or started, and no browser interaction occurred. Every upstream observation is a static file reading and no execution result is claimed.**

- 操作 / Actions:
- 核心缺口 / Core gap: False
- Resolution: Keep runtime behavior explicitly unknown; never cite upstream as proof that persistence, metadata fetch, opening, or any interaction works.
- 说明 / Statement: The upstream snapshot records upstream_status and application_runtime_status as not_run: dependencies were not installed, the project was not built or started, and no browser interaction occurred. Every upstream observation is a static file reading and no execution result is claimed.

### g_partial_repository
**Only five files are present at the pinned commit. The absence of a feature in those files cannot establish that the repository lacks import/export, synchronization, sharing, trash, deduplication, tag management, or routing.**

- 操作 / Actions:
- 核心缺口 / Core gap: False
- Resolution: Limit scope claims to the observed files; decide product inclusion and exclusion from the scenario and the leaf, never from silence in the partial snapshot.
- 说明 / Statement: Only five files are present at the pinned commit. The absence of a feature in those files cannot establish that the repository lacks import/export, synchronization, sharing, trash, deduplication, tag management, or routing.

### g_build_unverified
**No package manifest, lockfile, entry module, or build configuration is available, and framework, styling, database, and validation version compatibility was not verified. Whether the pinned commit builds or runs is unknown.**

- 操作 / Actions:
- 核心缺口 / Core gap: False
- Resolution: Treat upstream as documentary evidence only; any implementation of this reference is a new build, not a claim that the upstream code runs.
- 说明 / Statement: No package manifest, lockfile, entry module, or build configuration is available, and framework, styling, database, and validation version compatibility was not verified. Whether the pinned commit builds or runs is unknown.

### g_persistence_unverified
**Persistence across reloads, browser restarts, private windows, and storage eviction is inferred from IndexedDB usage in the upstream code but was not tested. The reference requires persistence while limiting it to one local browser profile.**

- 操作 / Actions:
  - [a_save_bookmark](#a_save_bookmark)
  - [a_edit_bookmark](#a_edit_bookmark)
  - [a_move_record](#a_move_record)
- 核心缺口 / Core gap: False
- Resolution: Acceptance testing for this reference must perform a real close-and-reopen check in the target browser; until then persistence is a requirement, not an observed result.
- 说明 / Statement: Persistence across reloads, browser restarts, private windows, and storage eviction is inferred from IndexedDB usage in the upstream code but was not tested. The reference requires persistence while limiting it to one local browser profile.

### g_metadata_service
**External metadata and icon services were not exercised; their availability, privacy implications, and failure presentation are unknown, and upstream exposes failures only through the console.**

- 操作 / Actions:
  - [a_fetch_metadata](#a_fetch_metadata)
  - [a_save_bookmark](#a_save_bookmark)
- 核心缺口 / Core gap: False
- Resolution: Keep metadata assistance optional and non-blocking; test and disclose any chosen provider, or implement the optional slice without third-party calls.
- 说明 / Statement: External metadata and icon services were not exercised; their availability, privacy implications, and failure presentation are unknown, and upstream exposes failures only through the console.

### g_preset_collections
**Whether the example categories 待购, 家居改造, and 以后看看 ship as preset collections or are created by the owner on first use is not confirmed.**

- 操作 / Actions:
  - [a_save_bookmark](#a_save_bookmark)
  - [a_create_collection](#a_create_collection)
- 核心缺口 / Core gap: False
- Resolution: Baseline decision: start with an empty library and only the default inbox; confirm with the product owner before adding presets.
- 说明 / Statement: Whether the example categories 待购, 家居改造, and 以后看看 ship as preset collections or are created by the owner on first use is not confirmed.

### g_multi_membership
**The scenario says 一个简单归类, which suggests one collection per record, but whether a record may belong to several collections is not explicitly confirmed.**

- 操作 / Actions:
  - [a_save_bookmark](#a_save_bookmark)
  - [a_move_record](#a_move_record)
- 核心缺口 / Core gap: False
- Resolution: Model one collection per record plus optional tags; if multi-collection membership becomes a requirement, the object model and move semantics must be revised.
- 说明 / Statement: The scenario says 一个简单归类, which suggests one collection per record, but whether a record may belong to several collections is not explicitly confirmed.

### g_cross_device_scope
**The scenario requires persistence across sessions but does not confirm multi-device or multi-browser access. The leaf's category description mentions multi-device use, while the fixed product shape is a single-person accumulating collection.**

- 操作 / Actions:
  - [a_save_bookmark](#a_save_bookmark)
  - [a_browse_collection](#a_browse_collection)
- 核心缺口 / Core gap: False
- Resolution: Exclude synchronization from this boundary and state the local-profile limitation explicitly; revisit only if multi-device access becomes a requirement.
- 说明 / Statement: The scenario requires persistence across sessions but does not confirm multi-device or multi-browser access. The leaf's category description mentions multi-device use, while the fixed product shape is a single-person accumulating collection.

### g_dedupe_granularity
**Normalization beyond trimming whitespace, lowercasing the host, and dropping a trailing slash is undefined; query parameters, fragments, and case-sensitive paths have no agreed treatment, and upstream has no deduplication logic to reference.**

- 操作 / Actions:
  - [a_save_bookmark](#a_save_bookmark)
  - [a_edit_bookmark](#a_edit_bookmark)
- 核心缺口 / Core gap: False
- Resolution: Ship the baseline normalization for the core and record the unresolved comparison surface for product confirmation; do not add merge tooling.
- 说明 / Statement: Normalization beyond trimming whitespace, lowercasing the host, and dropping a trailing slash is undefined; query parameters, fragments, and case-sensitive paths have no agreed treatment, and upstream has no deduplication logic to reference.

### g_scale
**Expected record counts, search latency targets, index requirements, and the need for pagination or virtualized rendering are unknown.**

- 操作 / Actions:
  - [a_search_records](#a_search_records)
  - [a_browse_collection](#a_browse_collection)
- 核心缺口 / Core gap: False
- Resolution: Render the loaded result set without pagination in the core and measure against a realistic library before adding performance work.
- 说明 / Statement: Expected record counts, search latency targets, index requirements, and the need for pagination or virtualized rendering are unknown.

### g_localization
**Interface language, date and time formatting, time zone presentation, and the status of Chinese collection names as examples versus required labels are undecided.**

- 操作 / Actions:
  - [a_browse_collection](#a_browse_collection)
  - [a_edit_bookmark](#a_edit_bookmark)
- 核心缺口 / Core gap: False
- Resolution: Treat the language as a product decision; avoid asserting locale-specific formatting in acceptance criteria until confirmed.
- 说明 / Statement: Interface language, date and time formatting, time zone presentation, and the status of Chinese collection names as examples versus required labels are undecided.

### g_removal
**The scenario does not describe removing a saved link. The reference excludes deletion and trash from the core, while upstream exposes deletion only for archived records with an immediate physical delete and a toast undo.**

- 操作 / Actions:
- 核心缺口 / Core gap: False
- Resolution: Do not implement destructive removal in the core; if removal is requested, design a recoverable flow and keep it clearly separate from collection organization.
- 说明 / Statement: The scenario does not describe removing a saved link. The reference excludes deletion and trash from the core, while upstream exposes deletion only for archived records with an immediate physical delete and a toast undo.

### g_field_limits
**No evidence justifies limits on URL, title, description, or tag length, or a maximum tag count for the new product. Upstream's 100-character URL input cap conflicts with its own validation schema and was not behaviorally tested.**

- 操作 / Actions:
  - [a_save_bookmark](#a_save_bookmark)
  - [a_edit_bookmark](#a_edit_bookmark)
- 核心缺口 / Core gap: False
- Resolution: Impose no reference-level ceilings; validate only the URL scheme and shape, and set practical limits later from usability evidence.
- 说明 / Statement: No evidence justifies limits on URL, title, description, or tag length, or a maximum tag count for the new product. Upstream's 100-character URL input cap conflicts with its own validation schema and was not behaviorally tested.

### g_usage_privacy
**Whether retaining open counts and last-opened times is acceptable is not confirmed. Upstream records both and sorts by them, while the scenario only asks to return to the page.**

- 操作 / Actions:
  - [a_open_record](#a_open_record)
  - [a_sort_records](#a_sort_records)
- 核心缺口 / Core gap: False
- Resolution: Treat usage metadata as optional supporting information; acceptance of the core depends on opening the page, not on statistics.
- 说明 / Statement: Whether retaining open counts and last-opened times is acceptable is not confirmed. Upstream records both and sorts by them, while the scenario only asks to return to the page.

### g_capture_channels
**The scenario describes saving while browsing but does not name a capture channel. Browser extension, bookmarklet, and mobile share target are excluded from this web-only boundary, so today a save starts from the library's add action with a URL at hand.**

- 操作 / Actions:
  - [a_save_bookmark](#a_save_bookmark)
- 核心缺口 / Core gap: False
- Resolution: Keep the library add form as the only capture surface for this boundary; revisit only if capture away from the application becomes a stated requirement.
- 说明 / Statement: The scenario describes saving while browsing but does not name a capture channel. Browser extension, bookmarklet, and mobile share target are excluded from this web-only boundary, so today a save starts from the library's add action with a URL at hand.

### g_tags_scope
**Tags are preserved as optional labels following the scenario's evidence and upstream behavior, but whether tag filter checkboxes, tag counts, or tag management belong in the product is not confirmed.**

- 操作 / Actions:
  - [a_save_bookmark](#a_save_bookmark)
  - [a_search_records](#a_search_records)
- 核心缺口 / Core gap: False
- Resolution: Keep tags as searchable free-form fields on records; exclude a tag sidebar and tag administration from the core boundary.
- 说明 / Statement: Tags are preserved as optional labels following the scenario's evidence and upstream behavior, but whether tag filter checkboxes, tag counts, or tag management belong in the product is not confirmed.
