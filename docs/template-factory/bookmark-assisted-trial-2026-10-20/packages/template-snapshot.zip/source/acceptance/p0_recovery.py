#!/usr/bin/env python3
'''P0 行为验收组：删除恢复与错误合同。

覆盖 A09、A10。仅使用 Python 3.12 标准库并复用 acceptance/common.py：
A09 通过真实 HTML 保存/删除/恢复/归类删除表单验证软删除、归类迁移与
跨重启持久化；A10 同时验证 JSON 未知 id、畸形请求以及 HTML 表单校验与
恢复。以 --case 派发，未知用例显式失败；每个用例对真实目标执行正向与
硬负向行为断言，向 stdout 输出单个 atlas.acceptance-result.v1 JSON，失
败时以非零码退出。
'''

from __future__ import annotations

import os
import re
import sys
import uuid
from html.parser import HTMLParser
from urllib.parse import parse_qsl, quote, urlsplit

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

import common

_NUMBER_RE = re.compile('[0-9]+')
_VOID_TAGS = frozenset({
    'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input',
    'link', 'meta', 'param', 'source', 'track', 'wbr',
})


def _normalize_space(value):
    return ' '.join(str(value or '').split())


class _Field:
    def __init__(self, attrs):
        self.attrs = attrs
        self.name = attrs.get('name')
        self.value = attrs.get('value', '')
        self.type = (attrs.get('type') or 'text').lower()
        self.checked = 'checked' in attrs


class _Option:
    def __init__(self, attrs):
        self.attrs = attrs
        self.value = attrs.get('value')
        self.text = ''
        self.selected = 'selected' in attrs

    def resolved_value(self):
        if self.value is not None:
            return self.value
        return self.text.strip()


class _Select:
    def __init__(self, attrs):
        self.attrs = attrs
        self.name = attrs.get('name')
        self.options = []

    def selected_value(self):
        for option in self.options:
            if option.selected:
                return option.resolved_value()
        if self.options:
            return self.options[0].resolved_value()
        return ''


class _Textarea:
    def __init__(self, attrs):
        self.attrs = attrs
        self.name = attrs.get('name')
        self.text = ''


class _Form:
    def __init__(self, attrs):
        self.attrs = attrs
        self.action = (attrs.get('action') or '').strip()
        self.method = (attrs.get('method') or 'get').strip().lower()
        self.testid = attrs.get('data-testid') or ''
        self.fields = []
        self.selects = []
        self.textareas = []

    def has_name(self, name):
        if any(field.name == name for field in self.fields):
            return True
        if any(select.name == name for select in self.selects):
            return True
        return any(textarea.name == name for textarea in self.textareas)

    def value(self, name):
        for field in reversed(self.fields):
            if field.name == name:
                return field.value
        for select in reversed(self.selects):
            if select.name == name:
                return select.selected_value()
        for textarea in reversed(self.textareas):
            if textarea.name == name:
                return textarea.text
        return None


class _Anchor:
    def __init__(self, attrs):
        self.attrs = attrs
        self.href = attrs.get('href') or ''
        self.testid = attrs.get('data-testid') or ''
        self.text = ''


class _Row:
    def __init__(self, attrs):
        self.attrs = attrs
        self.record_id = attrs.get('data-record-id') or ''
        self.anchors = []
        self.text = ''


def _action_path(action):
    text = (action or '').strip()
    if not text:
        return ''
    try:
        path = urlsplit(text).path
    except ValueError:
        return text
    if not path:
        return ''
    if not path.startswith('/'):
        path = '/' + path
    return path.rstrip('/') or '/'


def _path_of(href):
    try:
        path = urlsplit(href).path
    except ValueError:
        return ''
    if not path:
        return ''
    if not path.startswith('/'):
        path = '/' + path
    return path.rstrip('/') or '/'


def _form_path(form, default):
    action = (form.action or '').strip()
    return action if action else default


class _Document:
    def __init__(self):
        self.forms = []
        self.anchors = []
        self.rows = []
        self.testids = []
        self.start_tags = []
        self.text = ''

    def save_form(self):
        for form in self.forms:
            if form.method == 'post' and _action_path(form.action) == '/bookmarks/new':
                return form
        for form in self.forms:
            if form.method == 'post' and form.has_name('url'):
                return form
        return None


class _HtmlReader(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.doc = _Document()
        self._form = None
        self._select = None
        self._option = None
        self._textarea = None
        self._anchor = None
        self._row = None
        self._testid_stack = []

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        attributes = {
            str(key).lower(): ('' if value is None else value)
            for key, value in attrs
        }
        self.doc.start_tags.append((tag, attributes))
        testid = attributes.get('data-testid') or ''
        if testid:
            entry = {'tag': tag, 'attrs': attributes, 'text': ''}
            self.doc.testids.append(entry)
            if tag not in _VOID_TAGS:
                self._testid_stack.append((tag, entry))
        if tag == 'form':
            self._finish_form()
            self._form = _Form(attributes)
        elif tag == 'input':
            if self._form is not None:
                self._form.fields.append(_Field(attributes))
        elif tag == 'select':
            self._finish_select()
            if self._form is not None:
                self._select = _Select(attributes)
        elif tag == 'option':
            self._finish_option()
            if self._select is not None:
                self._option = _Option(attributes)
        elif tag == 'textarea':
            self._finish_textarea()
            if self._form is not None:
                self._textarea = _Textarea(attributes)
        elif tag == 'a':
            self._finish_anchor()
            self._anchor = _Anchor(attributes)
        elif tag == 'tr' and testid == 'record-row':
            self._finish_row()
            self._row = _Row(attributes)

    def handle_data(self, data):
        if not data:
            return
        self.doc.text += data
        if self._row is not None:
            self._row.text += data
        if self._anchor is not None:
            self._anchor.text += data
        if self._option is not None:
            self._option.text += data
        if self._textarea is not None:
            self._textarea.text += data
        for _, entry in self._testid_stack:
            entry['text'] += data

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag == 'a':
            self._finish_anchor()
        elif tag == 'option':
            self._finish_option()
        elif tag == 'select':
            self._finish_select()
        elif tag == 'textarea':
            self._finish_textarea()
        elif tag == 'form':
            self._finish_form()
        elif tag == 'tr':
            self._finish_row()
        if tag in _VOID_TAGS:
            return
        if self._testid_stack and self._testid_stack[-1][0] == tag:
            self._testid_stack.pop()

    def _finish_option(self):
        if self._option is None:
            return
        option = self._option
        self._option = None
        if self._select is not None:
            self._select.options.append(option)

    def _finish_select(self):
        self._finish_option()
        if self._select is None:
            return
        select = self._select
        self._select = None
        if self._form is not None:
            self._form.selects.append(select)

    def _finish_textarea(self):
        if self._textarea is None:
            return
        textarea = self._textarea
        self._textarea = None
        if self._form is not None:
            self._form.textareas.append(textarea)

    def _finish_anchor(self):
        if self._anchor is None:
            return
        anchor = self._anchor
        self._anchor = None
        self.doc.anchors.append(anchor)
        if self._row is not None:
            self._row.anchors.append(anchor)

    def _finish_row(self):
        if self._row is None:
            return
        row = self._row
        self._row = None
        self.doc.rows.append(row)

    def _finish_form(self):
        self._finish_select()
        self._finish_textarea()
        if self._form is None:
            return
        form = self._form
        self._form = None
        self.doc.forms.append(form)

    def finalize(self):
        self._finish_anchor()
        self._finish_row()
        self._finish_form()


def _parse_html(text):
    reader = _HtmlReader()
    reader.feed(text or '')
    reader.close()
    reader.finalize()
    return reader.doc


def _form_fields(form, overrides=None, omit=()):
    fields = {}
    for field in form.fields:
        name = field.name
        if not name:
            continue
        if field.type in ('submit', 'button', 'reset', 'file', 'image'):
            continue
        if field.type in ('checkbox', 'radio') and not field.checked:
            continue
        fields[name] = field.value
    for select in form.selects:
        if select.name:
            fields[select.name] = select.selected_value()
    for textarea in form.textareas:
        if textarea.name:
            fields[textarea.name] = textarea.text
    if overrides:
        for key, value in overrides.items():
            name = str(key)
            if value is None:
                fields.pop(name, None)
            else:
                fields[name] = str(value)
    for name in omit:
        fields.pop(name, None)
    return fields


def _first_form(doc, testid):
    for form in doc.forms:
        if form.testid == testid:
            return form
    return None


def _form_for_category(doc, testid, category_id):
    forms = [
        form for form in doc.forms
        if form.testid == testid and form.has_name('category_id')
    ]
    for form in forms:
        if form.value('category_id') == category_id:
            return form
    if len(forms) == 1:
        return forms[0]
    return None


def _find_record_form(doc, testid, record_id):
    for form in doc.forms:
        if form.testid == testid and form.value('record_id') == record_id:
            return form
    return None


def _form_error_text(doc):
    parts = []
    for entry in doc.testids:
        testid = (entry['attrs'].get('data-testid') or '').lower()
        if testid == 'form-error' or 'form-error' in testid:
            text = _normalize_space(entry['text'])
            if text:
                parts.append(text)
    return ' '.join(parts)


def _category_count_values(doc):
    result = {}
    for entry in doc.testids:
        if entry['attrs'].get('data-testid') != 'category-count':
            continue
        category_id = entry['attrs'].get('data-category-id')
        if not category_id:
            continue
        numbers = _NUMBER_RE.findall(entry['text'])
        value = int(numbers[-1]) if numbers else None
        result.setdefault(category_id, []).append(value)
    return result


def _row_ids(doc):
    return {row.record_id for row in doc.rows if row.record_id}


def _row_for_url(doc, url):
    for row in doc.rows:
        for anchor in row.anchors:
            if anchor.testid == 'record-open-link' and anchor.href == url:
                return row
    for row in doc.rows:
        for anchor in row.anchors:
            if anchor.href == url:
                return row
    return None


def _select_values(form, name):
    for select in form.selects:
        if select.name == name:
            return [option.resolved_value() for option in select.options]
    return []


def _unique_url(tag):
    token = f'{tag}-{uuid.uuid4().hex[:12]}'
    return f'https://{token}.atlas-acceptance.example/{token}'


def _unique_category(tag):
    return f'atlas-{tag}-{uuid.uuid4().hex[:10]}'


def _safe_json(response):
    try:
        return response.json()
    except Exception:
        return None


def _extract_record(payload):
    if isinstance(payload, dict):
        for key in ('bookmark', 'record', 'data', 'item'):
            value = payload.get(key)
            if isinstance(value, dict):
                return value
        return payload
    return None


def _extract_category(payload):
    if isinstance(payload, dict):
        value = payload.get('category')
        if isinstance(value, dict):
            return value
        return payload
    return None


def _extract_list(payload, keys):
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in keys:
            value = payload.get(key)
            if isinstance(value, list):
                return value
    return None


def _record_id(record):
    if isinstance(record, dict) and record.get('id') is not None:
        return str(record['id'])
    return None


def _record_url(record):
    if isinstance(record, dict) and record.get('url') is not None:
        return str(record['url'])
    return None


def _record_title(record):
    if isinstance(record, dict) and record.get('title') is not None:
        return str(record['title'])
    return None


def _record_description(record):
    if isinstance(record, dict):
        for key in ('description', 'desc'):
            if record.get(key) is not None:
                return str(record[key])
    return None


def _record_category_name(record, categories):
    if not isinstance(record, dict):
        return None
    by_id = {}
    names = set()
    for item in categories or []:
        if isinstance(item, dict) and item.get('id') is not None:
            if item.get('name') is not None:
                by_id[str(item['id'])] = str(item['name'])
                names.add(str(item['name']))
    for key in ('category', 'category_name', 'categoryName'):
        value = record.get(key)
        if isinstance(value, str):
            if value in names:
                return value
            if value in by_id:
                return by_id[value]
            return value
        if isinstance(value, dict) and value.get('name') is not None:
            return str(value['name'])
    for key in ('category_id', 'categoryId'):
        value = record.get(key)
        if value is not None and str(value) in by_id:
            return by_id[str(value)]
    return None


def _record_category_id(record):
    if not isinstance(record, dict):
        return None
    for key in ('category_id', 'categoryId'):
        value = record.get(key)
        if value is not None:
            return str(value)
    value = record.get('category')
    if isinstance(value, dict) and value.get('id') is not None:
        return str(value['id'])
    return None


def _category_names(categories):
    return {
        str(item['name']) for item in categories
        if isinstance(item, dict) and item.get('name') is not None
    }


def _category_ids(categories):
    return {
        str(item['id']) for item in categories
        if isinstance(item, dict) and item.get('id') is not None
    }


def _find_category_by_name(categories, name):
    if name is None:
        return None
    target = str(name).casefold()
    for item in categories:
        if isinstance(item, dict) and item.get('name') is not None:
            if str(item['name']).casefold() == target:
                return item
    return None


def _find_category_by_id(categories, category_id):
    if category_id is None:
        return None
    target = str(category_id)
    for item in categories:
        if isinstance(item, dict) and item.get('id') is not None:
            if str(item['id']) == target:
                return item
    return None


def _default_category(categories):
    for item in categories:
        if isinstance(item, dict) and item.get('is_default'):
            return item
    return _find_category_by_name(categories, common.DEFAULT_CATEGORY)


def _error_code(response):
    payload = _safe_json(response)
    if isinstance(payload, dict):
        error = payload.get('error')
        if isinstance(error, dict) and error.get('code') is not None:
            return str(error['code'])
        for key in ('code', 'error_code'):
            if payload.get(key) is not None:
                return str(payload[key])
    return None


def _bookmark_path(bookmark_id):
    return '/api/bookmarks/' + quote(str(bookmark_id), safe='')


def _move_path(bookmark_id):
    return _bookmark_path(bookmark_id) + '/move'


def _category_path(category_id):
    return '/api/categories/' + quote(str(category_id), safe='')


def _record_ids(records):
    return {
        record_id for record_id in (_record_id(record) for record in records)
        if record_id
    }


def _record_urls(records):
    return {
        url for url in (_record_url(record) for record in records)
        if url
    }


def _fetch_bookmarks(client, recorder, aid, params=None):
    response = client.get('/api/bookmarks', params=params)
    recorder.expect_status(response, 200, aid=f'{aid}-status')
    payload = _safe_json(response)
    records = _extract_list(payload, ('bookmarks', 'items', 'data', 'records'))
    recorder.check(
        f'{aid}-shape',
        isinstance(records, list),
        f'GET /api/bookmarks 必须返回 JSON 数组，实际 {type(payload).__name__}',
    )
    return records if isinstance(records, list) else []


def _fetch_categories(client, recorder, aid):
    response = client.get('/api/categories')
    recorder.expect_status(response, 200, aid=f'{aid}-status')
    payload = _safe_json(response)
    categories = _extract_list(payload, ('categories', 'items', 'data'))
    recorder.check(
        f'{aid}-shape',
        isinstance(categories, list),
        f'GET /api/categories 必须返回 JSON 数组，实际 {type(payload).__name__}',
    )
    return categories if isinstance(categories, list) else []


def _category_signature(categories):
    items = []
    for item in categories:
        if not isinstance(item, dict):
            continue
        items.append((
            str(item.get('id')),
            str(item.get('name')),
            bool(item.get('is_default')),
            item.get('count'),
        ))
    return tuple(sorted(items, key=lambda entry: (entry[0], entry[1])))


def _record_map(records, categories):
    result = {}
    for record in records:
        record_id = _record_id(record)
        if record_id:
            result[record_id] = _record_category_name(record, categories)
    return result


def _snapshot(client, recorder, aid):
    categories = _fetch_categories(client, recorder, f'{aid}-categories')
    records = _fetch_bookmarks(
        client, recorder, f'{aid}-records', params={'include_trashed': 1}
    )
    return (_category_signature(categories), _record_map(records, categories))


def _check_unchanged(recorder, aid, before, after, label):
    recorder.check(
        f'{aid}-categories-unchanged',
        before[0] == after[0],
        f'{label} 后分类集合（含计数）不变：{len(before[0])} -> {len(after[0])}',
    )
    recorder.check(
        f'{aid}-records-unchanged',
        before[1] == after[1],
        f'{label} 后记录集合与归类归属不变：{len(before[1])} -> {len(after[1])}',
    )


def _follow_303(client, recorder, response, aid, expected_path=None, expected_query=None):
    recorder.expect_status(response, 303, aid=f'{aid}-status')
    location = response.location
    if not recorder.check(
        f'{aid}-location',
        bool(location),
        f'303 响应必须带 Location，实际 {location!r}',
    ):
        return None, None
    parts = urlsplit(location)
    if expected_path is not None:
        actual_path = parts.path.rstrip('/') or '/'
        wanted_path = expected_path.rstrip('/') or '/'
        recorder.check(
            f'{aid}-path',
            actual_path == wanted_path,
            f'303 Location={location!r} 的路径={actual_path!r}（期望 {wanted_path!r}）',
        )
    if expected_query:
        actual_query = dict(parse_qsl(parts.query, keep_blank_values=True))
        for key, value in expected_query.items():
            actual_value = actual_query.get(key)
            recorder.check(
                f'{aid}-query-{key}',
                actual_value == value,
                f'303 Location={location!r} 的 {key}={actual_value!r}（期望 {value!r}）',
            )
    page = client.get(location, accept='text/html')
    recorder.expect_status(page, 200, aid=f'{aid}-follow-status')
    return page, location


def _home_page(client, recorder, aid, params=None):
    response = client.get('/', params=params, accept='text/html')
    recorder.expect_status(response, 200, aid=f'{aid}-status')
    recorder.check(
        f'{aid}-content-type',
        'text/html' in response.content_type.lower(),
        f'GET / Content-Type={response.content_type!r}',
    )
    return _parse_html(response.text)


def _categories_page(client, recorder, aid):
    response = client.get('/categories', accept='text/html')
    recorder.expect_status(response, 200, aid=f'{aid}-status')
    recorder.check(
        f'{aid}-content-type',
        'text/html' in response.content_type.lower(),
        f'GET /categories Content-Type={response.content_type!r}',
    )
    return _parse_html(response.text)


def _expect_html_error(recorder, response, aid, label, expected_status):
    recorder.check(
        f'{aid}-no-5xx',
        response.status < 500,
        f'{label} -> HTTP {response.status}（校验类错误不得产生 5xx）',
    )
    recorder.expect_status(
        response,
        expected_status,
        aid=f'{aid}-status',
        detail=f'{label} -> HTTP {response.status}（期望 {expected_status}）',
    )
    doc = _parse_html(response.text)
    error_text = _form_error_text(doc)
    recorder.check(
        f'{aid}-form-error',
        bool(error_text),
        f'{label} 显示可读 form-error，实际 {error_text!r}',
    )
    return doc


def _get_record_json(client, recorder, aid, record_id):
    response = client.get(_bookmark_path(record_id))
    recorder.expect_status(response, 200, aid=f'{aid}-status')
    payload = _safe_json(response)
    record = _extract_record(payload)
    recorder.check(
        f'{aid}-shape',
        isinstance(record, dict),
        f'GET /api/bookmarks/{record_id} 返回 JSON 对象，实际 {type(payload).__name__}',
    )
    return record if isinstance(record, dict) else None


def _save_form_from_home(client, recorder, aid, params=None):
    page = client.get('/', params=params, accept='text/html')
    recorder.expect_status(page, 200, aid=f'{aid}-status')
    doc = _parse_html(page.text)
    form = doc.save_form()
    recorder.check(
        f'{aid}-save-form',
        form is not None,
        '首页含 action=/bookmarks/new 且 method=post 的真实保存表单',
    )
    return doc, form


def _check_json_error(recorder, response, prefix, expected_status, expected_code, label):
    recorder.check(
        f'{prefix}-no-5xx',
        response.status < 500,
        f'{label} -> HTTP {response.status}（校验类错误不得产生 5xx）',
    )
    recorder.expect_status(
        response,
        expected_status,
        aid=f'{prefix}-status',
        detail=f'{label} -> HTTP {response.status}（期望 {expected_status}）',
    )
    code = _error_code(response)
    recorder.check(
        f'{prefix}-code',
        code == expected_code,
        f'{label} 错误码={code!r}（期望 {expected_code}）',
    )


def _a09_live_flow(client, recorder):
    health = client.get('/api/health')
    recorder.expect_status(health, 200, aid='a09-live-health-status')

    _, save_form = _save_form_from_home(client, recorder, 'a09-live')
    if save_form is None:
        return

    name = _unique_category('a09-live')
    url = _unique_url('a09-live')
    title = f'A09 恢复标题 {uuid.uuid4().hex[:8]}'
    description = f'A09 恢复描述 {uuid.uuid4().hex[:8]}'
    response = client.post_form(
        _form_path(save_form, '/bookmarks/new'),
        _form_fields(save_form, {
            'url': url,
            'title': title,
            'description': description,
            'category': name,
        }),
        follow_redirects=False,
        accept='text/html',
    )
    page, _ = _follow_303(
        client, recorder, response, 'a09-live-save', expected_path='/'
    )
    if page is None:
        return
    doc = _parse_html(page.text)
    row = _row_for_url(doc, url)
    if row is None:
        doc = _home_page(client, recorder, 'a09-live-save-fallback')
        row = _row_for_url(doc, url)
    if not recorder.check(
        'a09-live-saved-row',
        row is not None,
        f'真实保存表单提交后 HTML 列表出现 url={url!r} 的记录行',
    ):
        return
    record_id = row.record_id
    if not recorder.check(
        'a09-live-saved-id', bool(record_id), f'保存记录 data-record-id={record_id!r}'
    ):
        return

    categories = _fetch_categories(client, recorder, 'a09-live-categories')
    category = _find_category_by_name(categories, name)
    category_id = _record_id(category)
    if not recorder.check(
        'a09-live-category-created',
        bool(category_id),
        f'保存新归类名 {name!r} 后 /api/categories 自动创建该归类 id={category_id!r}',
    ):
        return
    count_before = category.get('count') if isinstance(category, dict) else None
    recorder.check(
        'a09-live-count-before-delete',
        count_before == 1,
        f'删除前归类 {name!r} API count={count_before!r}（期望 1）',
    )

    record = _get_record_json(client, recorder, 'a09-live-record', record_id)
    if record is not None:
        recorder.check(
            'a09-live-record-url',
            _record_url(record) == url,
            f'保存后 url={_record_url(record)!r}（期望 {url!r}）',
        )
        recorder.check(
            'a09-live-record-title',
            _record_title(record) == title,
            f'保存后 title={_record_title(record)!r}（期望 {title!r}）',
        )
        recorder.check(
            'a09-live-record-description',
            _record_description(record) == description,
            f'保存后 description={_record_description(record)!r}（期望 {description!r}）',
        )
        recorder.check(
            'a09-live-record-category',
            _record_category_name(record, categories) == name,
            f'保存后 category={_record_category_name(record, categories)!r}（期望 {name!r}）',
        )

    delete_form = _find_record_form(doc, 'record-delete-form', record_id)
    if delete_form is None:
        doc = _home_page(
            client, recorder, 'a09-live-delete-home', params={'category': name}
        )
        delete_form = _find_record_form(doc, 'record-delete-form', record_id)
    if not recorder.check(
        'a09-live-delete-form',
        delete_form is not None,
        f'记录 {record_id!r} 行含 record-delete-form',
    ):
        return
    response = client.post_form(
        _form_path(delete_form, '/'),
        _form_fields(delete_form),
        follow_redirects=False,
        accept='text/html',
    )
    page, _ = _follow_303(
        client, recorder, response, 'a09-live-delete',
        expected_path='/', expected_query={'trash': '1'},
    )
    if page is None:
        return
    trash_doc = _parse_html(page.text)

    default_doc = _home_page(client, recorder, 'a09-live-default-after-delete')
    recorder.check(
        'a09-live-default-excluded',
        record_id not in _row_ids(default_doc),
        f'删除后默认列表排除记录 {record_id!r}',
    )
    category_doc = _home_page(
        client, recorder, 'a09-live-category-list-after-delete',
        params={'category': name},
    )
    recorder.check(
        'a09-live-category-list-excluded',
        record_id not in _row_ids(category_doc),
        f'删除后归类 {name!r} 的活动列表排除记录 {record_id!r}',
    )

    categories_after = _fetch_categories(client, recorder, 'a09-live-categories-after')
    category_after = _find_category_by_id(categories_after, category_id)
    count_after = category_after.get('count') if isinstance(category_after, dict) else None
    recorder.check(
        'a09-live-api-count-excluded',
        count_after == 0,
        f'删除后归类 {name!r} API count={count_after!r}（期望 0，只计活动记录）',
    )
    categories_page = _categories_page(
        client, recorder, 'a09-live-categories-page-after-delete'
    )
    for label, count_doc in (('home', default_doc), ('categories', categories_page)):
        values = _category_count_values(count_doc).get(category_id, [])
        recorder.check(
            f'a09-live-html-count-{label}',
            bool(values) and all(value == 0 for value in values),
            f'删除后 {label} HTML 归类 {name!r} 计数={values!r}（期望 0）',
        )

    trashed = _fetch_bookmarks(
        client, recorder, 'a09-live-trashed',
        params={'category': name, 'include_trashed': 1},
    )
    recorder.check(
        'a09-live-soft-deleted',
        record_id in _record_ids(trashed),
        f'include_trashed=1 时记录 {record_id!r} 仍存在，证明删除是软删除',
    )

    restore_form = _find_record_form(trash_doc, 'record-restore-form', record_id)
    if restore_form is None:
        trash_doc = _home_page(
            client, recorder, 'a09-live-trash-refetch', params={'trash': 1}
        )
        restore_form = _find_record_form(trash_doc, 'record-restore-form', record_id)
    if not recorder.check(
        'a09-live-restore-form',
        restore_form is not None,
        f'/?trash=1 显示记录 {record_id!r} 的 record-restore-form',
    ):
        return

    response = client.post_form(
        _form_path(restore_form, '/'),
        _form_fields(restore_form),
        follow_redirects=False,
        accept='text/html',
    )
    page, _ = _follow_303(
        client, recorder, response, 'a09-live-restore',
        expected_path='/', expected_query={'category': name},
    )
    if page is None:
        return
    restored_doc = _parse_html(page.text)
    recorder.check(
        'a09-live-restored-row',
        record_id in _row_ids(restored_doc),
        f'恢复后归类页重新显示记录 {record_id!r}',
    )
    default_after = _home_page(client, recorder, 'a09-live-default-after-restore')
    recorder.check(
        'a09-live-restored-default-visible',
        record_id in _row_ids(default_after),
        f'恢复后默认列表重新显示记录 {record_id!r}',
    )
    categories_restored = _fetch_categories(
        client, recorder, 'a09-live-categories-after-restore'
    )
    category_restored = _find_category_by_id(categories_restored, category_id)
    count_restored = (
        category_restored.get('count') if isinstance(category_restored, dict) else None
    )
    recorder.check(
        'a09-live-count-after-restore',
        count_restored == 1,
        f'恢复后归类 {name!r} API count={count_restored!r}（期望 1）',
    )
    restored = _get_record_json(
        client, recorder, 'a09-live-restored-record', record_id
    )
    if restored is not None:
        recorder.check(
            'a09-live-restored-url',
            _record_url(restored) == url,
            f'恢复后 url={_record_url(restored)!r}（期望 {url!r}）',
        )
        recorder.check(
            'a09-live-restored-title',
            _record_title(restored) == title,
            f'恢复后 title={_record_title(restored)!r}（期望 {title!r}）',
        )
        recorder.check(
            'a09-live-restored-description',
            _record_description(restored) == description,
            f'恢复后 description={_record_description(restored)!r}（期望 {description!r}）',
        )
        recorder.check(
            'a09-live-restored-category',
            _record_category_name(restored, categories_restored) == name,
            f'恢复后 category={_record_category_name(restored, categories_restored)!r}（期望 {name!r}）',
        )


def _a09_category_migration(client, recorder):
    categories_page = _categories_page(client, recorder, 'a09-migrate-categories-page')
    create_form = _first_form(categories_page, 'category-create-form')
    if not recorder.check(
        'a09-migrate-create-form',
        create_form is not None and create_form.has_name('name'),
        'GET /categories 含 category-create-form 与 name 输入',
    ):
        return

    name = _unique_category('a09-migrate')
    response = client.post_form(
        _form_path(create_form, '/categories'),
        _form_fields(create_form, {'name': name}),
        follow_redirects=False,
        accept='text/html',
    )
    page, _ = _follow_303(
        client, recorder, response, 'a09-migrate-create', expected_path='/categories'
    )
    if page is None:
        return
    categories = _fetch_categories(client, recorder, 'a09-migrate-created')
    category = _find_category_by_name(categories, name)
    category_id = _record_id(category)
    if not recorder.check(
        'a09-migrate-created-id',
        bool(category_id),
        f'真实归类表单创建归类 {name!r} 后 id={category_id!r}',
    ):
        return

    _, save_form = _save_form_from_home(client, recorder, 'a09-migrate-save')
    if save_form is None:
        return
    url = _unique_url('a09-migrate')
    title = f'A09 迁移标题 {uuid.uuid4().hex[:8]}'
    description = f'A09 迁移描述 {uuid.uuid4().hex[:8]}'
    response = client.post_form(
        _form_path(save_form, '/bookmarks/new'),
        _form_fields(save_form, {
            'url': url,
            'title': title,
            'description': description,
            'category': name,
        }),
        follow_redirects=False,
        accept='text/html',
    )
    page, _ = _follow_303(
        client, recorder, response, 'a09-migrate-save', expected_path='/'
    )
    if page is None:
        return
    doc = _parse_html(page.text)
    row = _row_for_url(doc, url)
    if row is None:
        doc = _home_page(
            client, recorder, 'a09-migrate-save-fallback', params={'category': name}
        )
        row = _row_for_url(doc, url)
    if not recorder.check(
        'a09-migrate-saved-row',
        row is not None,
        f'在归类 {name!r} 中经真实保存表单创建记录 url={url!r}',
    ):
        return
    record_id = row.record_id
    if not recorder.check(
        'a09-migrate-saved-id', bool(record_id), f'迁移用例记录 id={record_id!r}'
    ):
        return
    saved = _get_record_json(client, recorder, 'a09-migrate-saved-record', record_id)
    if saved is not None:
        recorder.check(
            'a09-migrate-saved-category',
            _record_category_name(saved, categories) == name,
            f'保存后记录 category={_record_category_name(saved, categories)!r}（期望 {name!r}）',
        )

    delete_form = _find_record_form(doc, 'record-delete-form', record_id)
    if delete_form is None:
        doc = _home_page(
            client, recorder, 'a09-migrate-delete-home', params={'category': name}
        )
        delete_form = _find_record_form(doc, 'record-delete-form', record_id)
    if not recorder.check(
        'a09-migrate-delete-form',
        delete_form is not None,
        f'记录 {record_id!r} 行含 record-delete-form',
    ):
        return
    response = client.post_form(
        _form_path(delete_form, '/'),
        _form_fields(delete_form),
        follow_redirects=False,
        accept='text/html',
    )
    page, _ = _follow_303(
        client, recorder, response, 'a09-migrate-delete',
        expected_path='/', expected_query={'trash': '1'},
    )
    if page is None:
        return
    trash_doc = _parse_html(page.text)
    recorder.check(
        'a09-migrate-trashed-before-category-delete',
        _find_record_form(trash_doc, 'record-restore-form', record_id) is not None,
        f'删除归类前 /?trash=1 显示记录 {record_id!r} 的恢复表单',
    )

    categories_page = _categories_page(
        client, recorder, 'a09-migrate-delete-category-page'
    )
    category_delete_form = _form_for_category(
        categories_page, 'category-delete-form', category_id
    )
    if not recorder.check(
        'a09-migrate-category-delete-form',
        category_delete_form is not None,
        f'找到归类 {name!r} 的 category-delete-form',
    ):
        return
    response = client.post_form(
        _form_path(category_delete_form, '/categories'),
        _form_fields(category_delete_form, {'category_id': category_id}),
        follow_redirects=False,
        accept='text/html',
    )
    page, _ = _follow_303(
        client, recorder, response, 'a09-migrate-category-delete',
        expected_path='/categories',
    )
    if page is None:
        return

    categories_after = _fetch_categories(
        client, recorder, 'a09-migrate-categories-after'
    )
    recorder.check(
        'a09-migrate-category-gone',
        _find_category_by_id(categories_after, category_id) is None
        and _find_category_by_name(categories_after, name) is None,
        f'删除后归类 {name!r} 不再存在',
    )
    default_item = _default_category(categories_after)
    default_id = _record_id(default_item)
    if not recorder.check(
        'a09-migrate-default-id',
        bool(default_id),
        f'默认归类「{common.DEFAULT_CATEGORY}」id={default_id!r}',
    ):
        return

    migrated = _get_record_json(
        client, recorder, 'a09-migrate-record-after-category-delete', record_id
    )
    if migrated is not None:
        actual = _record_category_name(migrated, categories_after)
        recorder.check(
            'a09-migrate-record-default',
            actual == common.DEFAULT_CATEGORY,
            f'删除归类后软删记录 category={actual!r}（期望 {common.DEFAULT_CATEGORY!r}）',
        )
        actual_id = _record_category_id(migrated)
        if actual_id is not None:
            recorder.check(
                'a09-migrate-record-default-id',
                actual_id == default_id,
                f'删除归类后软删记录 category_id={actual_id!r}（期望默认归类 {default_id!r}）',
            )

    default_all = _fetch_bookmarks(
        client, recorder, 'a09-migrate-default-all',
        params={
            'category': common.DEFAULT_CATEGORY,
            'include_trashed': 1,
        },
    )
    recorder.check(
        'a09-migrate-soft-deleted-in-default',
        record_id in _record_ids(default_all),
        f'删除归类后软删记录 {record_id!r} 仍存在于「{common.DEFAULT_CATEGORY}」回收内容',
    )

    trash_doc = _home_page(
        client, recorder, 'a09-migrate-trash-after-category-delete', params={'trash': 1}
    )
    restore_form = _find_record_form(trash_doc, 'record-restore-form', record_id)
    if not recorder.check(
        'a09-migrate-still-restorable',
        restore_form is not None,
        f'删除归类后软删记录 {record_id!r} 仍在 /?trash=1 可恢复',
    ):
        return
    response = client.post_form(
        _form_path(restore_form, '/'),
        _form_fields(restore_form),
        follow_redirects=False,
        accept='text/html',
    )
    page, _ = _follow_303(
        client, recorder, response, 'a09-migrate-restore',
        expected_path='/', expected_query={'category': common.DEFAULT_CATEGORY},
    )
    if page is None:
        return
    default_active = _fetch_bookmarks(
        client, recorder, 'a09-migrate-default-active',
        params={'category': common.DEFAULT_CATEGORY},
    )
    recorder.check(
        'a09-migrate-restored-visible',
        record_id in _record_ids(default_active),
        f'恢复后记录 {record_id!r} 回到「{common.DEFAULT_CATEGORY}」活动列表',
    )
    restored = _get_record_json(
        client, recorder, 'a09-migrate-restored-record', record_id
    )
    if restored is not None:
        actual = _record_category_name(restored, categories_after)
        recorder.check(
            'a09-migrate-restored-category',
            actual == common.DEFAULT_CATEGORY,
            f'恢复后记录 category={actual!r}（期望 {common.DEFAULT_CATEGORY!r}）',
        )
        restored_category_id = _record_category_id(restored)
        if restored_category_id is not None:
            recorder.check(
                'a09-migrate-restored-category-id',
                restored_category_id == default_id,
                f'恢复后记录 category_id={restored_category_id!r}（期望 {default_id!r}）',
            )
    final_categories = _fetch_categories(
        client, recorder, 'a09-migrate-final-categories'
    )
    final_default = _find_category_by_id(final_categories, default_id)
    final_default_count = (
        final_default.get('count') if isinstance(final_default, dict) else None
    )
    recorder.check(
        'a09-migrate-no-orphan',
        final_default is not None
        and isinstance(final_default_count, int)
        and final_default_count >= 1,
        f'恢复后默认归类仍存在且 count={final_default_count!r}，记录无孤儿引用',
    )


def _a09_across_restart(args, recorder):
    first = common.launch_app(args.app_root, args.data_dir, 0)
    instance_dir = first.instance_dir
    record_id = None
    url = _unique_url('a09-restart')
    title = f'A09 重启标题 {uuid.uuid4().hex[:8]}'
    description = f'A09 重启描述 {uuid.uuid4().hex[:8]}'
    category_name = _unique_category('a09-restart')
    try:
        client = common.HttpClient(first.base_url)
        try:
            health = client.get('/api/health')
            recorder.expect_status(health, 200, aid='a09-restart-health-status')
            _, save_form = _save_form_from_home(
                client, recorder, 'a09-restart-save'
            )
            doc = None
            if save_form is not None:
                response = client.post_form(
                    _form_path(save_form, '/bookmarks/new'),
                    _form_fields(save_form, {
                        'url': url,
                        'title': title,
                        'description': description,
                        'category': category_name,
                    }),
                    follow_redirects=False,
                    accept='text/html',
                )
                page, _ = _follow_303(
                    client, recorder, response, 'a09-restart-save',
                    expected_path='/',
                )
                if page is not None:
                    doc = _parse_html(page.text)
                    row = _row_for_url(doc, url)
                    if row is None:
                        doc = _home_page(
                            client, recorder, 'a09-restart-save-fallback',
                            params={'category': category_name},
                        )
                        row = _row_for_url(doc, url)
                    if recorder.check(
                        'a09-restart-saved-row',
                        row is not None,
                        f'隔离实例经真实保存表单创建 url={url!r}',
                    ):
                        record_id = row.record_id
                        recorder.check(
                            'a09-restart-saved-id',
                            bool(record_id),
                            f'隔离实例记录 data-record-id={record_id!r}',
                        )
            if record_id:
                delete_form = _find_record_form(
                    doc, 'record-delete-form', record_id
                ) if doc is not None else None
                if delete_form is None:
                    doc = _home_page(
                        client, recorder, 'a09-restart-delete-home',
                        params={'category': category_name},
                    )
                    delete_form = _find_record_form(
                        doc, 'record-delete-form', record_id
                    )
                if recorder.check(
                    'a09-restart-delete-form',
                    delete_form is not None,
                    f'隔离实例记录 {record_id!r} 行含 record-delete-form',
                ):
                    response = client.post_form(
                        _form_path(delete_form, '/'),
                        _form_fields(delete_form),
                        follow_redirects=False,
                        accept='text/html',
                    )
                    page, _ = _follow_303(
                        client, recorder, response, 'a09-restart-delete',
                        expected_path='/', expected_query={'trash': '1'},
                    )
                    if page is not None:
                        trash_doc = _parse_html(page.text)
                        recorder.check(
                            'a09-restart-trash-form-before-stop',
                            _find_record_form(
                                trash_doc, 'record-restore-form', record_id
                            ) is not None,
                            f'停止前 /?trash=1 显示记录 {record_id!r} 的恢复表单',
                        )
                trashed = _fetch_bookmarks(
                    client, recorder, 'a09-restart-trashed-before-stop',
                    params={'include_trashed': 1},
                )
                recorder.check(
                    'a09-restart-soft-deleted-before-stop',
                    record_id in _record_ids(trashed),
                    f'停止前 include_trashed=1 仍包含记录 {record_id!r}',
                )
                default_doc = _home_page(
                    client, recorder, 'a09-restart-excluded-before-stop'
                )
                recorder.check(
                    'a09-restart-excluded-before-stop',
                    record_id not in _row_ids(default_doc),
                    f'停止前默认列表排除已删除记录 {record_id!r}',
                )
        finally:
            client.close()
    finally:
        common.stop_app(first)

    if not recorder.check(
        'a09-restart-prerequisite',
        bool(record_id) and bool(instance_dir),
        f'隔离实例未提供可重启的记录 id 或实例目录：record_id={record_id!r}',
    ):
        return

    second = common.launch_app(
        args.app_root, args.data_dir, 0, instance_dir=instance_dir
    )
    try:
        client = common.HttpClient(second.base_url)
        try:
            health = client.get('/api/health')
            recorder.expect_status(health, 200, aid='a09-restart2-health-status')
            default_doc = _home_page(
                client, recorder, 'a09-restart2-default'
            )
            recorder.check(
                'a09-restart2-still-excluded',
                record_id not in _row_ids(default_doc),
                f'重启后默认列表仍排除记录 {record_id!r}',
            )
            trashed = _fetch_bookmarks(
                client, recorder, 'a09-restart2-trashed',
                params={'include_trashed': 1},
            )
            recorder.check(
                'a09-restart2-trash-retained',
                record_id in _record_ids(trashed),
                f'重启后 include_trashed=1 仍包含记录 {record_id!r}',
            )
            categories = _fetch_categories(
                client, recorder, 'a09-restart2-categories'
            )
            recorder.check(
                'a09-restart2-category-retained',
                _find_category_by_name(categories, category_name) is not None,
                f'重启后归类 {category_name!r} 仍存在',
            )
            trash_doc = _home_page(
                client, recorder, 'a09-restart2-trash', params={'trash': 1}
            )
            restore_form = _find_record_form(
                trash_doc, 'record-restore-form', record_id
            )
            if not recorder.check(
                'a09-restart2-restore-form',
                restore_form is not None,
                f'重启后 /?trash=1 仍显示记录 {record_id!r} 的恢复表单',
            ):
                return
            response = client.post_form(
                _form_path(restore_form, '/'),
                _form_fields(restore_form),
                follow_redirects=False,
                accept='text/html',
            )
            page, _ = _follow_303(
                client, recorder, response, 'a09-restart2-restore',
                expected_path='/', expected_query={'category': category_name},
            )
            if page is None:
                return
            restored_doc = _parse_html(page.text)
            recorder.check(
                'a09-restart2-restored-visible',
                record_id in _row_ids(restored_doc),
                f'重启并恢复后记录 {record_id!r} 重新出现在列表',
            )
            restored = _get_record_json(
                client, recorder, 'a09-restart2-restored-record', record_id
            )
            if restored is not None:
                recorder.check(
                    'a09-restart2-restored-url',
                    _record_url(restored) == url,
                    f'重启并恢复后 url={_record_url(restored)!r}（期望 {url!r}）',
                )
                recorder.check(
                    'a09-restart2-restored-title',
                    _record_title(restored) == title,
                    f'重启并恢复后 title={_record_title(restored)!r}（期望 {title!r}）',
                )
                recorder.check(
                    'a09-restart2-restored-description',
                    _record_description(restored) == description,
                    f'重启并恢复后 description={_record_description(restored)!r}（期望 {description!r}）',
                )
                recorder.check(
                    'a09-restart2-restored-category',
                    _record_category_name(restored, categories) == category_name,
                    f'重启并恢复后 category={_record_category_name(restored, categories)!r}（期望 {category_name!r}）',
                )
        finally:
            client.close()
    finally:
        common.stop_app(second)


def _case_a09(args, recorder):
    client = common.HttpClient(args.base_url)
    try:
        _a09_live_flow(client, recorder)
        _a09_category_migration(client, recorder)
    finally:
        client.close()
    _a09_across_restart(args, recorder)


def _case_a10(args, recorder):
    client = common.HttpClient(args.base_url)
    try:
        health = client.get('/api/health')
        recorder.expect_status(health, 200, aid='a10-health-status')

        anchor_url = _unique_url('a10-anchor')
        anchor_title = f'A10 锚点 {uuid.uuid4().hex[:8]}'
        anchor_description = f'A10 锚点描述 {uuid.uuid4().hex[:8]}'
        created = client.post_json(
            '/api/bookmarks',
            {
                'url': anchor_url,
                'title': anchor_title,
                'description': anchor_description,
            },
        )
        recorder.expect_status(created, 201, aid='a10-anchor-create-status')
        anchor_id = _record_id(_extract_record(_safe_json(created)))
        if not recorder.check(
            'a10-anchor-create-id',
            bool(anchor_id),
            f'创建锚点记录返回 id={anchor_id!r}',
        ):
            return

        categories = _fetch_categories(client, recorder, 'a10-api-categories')
        before_state = _snapshot(client, recorder, 'a10-api-before')
        before_record = _get_record_json(
            client, recorder, 'a10-anchor-before', anchor_id
        )
        if before_record is None:
            return

        unknown = f'unknown-{uuid.uuid4().hex[:12]}'
        unknown_get = client.get(_bookmark_path(unknown))
        _check_json_error(
            recorder, unknown_get, 'a10-unknown-get', 404, 'not_found',
            f'GET /api/bookmarks/{unknown}',
        )
        unknown_patch = client.patch_json(
            _bookmark_path(unknown), {'title': 'A10 未知 id'}
        )
        _check_json_error(
            recorder, unknown_patch, 'a10-unknown-patch', 404, 'not_found',
            f'PATCH /api/bookmarks/{unknown}',
        )
        unknown_delete = client.request('DELETE', _bookmark_path(unknown))
        _check_json_error(
            recorder, unknown_delete, 'a10-unknown-delete', 404, 'not_found',
            f'DELETE /api/bookmarks/{unknown}',
        )
        unknown_move = client.post_json(
            _move_path(unknown), {'category': common.DEFAULT_CATEGORY}
        )
        _check_json_error(
            recorder, unknown_move, 'a10-unknown-move', 404, 'not_found',
            f'POST /api/bookmarks/{unknown}/move',
        )

        malformed = (
            ('save', 'POST', '/api/bookmarks', '{"url": '),
            ('patch', 'PATCH', _bookmark_path(anchor_id), '{"title": '),
            ('move', 'POST', _move_path(anchor_id), '{"category": '),
        )
        for label, method, path, body in malformed:
            response = client.request(
                method,
                path,
                data=body,
                headers={'Content-Type': 'application/json'},
            )
            _check_json_error(
                recorder, response, f'a10-malformed-{label}', 400, 'bad_request',
                f'{method} {path} 畸形 JSON',
            )

        after_state = _snapshot(client, recorder, 'a10-api-after')
        _check_unchanged(
            recorder, 'a10-api', before_state, after_state, '未知 id 与畸形 JSON 请求'
        )
        after_record = _get_record_json(
            client, recorder, 'a10-anchor-after', anchor_id
        )
        if after_record is not None:
            recorder.check(
                'a10-anchor-url-unchanged',
                _record_url(after_record) == _record_url(before_record),
                f'锚点 url={_record_url(after_record)!r}（未被修改）',
            )
            recorder.check(
                'a10-anchor-title-unchanged',
                _record_title(after_record) == _record_title(before_record),
                f'锚点 title={_record_title(after_record)!r}（未被修改）',
            )
            recorder.check(
                'a10-anchor-description-unchanged',
                _record_description(after_record) == _record_description(before_record),
                f'锚点 description={_record_description(after_record)!r}（未被修改）',
            )
            recorder.check(
                'a10-anchor-category-unchanged',
                _record_category_name(after_record, categories)
                == _record_category_name(before_record, categories),
                f'锚点 category={_record_category_name(after_record, categories)!r}（未被修改）',
            )

        _, save_form = _save_form_from_home(client, recorder, 'a10-html')
        if save_form is None:
            return
        token = uuid.uuid4().hex[:10]
        bad_url = f'atlas-a10-missing-scheme-{token}'
        corrected_url = _unique_url('a10-corrected')
        html_title = f'A10 表单标题 {token}'
        html_description = f'A10 表单描述 {token}'
        before_html_state = _snapshot(client, recorder, 'a10-html-before')
        before_html_ids = set(before_html_state[1])
        before_html_records = _fetch_bookmarks(
            client, recorder, 'a10-html-before-records',
            params={'include_trashed': 1},
        )
        before_html_total = len(_record_ids(before_html_records))
        before_urls = _record_urls(before_html_records)

        response = client.post_form(
            _form_path(save_form, '/bookmarks/new'),
            _form_fields(save_form, {
                'url': bad_url,
                'title': html_title,
                'description': html_description,
            }),
            follow_redirects=False,
            accept='text/html',
        )
        error_doc = _expect_html_error(
            recorder, response, 'a10-html-invalid-url', 'HTML 保存非法 URL', 400
        )
        error_form = error_doc.save_form()
        recorder.check(
            'a10-html-invalid-url-form',
            error_form is not None,
            'HTML 非法 URL 错误页保留可重新提交的保存表单',
        )
        if error_form is not None:
            retained_url = error_form.value('url')
            retained_title = error_form.value('title')
            retained_description = error_form.value('description')
            recorder.check(
                'a10-html-invalid-url-retained-url',
                retained_url == bad_url,
                f'错误页保留 url={retained_url!r}（期望 {bad_url!r}）',
            )
            recorder.check(
                'a10-html-invalid-url-retained-title',
                retained_title == html_title,
                f'错误页保留 title={retained_title!r}（期望 {html_title!r}）',
            )
            recorder.check(
                'a10-html-invalid-url-retained-description',
                retained_description == html_description,
                f'错误页保留 description={retained_description!r}（期望 {html_description!r}）',
            )
        after_invalid_state = _snapshot(client, recorder, 'a10-html-after-invalid')
        _check_unchanged(
            recorder, 'a10-html-invalid-url', before_html_state, after_invalid_state,
            'HTML 非法 URL',
        )
        after_invalid_records = _fetch_bookmarks(
            client, recorder, 'a10-html-after-invalid-records',
            params={'include_trashed': 1},
        )
        recorder.check(
            'a10-html-invalid-url-not-written',
            bad_url not in _record_urls(after_invalid_records),
            f'被拒绝的 url={bad_url!r} 不出现在记录集合',
        )

        if error_form is None:
            return
        response = client.post_form(
            _form_path(error_form, '/bookmarks/new'),
            _form_fields(error_form, {'url': corrected_url}),
            follow_redirects=False,
            accept='text/html',
        )
        page, _ = _follow_303(
            client, recorder, response, 'a10-html-corrected-save', expected_path='/'
        )
        if page is None:
            return
        corrected_doc = _parse_html(page.text)
        row = _row_for_url(corrected_doc, corrected_url)
        if row is None:
            corrected_doc = _home_page(
                client, recorder, 'a10-html-corrected-fallback'
            )
            row = _row_for_url(corrected_doc, corrected_url)
        if not recorder.check(
            'a10-html-corrected-row',
            row is not None,
            f'修正 URL 后列表出现 url={corrected_url!r} 的记录行',
        ):
            return
        corrected_id = row.record_id
        recorder.check(
            'a10-html-corrected-id',
            bool(corrected_id),
            f'修正后记录 data-record-id={corrected_id!r}',
        )
        after_corrected = _fetch_bookmarks(
            client, recorder, 'a10-html-after-corrected',
            params={'include_trashed': 1},
        )
        after_corrected_ids = _record_ids(after_corrected)
        after_corrected_urls = _record_urls(after_corrected)
        recorder.check(
            'a10-html-corrected-only-one',
            len(after_corrected_ids) == before_html_total + 1,
            f'修正后记录数 {before_html_total} -> {len(after_corrected_ids)}（只新增一条）',
        )
        recorder.check(
            'a10-html-corrected-no-invalid',
            bad_url not in after_corrected_urls and bad_url not in before_urls,
            f'非法 url={bad_url!r} 未写入记录集合',
        )
        recorder.check(
            'a10-html-corrected-single-title',
            sum(
                1 for record in after_corrected
                if _record_title(record) == html_title
            ) == 1,
            f'标题 {html_title!r} 仅对应一条记录',
        )
        if corrected_id:
            corrected_record = _get_record_json(
                client, recorder, 'a10-html-corrected-record', corrected_id
            )
            if corrected_record is not None:
                recorder.check(
                    'a10-html-corrected-url',
                    _record_url(corrected_record) == corrected_url,
                    f'修正后 url={_record_url(corrected_record)!r}（期望 {corrected_url!r}）',
                )
                recorder.check(
                    'a10-html-corrected-title',
                    _record_title(corrected_record) == html_title,
                    f'修正后 title={_record_title(corrected_record)!r}（期望 {html_title!r}）',
                )
                recorder.check(
                    'a10-html-corrected-description',
                    _record_description(corrected_record) == html_description,
                    f'修正后 description={_record_description(corrected_record)!r}（期望 {html_description!r}）',
                )

        categories_page = _categories_page(
            client, recorder, 'a10-categories-page'
        )
        create_form = _first_form(categories_page, 'category-create-form')
        if not recorder.check(
            'a10-category-create-form',
            create_form is not None and create_form.has_name('name'),
            'GET /categories 含 category-create-form 与 name 输入',
        ):
            return
        before_category_state = _snapshot(
            client, recorder, 'a10-category-before'
        )
        bad_name = 'x' * 121
        response = client.post_form(
            _form_path(create_form, '/categories'),
            _form_fields(create_form, {'name': bad_name}),
            follow_redirects=False,
            accept='text/html',
        )
        error_doc = _expect_html_error(
            recorder, response, 'a10-category-invalid', 'HTML 归类非法 name', 400
        )
        error_form = _first_form(error_doc, 'category-create-form')
        recorder.check(
            'a10-category-invalid-form',
            error_form is not None,
            'HTML 归类非法 name 错误页保留 category-create-form',
        )
        if error_form is not None:
            retained_name = error_form.value('name')
            recorder.check(
                'a10-category-invalid-retained',
                retained_name == bad_name,
                f'错误页保留 name={retained_name!r}（期望 {bad_name!r}）',
            )
        after_category_state = _snapshot(
            client, recorder, 'a10-category-after'
        )
        _check_unchanged(
            recorder, 'a10-category-invalid', before_category_state,
            after_category_state, 'HTML 归类非法 name',
        )
        categories_after = _fetch_categories(
            client, recorder, 'a10-category-after-list'
        )
        recorder.check(
            'a10-category-not-created',
            _find_category_by_name(categories_after, bad_name) is None,
            f'非法 name={bad_name!r} 未被创建为归类',
        )
    finally:
        client.close()


_HANDLERS = {
    'A09': _case_a09,
    'A10': _case_a10,
}


def main(argv=None):
    args = common.parse_case_args(argv)
    recorder = common.Recorder(args.case)
    handler = _HANDLERS.get(args.case)
    if handler is None:
        recorder.check(
            'dispatch',
            False,
            f'acceptance/p0_recovery.py 不实现用例 {args.case}（应由其他程序派发）',
        )
    else:
        try:
            handler(args, recorder)
        except common.AcceptanceError as exc:
            recorder.check('infrastructure', False, f'验收基础设施错误：{exc}')
        except Exception as exc:
            recorder.check(
                'unexpected-error',
                False,
                f'未预期错误：{type(exc).__name__}: {exc}',
            )
    return recorder.finish(args.case)


if __name__ == '__main__':
    sys.exit(main())
