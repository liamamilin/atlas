# 架构与契约

## 默认技术栈与理由

- 交付 profile：python-web。Python 3.12 标准库（http.server、sqlite3、urllib、json、html.parser），零第三方依赖；服务端渲染 HTML 表单，JSON API 与 HTML 适配器共用同一服务层。
- 备选 Flask/FastAPI 需安装依赖；Node + IndexedDB/SPA 需 npm/浏览器工具且把数据放在浏览器 profile。二者与离线、可独立验收、单用户本地库的约束冲突，故不采用。
- 数据文件位于应用 `--data-dir/bookmarks.sqlite3`；验收的每实例隔离目录由测试适配器创建，测试者 `--data-dir` 根目录不是应用数据库。
- 单用户、本地优先；无认证、无云同步。日常绑定 127.0.0.1；仅隔离验收网络使用 0.0.0.0。

## 数据模型（SQLite）

- `schema_meta(version INTEGER)`：迁移版本单行。启动时在一个事务内创建/升级 schema，v1 建表并写入预置归类；版本演进只通过事务化迁移，不回退、不依赖客户端存储。
- `categories(id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE COLLATE NOCASE, is_default INTEGER NOT NULL DEFAULT 0, position INTEGER NOT NULL, created_at INTEGER NOT NULL)`：仅新数据库首次初始化预置「未整理」(is_default=1)、「待购」、「家居改造」、「以后看看」；之后启动保留用户对非默认分类的合法删除或重命名，不重新补回旧预置名称。
- `bookmarks(id TEXT PRIMARY KEY, url TEXT NOT NULL, hostname TEXT NOT NULL, title TEXT NULL, description TEXT NULL, category_id TEXT NOT NULL REFERENCES categories(id), favicon_url TEXT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, trashed_at INTEGER NULL)`。
- 索引：category_id、created_at、hostname；url 不设唯一索引。P1/F14 的重复检测由服务层查询活动记录完成；P0 不启用重复拒绝。
- trashed_at 为 NULL 表示活动记录；非 NULL 为软删除。默认列表与计数只统计 trashed_at IS NULL；恢复清空 trashed_at。删除归类在单一事务内把该归类下的活动记录与软删除记录都改到默认归类，因此恢复不会产生无归类记录。
- 排序固定为 created_at DESC、id ASC；category 与 q 只作请求参数，不落库。

## URL 策略

- 记录 URL 必须是绝对、可解析的 HTTP(S) URL，且 hostname 有效且非空。单标签主机（如 http://localhost）与 IP 字面量均有效；不做 DNS 查询、可达性检查或目标页抓取。
- 保存与打开都保留用户提交的原始字符串（不补斜杠、不改大小写、不重写路径）；hostname 由解析结果派生。若 PATCH 更新 URL，必须用新 URL 重新派生 hostname。
- 拒绝：缺少 scheme、非 http/https、缺少/非法 hostname、无法解析的字符串；返回 400 invalid_url 且不写入。
- 上游 S04 记录点域名正则限制，S02 记录新记录包含派生 hostname；这些是固定来源观察。target 的绝对 HTTP(S) URL 解析、允许单标签 hostname 与保留原始 URL 文本，是本模板的 adjusted 设计，采用上述解析策略。
- 保存、打开、抓取三者分离：P0 保存与列表均不请求目标页；打开只产生浏览器导航或 /go 302。

## API、错误与状态合同

- `GET /api/health` → 200 JSON，含就绪与 schema 版本。
- `GET /api/categories` → 200 数组，每项 id、name、count、is_default；count 只计活动记录。
- `POST /api/categories` name → 201；重名 409 duplicate_category；空名或超过 120 字符 400 invalid_name。
- `PATCH /api/categories/{id}` name → 200；同上校验；默认归类 400 protected_category。`DELETE /api/categories/{id}` → 200；默认归类 400 protected_category；否则事务内把活动与软删记录迁到默认归类。
- `GET /api/bookmarks?category=<name|id>&q=<str>&include_trashed=0|1` → 200 数组；默认排序 created_at DESC、id ASC；q 仍仅对标题、hostname、描述做大小写不敏感子串匹配并与 category 叠加；GET 的 category 缺省或空字符串表示全库，非空且未知的归类返回空数组。这是读取过滤语义，不改变保存/移动显式空 category 的 400 invalid_category，也不改变保存省略/null 进入默认归类；不扩为原始 URL 或分类名搜索。
- `POST /api/bookmarks` url 必填，title、description、category 可选，allow_duplicate 为 P1；201；category 省略/null 时归入默认「未整理」；显式空字符串或超过 120 字符 400 invalid_category；新名称按 NOCASE 自动创建并复用；非法 URL 400 invalid_url；P1 重复 409 duplicate_url 且附 existing_id。
- `GET /api/bookmarks/{id}` 对数据库中仍存在的活动记录及软删除记录一律 200，返回该行的持久状态（含 trashed_at）；仅不存在的 ID 返回 404 not_found。该 GET 只读，不清空 trashed_at、不自动恢复；默认列表及默认计数仍排除软删除记录，include_trashed=1、回收站、分类删除迁移活动与软删记录、恢复与跨重启合同不变。`PATCH` 更新字段；URL 变化时重算 hostname；非法 URL 400 invalid_url，非法归类 400 invalid_category；P1 重复 409 duplicate_url。`POST /api/bookmarks/{id}/move` body category 必填；省略/空/超长 400 invalid_category；新名称自动创建。`DELETE /api/bookmarks/{id}` 软删除 200；`POST /api/bookmarks/{id}/restore` 恢复；P1 同 URL 活动冲突 409 duplicate_url 且不改数据。
- `GET /go/{id}` 302，Location 为保存时原始 URL；未知 id 404 not_found。HTML 打开链接使用原始 URL，target=_blank、rel=noopener。
- P1：`GET /api/export` Netscape HTML；`POST /api/import` 同格式，返回 imported/skipped。
- 错误合同：JSON 失败返回 `{error:{code,message,field}}`；通用 bad_request（畸形/不可解析 JSON，400）、invalid_url、invalid_category、invalid_name、not_found、duplicate_category、protected_category、duplicate_url。校验错误不产生 5xx，不产生部分写入；畸形 JSON 一律 bad_request 且不写。
- 机器错误分支范围：`contract_coverage.error_contract` 的 `atlas.bookmark-error-contract.v2` 保持原32条分支和双向映射，专门枚举分类管理及书签保存/移动的分类输入错误（invalid_name、invalid_category），不宣称穷尽产品所有错误。URL 校验、畸形 JSON、未知 ID 等仍受上文完整错误合同约束，分别由既有 A02/A10、A10、A08/A10 的已有断言检查；精确函数/断言和执行前提见本轮 ASSERTION_MAP.md（审阅附带材料）。这是一份静态映射，未执行不称已运行通过。
- 状态合同：GET 幂等；写操作事务化；校验失败保持提交前状态；分类与 q 为视图状态；删除与恢复改变 trashed_at 但不删除行。

## UI/HTML 适配器合同（供真实表单验收与独立浏览器执行者）

- `GET /`：保存表单 `form[action=/bookmarks/new]`（method=post，字段 url/title/description/category；category 预填「未整理」）；`a[data-testid=category-manager]` 指向 /categories；`form[data-testid=category-search-form]` 为 GET /，含 select 或 input name=category（归类名）与 input name=q；记录行 `tr[data-testid=record-row][data-record-id]`；打开链接 `a[data-testid=record-open-link]` 的 href 必须等于保存时原始 URL，target=_blank，rel 含 noopener；每行含 `form[data-testid=record-move-form]`（input record_id、select name=category_id，值为 API 归类 ID）、`form[data-testid=record-delete-form]`（input record_id）；回收站或 `GET /?trash=1` 的软删记录行含 `form[data-testid=record-restore-form]`（input record_id）。
- `GET /categories`：`form[data-testid=category-create-form]`（input name）、`form[data-testid=category-rename-form]`（input category_id、name）、`form[data-testid=category-delete-form]`（input category_id）；每个归类行/侧栏计数为 `[data-testid=category-count][data-category-id=...]`，只显示活动记录数；归类名/计数与 JSON 一致。
- 表单成功：save 303 到 /?category=...；move 303 到目标归类；delete 303 到 /?trash=1；restore 303 到恢复后归类；category create/rename/delete 303 到 /categories。失败：400/409 渲染当前页，含 `[data-testid=form-error]` 可读消息，保留 url/title/description/category/name/category_id/record_id 中已提交的值，并保留可重新提交的表单；不得 5xx 或写入。
- 归类搜索：提交 category 与 q，成功后 URL 与表单同时保留两者；页面显示所选归类、保留的查询和匹配行；同一关键字在两个归类分别得到各自结果；某归类无匹配时显示明确空结果，不是错误。
- 记录移动由 HTML 适配器把 category_id 翻译成归类名，再调用现有 move 服务；归类删除仍按 API 事务迁移活动与软删记录。默认归类不可重命名/删除。
- P0 不提供孤立的记录编辑界面；仅保留 PATCH /api/bookmarks/{id} 的现有 URL 更新合同（URL 变化重算 hostname）。打开链接的实际导航目标由 href 与 /go 302 双重验证，不抓取目标页。

## 验收适配器合同

- 全部程序使用 `--base-url` 指向真实 python-web 目标；A01/A05/A09 另需 `--app-root` 与 `--data-dir` 做既有重启检查。A03 也必需二者：base_url 验证省略归类保存进入未整理、有效新归类名自动创建、读回/分类筛选及 HTML/JSON 一致；已用目标按用户持久分类状态验收，不要求补回合法删除或改名的非默认预置。另用同一 app_root 和测试者 data_dir 经 common.launch_app(...,fresh=True) 新建独立实例，在首次业务写入前分别核 API 与 HTML 可见四个预置分类；不清空原目标或既有目录。缺参、fresh 启动失败、来源不匹配、清理失败均明确失败，不跳过或回退。A11 保留自己既有的同冻结源码 fresh 实例首启/未过滤空库检查，base_url 只观察当前部署入口，参数仍必需且两组分别记录。A03/A11 的 fresh 都不是同数据目录跨重启证明，不因此把 A03 加入 common.RESTART_CASES。A14 仍仅需 `--data-dir`。
- `--app-root` 只读；`--data-dir` 是测试者草稿根。重启用例通过 common.launch_app 在同一 `--data-dir/instances/<id>` 上启动 `app/serve.py`，真实写入、SIGTERM、同一目录重启并读回；健康检查不是重启证据。
- HTML 用例以标准库 urllib 提交 application/x-www-form-urlencoded 表单并解析响应 HTML 的 data-testid、表单字段、链接与文本；不以 API 调用代替声明的 HTML 表单，不驱动 JS/DOM。独立浏览器执行者可复用同一契约。
- 所有请求限定在 base_url 精确 origin；/go 不跟随重定向；不请求保存的外链、元数据或 favicon；不附加凭据；目标要求认证时显式报告基础设施未就绪。
- A13 保持原 P1 goal，只修正其页面打开链接断言：按本次 record_id 精确定位 tr[data-testid=record-row][data-record-id]，在该行内读取 a[data-testid=record-open-link] 的 HTML 解码后 href，精确等于提交原始 URL（大小写、路径、查询串、片段均保留），target=_blank，rel 按 token 含 noopener。其他行/注释/隐藏文本不能代替目标行链接，页面不必出现 /go 字符串。A08 另有既有 /go 302、原始 Location、未知 ID404 检查；A13 原先没有自己的302断言，A14/A15 不变。所有测试均不请求或跟随保存的外链。
- A13 离线证据边界：页面不引用外部资源只证明该行为子项，不能单独证明断网保存。宣称完整 A13 离线通过，运行者须使用现有执行环境禁用应用外网，并保留绑定同一 app_root、应用/执行容器与实际运行 receipt 的网络配置及运行证据。缺少真实断网环境证据时离线结论未证明，不能从程序子项 passed 汇总成完整离线 passed；不接受用户自填 offline=true。使用现有未运行/未满足证据状态，不新增不支持的 enum。本轮 G1 仅 P0，A13 不新增为 G1 真实运行前置；未运行 A13 就保留 not_run。
- 结果：stdout 单个 atlas.acceptance-result.v1 JSON；断言失败或基础设施错误 exit nonzero；不声称已运行。

## 非功能需求

- 离线可用：保存/浏览/检索不依赖外部服务；不设置外部抓取为 P0 要求。
- 数据完整性：写事务化；归类删除与恢复保持引用完整；校验失败零写入。
- 确定性：排序、错误码、重定向稳定；GET 幂等。
- 可访问/可测试：语义化 HTML、表单 label 或 aria、稳定 data-testid；服务端输出 UTF-8。
- 单用户本机：无认证；日常 127.0.0.1，0.0.0.0 仅隔离验收网络。
- 不设未经验证的时延/吞吐/成本目标；只要求请求可顺序处理。

## 边界与限制

- 不实现云同步、多设备、协作、分享、浏览器扩展/移动分享目标。
- 不保存网页副本、不抓取正文、不做失效链接检测（F17/F18）。
- 不引入置顶/归档/多排序/复制 URL/访问计数（F20/F23/F24）。
- 归类为扁平单选；嵌套/标签属后期（F19/D12）。
- P0 不做重复拒绝；F14/A15 保持 P1。
- 第三方元数据/图标仅 P1 可选增强，失败不影响保存；离线验收不验证其可达性。

## A04/A12 分类输入澄清（本次受限修订）

- A04 仅分类管理：HTML create/rename 表单的 name 与 JSON create/rename 的 name 同为归类名称；省略、空字符串、纯空白、121 字符均 400 invalid_name，JSON 显式 null 同样 invalid_name。既有重名 duplicate_category、默认分类 protected_category、删除迁移/恢复均保留。
- A12 仅书签保存和移动，不将分类管理 name 校验混为 invalid_category。HTML 保存使用名称 category；省略时未整理，显式空/纯空白/121 字符为 400 invalid_category。HTML 无 JSON null 这种原生值，不能把字面字符串 null 当 JSON null。
- JSON 保存使用名称 category；省略或显式 null 均默认未整理，显式空/纯空白/121 字符为 invalid_category。JSON move 的名称 category 必填；省略、null、空/纯空白/121 字符为 invalid_category。有效新名称可自动创建并复用，未知名称不等于非法 ID。
- HTML move 使用 category_id（API 已有分类 ID），必须解析为已有名称再调用服务；省略、空或未知 ID 为 invalid_category，不能把未知 ID 当新名称创建。JSON 保存/move 合同不新增 category_id 字段；GET category 未知值的空结果语义不改。
- 错误分支一律零写入：HTML 400、form-error 可读、保留已提交字段并提供可重试表单；JSON 400、error.code/message/field，无导航。成功流程、303 导航、阶段、能力与既有断言意图保留。
- 搜索仍仅对 title、hostname、description 做大小写不敏感子串匹配，并叠加分类；不扩展为 URL 全文、分类名或标签检索。此处对齐目标设计，不更改案例来源观察。
