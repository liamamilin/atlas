# 决策与默认值

## D01 · 首版运行与数据边界？

单用户本机、独立SQLite；显式保存，无账户、云端和协作。

When to ask / 询问条件: 确需公网托管或多人数据时先确认，不自行扩展。

保护本地数据，避免默认外发。

assisted default

## D02 · 是否复刻上游？

Target design inference, not an upstream claim: the pinned research makes the home the subject and requires recurring work plus a durable completion record. Upstream code corroborates that abstract shape but realizes recurrence in months, keeps one house profile, links maintenance to an optional appliance, and does not show an explicit appliance-to-home foreign key in the selected files. The target therefore makes the home anchor explicit through home_id on equipment and plans, uses every-N-days recurrence from the scenario, and keeps only the home, equipment, plan, completion, and history slice. It does not copy upstream code, schema, or UI. Upstream status: not_run; no upstream build, test, server, TUI, or database was started.

When to ask / 询问条件: 目标变化、破坏已有数据或需要引入上游实现/依赖时先确认。

不混淆来源事实与目标设计。

assisted default
