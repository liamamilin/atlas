# 阶段与验收

## P0 · 核心可用

Create the home and its equipment, define every-N-day care plans anchored to them, see the exact sets of tasks that are overdue, due, or upcoming as of a date, record a completion with a note, advance the next due date to max(old due_on, latest completion + interval_days) so it never regresses, and retrieve care history by home or equipment.

| 用例 | 类型 | 行为 | 执行器 |
| --- | --- | --- | --- |
| A01 | positive | In a dedicated data directory, create the single home, add an equipment record under it, and prove duplicate-home and invalid-name, invalid-category, and unknown-home requests return 409, 422, or 404 without changing stored records. | acceptance/probe.py |
| A02 | positive | Create plans with interval_days in 1..3650 and verify GET /api/tasks/due returns exact overdue, due, and upcoming ID sets and counts at the as_of and horizon_days boundaries, using fresh equipment scopes, while invalid plans write nothing. | acceptance/probe.py |
| A03 | positive | Record a completion and note in one atomic call and verify last_completed_on is the true latest date and due_on is max(old due_on, latest + interval_days) across leap-day, month-end, year-end, initial-backfill, and no-anchor creation-day examples, with invalid completions leaving no trace. | acceptance/probe.py |
| A04 | positive | Retrieve completions filtered by home and equipment in documented descending order with plan and equipment names and notes, and reject invalid filters without writes. | acceptance/probe.py |
| A05 | positive | Load GET / and assert a dependency-free HTML shell exposes home, equipment, plan, due, completion, and history workflows with structural accessibility relationships (label for/id, fieldset/legend, due caption and th scope=col, role=status, aria-live=polite, lang=en), while unknown routes and methods return documented JSON errors. | acceptance/probe.py |
