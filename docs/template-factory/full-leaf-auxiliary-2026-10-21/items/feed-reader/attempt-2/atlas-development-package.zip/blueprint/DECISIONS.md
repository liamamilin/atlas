# 决策与默认值

## D01 · 首版运行与数据边界？

Go 1.22+ service compiled as one static binary, PostgreSQL 14+ in a disposable database (schema feedreader) holding one seeded operator account, HTTP server plus scheduler goroutine in the same process; the acceptance probe runs on the same host with Python 3.9+ standard library only, driving the JSON API at http://127.0.0.1:8080 and a loopback RSS fixture server that it starts and stops itself; every probe record is prefixed probe-/Probe and is deleted by the probe at teardown, and because mark-all-read is account wide the probe refuses to run against an instance that already holds subscriptions it did not create.

When to ask / 询问条件: 确需公网托管或多人数据时先确认，不自行扩展。

保护本地数据，避免默认外发。

assisted default

## D02 · 是否复刻上游？

Target inference: the leaf makes the user's own subscription list the only selector and adds standing automated intake plus a per-item reading state, and the fixed scenario is one operator on their own server, so the target is a self-hosted single-user service rather than a hosted multi-tenant platform or a desktop app. The concrete choices are: one Go binary (net/http plus html/template) over PostgreSQL; a scheduler goroutine that refreshes each feed on its own next_check_at, where the configured polling interval is used verbatim with no lower floor (so a short interval stays legal and the standing intake is observable in seconds) while a publisher delay may only push the next check further out; conditional GET with ETag and Last-Modified; a per feed hash of the item identifier as the duplicate suppression key; a two valued read status with an independent starred flag; subscribe time ingestion, so a new subscription is readable at once and its first items are stored unread; entries listed newest first with an id tie break and the reader view navigating over the read entries by changed_at; a site URL resolved through the feed its page advertises; category nesting in the OPML export and an idempotent import keyed on the resolved feed URL. These are target proposals derived from the observations above; they are not claims about how the upstream product behaves, and the upstream was read as source only and never built or run.

When to ask / 询问条件: 目标变化、破坏已有数据或需要引入上游实现/依赖时先确认。

不混淆来源事实与目标设计。

assisted default
