# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_8e3395b7131b4d699b2ec0fb167b0c4b@1

Keep a personal list of feeds, let new items arrive on their own, and clear the unread backlog each morning while keeping the list portable

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_attempt_2_1

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/internal/model/entry.go · bdd8087d9cf7a20ca7e800948389e8a7e86445da

code_observation: Entry status is a two valued string field, EntryStatusUnread = 'unread' and EntryStatusRead = 'read', with published_at ascending as the default listing order.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S03 · ev_assisted_attempt_2_10

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/internal/reader/opml/opml.go · bdd8087d9cf7a20ca7e800948389e8a7e86445da

code_observation: The OPML encoder writes the type attribute as 'rss' for an outline that carries a feed URL and leaves it out for a folder, so an exported feed outline is distinguishable from a category outline.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S04 · ev_assisted_attempt_2_11

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/internal/reader/opml/opml.go · bdd8087d9cf7a20ca7e800948389e8a7e86445da

code_observation: A parsed outline counts as a subscription only when its xmlUrl attribute is not blank, so outlines without xmlUrl are folders rather than feeds.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S05 · ev_assisted_attempt_2_12

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/internal/ui/entry_read.go · bdd8087d9cf7a20ca7e800948389e8a7e86445da

code_observation: The reader view resolves the previous and next entries with a pagination builder restricted to entries whose status is read and ordered by changed_at descending.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S06 · ev_assisted_attempt_2_13

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/internal/ui/entry_toggle_starred.go · bdd8087d9cf7a20ca7e800948389e8a7e86445da

code_observation: Starring is a separate toggle endpoint that returns OK without looking at the entry status, so the starred flag is independent of the unread and read state.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S07 · ev_assisted_attempt_2_14

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/README.md · bdd8087d9cf7a20ca7e800948389e8a7e86445da

documentation: The product documentation lists Atom 0.3/1.0, RSS 1.0/2.0 and JSON Feed 1.0/1.1 as supported formats, states that OPML import/export and URL import are available, and that articles are organized with categories and bookmarks.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S08 · ev_assisted_attempt_2_15

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/README.md · bdd8087d9cf7a20ca7e800948389e8a7e86445da

documentation: The documentation states that feeds are updated in the background by an internal scheduler or a cron job, that Last-Modified, If-Modified-Since, If-None-Match, Cache-Control, Expires and ETag are respected, and that the default polling interval is one hour.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S09 · ev_assisted_attempt_2_16

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/README.md · bdd8087d9cf7a20ca7e800948389e8a7e86445da

documentation: The reference implementation is written in Go, shipped as a single static binary and works only with PostgreSQL.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S10 · ev_assisted_attempt_2_17

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE · bdd8087d9cf7a20ca7e800948389e8a7e86445da

documentation: The upstream project is distributed under the Apache License, Version 2.0, so the reference material is usable as a design reference only.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S11 · ev_assisted_attempt_2_2

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/internal/model/entry.go · bdd8087d9cf7a20ca7e800948389e8a7e86445da

code_observation: The Entry record carries FeedID, Status, Hash, Title, URL and an independent boolean Starred field alongside Status, plus an optional nested Feed pointer, so the read state and the starred state are separate attributes of the same row.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S12 · ev_assisted_attempt_2_3

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/internal/model/feed.go · bdd8087d9cf7a20ca7e800948389e8a7e86445da

code_observation: A feed row stores its own fetch bookkeeping: CheckedAt, NextCheckAt, EtagHeader, LastModifiedHeader, plus ParsingErrorMsg and ParsingErrorCount for feeds that stopped parsing.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S13 · ev_assisted_attempt_2_4

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/internal/model/feed.go · bdd8087d9cf7a20ca7e800948389e8a7e86445da

code_observation: ScheduleNextCheck derives the next check delay from the configured scheduler interval, never lets a publisher supplied delay shorten it (max(interval, refreshDelay)) and clamps it to the scheduler maximum before writing NextCheckAt.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S14 · ev_assisted_attempt_2_5

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/internal/reader/handler/handler.go · bdd8087d9cf7a20ca7e800948389e8a7e86445da

code_observation: A refresh attaches the stored ETag and Last-Modified values as conditional request headers unless the feed ignores the HTTP cache or the refresh is forced.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S15 · ev_assisted_attempt_2_6

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/internal/reader/handler/handler.go · bdd8087d9cf7a20ca7e800948389e8a7e86445da

code_observation: After a modified response the refresh delay is the maximum of the feed TTL, the Cache-Control max-age and the Expires header, and the parsed entries are handed to the store together with a flag that says whether existing entries may be updated.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S16 · ev_assisted_attempt_2_7

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/internal/reader/handler/handler.go · bdd8087d9cf7a20ca7e800948389e8a7e86445da

code_observation: Subscription creation refuses a feed URL the user already has (ErrDuplicatedFeed) and reports a parse failure when the fetched body is not a feed, so a failed subscription writes nothing.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S17 · ev_assisted_attempt_2_8

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/internal/reader/handler/handler.go · bdd8087d9cf7a20ca7e800948389e8a7e86445da

code_observation: The subscription path hands the parsed entries to the entry processor (ProcessFeedEntries) before the feed row is created, so processing the first batch of items belongs to the subscription call itself and not to a later refresh.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S18 · ev_assisted_attempt_2_9

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/internal/reader/opml/opml.go · bdd8087d9cf7a20ca7e800948389e8a7e86445da

code_observation: An OPML outline carries title, text, xmlUrl, htmlUrl and description attributes and nests child outlines, so one category outline can hold one feed outline per subscription.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S19 · ev_assisted_attempt_2_design

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE · bdd8087d9cf7a20ca7e800948389e8a7e86445da

inference: Target inference: the leaf makes the user's own subscription list the only selector and adds standing automated intake plus a per-item reading state, and the fixed scenario is one operator on their own server, so the target is a self-hosted single-user service rather than a hosted multi-tenant platform or a desktop app. The concrete choices are: one Go binary (net/http plus html/template) over PostgreSQL; a scheduler goroutine that refreshes each feed on its own next_check_at, where the configured polling interval is used verbatim with no lower floor (so a short interval stays legal and the standing intake is observable in seconds) while a publisher delay may only push the next check further out; conditional GET with ETag and Last-Modified; a per feed hash of the item identifier as the duplicate suppression key; a two valued read status with an independent starred flag; subscribe time ingestion, so a new subscription is readable at once and its first items are stored unread; entries listed newest first with an id tie break and the reader view navigating over the read entries by changed_at; a site URL resolved through the feed its page advertises; category nesting in the OPML export and an idempotent import keyed on the resolved feed URL. These are target proposals derived from the observations above; they are not claims about how the upstream product behaves, and the upstream was read as source only and never built or run.

Apache-2.0

https://github.com/miniflux/v2/blob/bdd8087d9cf7a20ca7e800948389e8a7e86445da/LICENSE

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## 待验证

- 辅助静态独审通过，不代表运行通过
- 上游not_run
- The upstream reference was read as source only and was never built, installed or run; no upstream runtime behaviour is claimed and no certification of the upstream product is made.
- The probe drives the JSON API of the target; the operator-facing HTML surface described in the architecture is verified by hand and is not asserted by an acceptance case.
- Only RSS 2.0 fixtures are exercised by the probe; Atom 0.3/1.0 and JSON Feed 1.0/1.1 parsing is specified in the contract but not covered by an acceptance case.
- The scheduled intake check of A01 is reported as not_run when the service does not report polling_interval_seconds on GET /api/v1/config, or when the configured polling interval is longer than the probe intake timeout; the remaining A01 sub-checks then run on the explicit refresh endpoint instead of the scheduler path.
- The probe requires a disposable instance because read-all is account wide: it refuses to run against an instance that already holds subscriptions outside its own probe- categories, and it deletes only feeds in those categories and categories whose title starts with probe-.
- The site URL discovery reads only the link rel=alternate tags of the page; it does not crawl the page body and does not guess a feed path.
- Full text extraction, rewrite and filter rules, share codes, webhooks, third party integrations and the Fever or Google Reader compatible APIs are outside this leaf and are not implemented.
- Podcast and video enclosures, playback position and per feed crawler mode are not part of the target scope.
- The reader view renders the stored item content only; the target never re-fetches the article page, so an item whose source page changes is not updated in place.
- Multi user accounts, per user API tokens and password or passkey login flows are reduced to a single seeded operator in this scope.
- OPML import reuses an existing category by name, so two categories with the same title inside one file are merged into the first match.
