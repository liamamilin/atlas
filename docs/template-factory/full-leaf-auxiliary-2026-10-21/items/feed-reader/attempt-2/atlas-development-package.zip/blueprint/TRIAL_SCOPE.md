# 辅助试用范围

Keep a personal list of feeds, let new items arrive on their own, and clear the unread backlog each morning while keeping the list portable

- The upstream reference was read as source only and was never built, installed or run; no upstream runtime behaviour is claimed and no certification of the upstream product is made.
- The probe drives the JSON API of the target; the operator-facing HTML surface described in the architecture is verified by hand and is not asserted by an acceptance case.
- Only RSS 2.0 fixtures are exercised by the probe; Atom 0.3/1.0 and JSON Feed 1.0/1.1 parsing is specified in the contract but not covered by an acceptance case.
- The scheduled intake check of A01 is reported as not_run when the service does not report polling_interval_seconds on GET /api/v1/config, or when the configured polling interval is longer than the probe intake timeout; the remaining A01 sub-checks then run on the explicit refresh endpoint instead of the scheduler path.
- The probe requires a disposable instance because read-all is account wide: it refuses to run against an instance that already holds subscriptions outside its own probe- categories, and it deletes only feeds in those categories and categories whose title starts with probe-.
- The site URL discovery reads only the link rel=alternate tags of the page; it does not crawl the page body and does not guess a feed path.
- Full text extraction, rewrite and filter rules, share codes, webhooks, third party integrations and the Fever or Google Reader compatible APIs are outside this leaf and are not implemented.
- Podcast and video enclosures, playback position and per feed crawler mode are not part of the target scope.
- The reader view renders the stored item content only; the target never re-fetches the article page, so an item whose source page changes is not updated in place.
- Multi user accounts, per user API tokens and password or passkey login flows are reduced to a single seeded operator in this scope.
- OPML import reuses an existing category by name, so two categories with the same title inside one file are merged into the first match.

OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。模板先于应用；仅代表场景后续开发应用。严格G1/T08不因本包通过。