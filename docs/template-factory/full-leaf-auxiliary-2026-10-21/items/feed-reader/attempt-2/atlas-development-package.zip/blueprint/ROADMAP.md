# 阶段与验收

## P0 · 核心可用

Keep a personal list of feeds, let new items arrive on their own, and clear the unread backlog each morning while keeping the list portable

| 用例 | 类型 | 行为 | 执行器 |
| --- | --- | --- | --- |
| A01 | positive | A01: A newly published item shows up in the Unread view after a scheduled refresh, carries its feed's title and canonical link, and is listed only once because the item identifier is already known. | acceptance/probe.py |
| A02 | positive | A02: Marking an item read removes it from the Unread view and lowers the shown unread count, the same happens when a whole feed, a whole category or the whole account is marked read, and an item that was starred keeps its starred flag after being read and still appears in the starred list. | acceptance/probe.py |
| A03 | positive | A03: Exporting the subscription list yields one OPML outline per subscribed feed with its xmlUrl inside its category outline, and importing that file back recreates the same subscriptions without duplicates. | acceptance/probe.py |
| A04 | positive | A04: A feed URL and a site URL are subscribed into a category and listed there with the feed title, while a duplicate feed URL, an unknown category, a malformed URL and a URL that is not a feed are all rejected without creating a subscription. | acceptance/probe.py |
| A05 | positive | A05: Opening an item in the reader view returns its content, its feed title and its canonical link with previous/next entries drawn from the already-read items, and an unknown item id is reported as not found. | acceptance/probe.py |
