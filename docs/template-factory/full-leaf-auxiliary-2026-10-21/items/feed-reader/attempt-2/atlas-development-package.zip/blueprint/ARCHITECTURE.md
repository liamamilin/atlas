# 架构与契约

# feedreader - architecture for the morning triage service

## 1. Target and rationale
`feedreader` is a self-hosted, single-user feed reader **service**. One process serves a small HTML reading surface and a JSON API, holds the operator's subscription list, the items it delivers and their reading state in PostgreSQL, and refreshes every subscribed feed in the background.

The delivery profile is `service`, so the list and the state live on the operator's own server, not in a hosted multi-tenant platform and not on a desktop. The stack follows the upstream reference that was read for this leaf (Go, one static binary, PostgreSQL only, an internal scheduler, conditional GET, a one hour default polling interval) and keeps only the scenario core: the subscription list, standing intake, unread triage, reading state and OPML portability. Filters, sharing, integrations, enclosures, full-text extraction and multi-user accounts are out of scope.

The fixed scenario is preserved: one individual reader on their own server, following about twenty blogs and news feeds, clearing the unread backlog each morning and keeping the list portable.

## 2. Runtime, deployment and configuration
- Language: Go 1.22+, `net/http` for the server, `html/template` for the web surface, `embed` for static assets, plain SQL, no ORM and no framework.
- Process: one static binary. `feedreader migrate` applies the embedded SQL migrations; `feedreader serve` runs the HTTP server and the scheduler goroutine in the same process.
- Storage: PostgreSQL 14+ (`FEEDREADER_DATABASE_URL`), one schema `feedreader`, migrations embedded in the binary.
- Configuration comes from environment variables only. The only arguments are the subcommands `migrate` and `serve`; there are no configuration flags, so the commands in section 8 and the acceptance environment in the acceptance README are the same commands.

| Variable | Default | Meaning |
| --- | --- | --- |
| `FEEDREADER_LISTEN_ADDR` | `:8080` | HTTP listen address |
| `FEEDREADER_DATABASE_URL` | required | PostgreSQL DSN |
| `FEEDREADER_API_KEY` | required for the API | value of the `X-Api-Key` header |
| `FEEDREADER_USERNAME`, `FEEDREADER_PASSWORD` | required once | bootstrap of the single operator account |
| `FEEDREADER_POLLING_INTERVAL` | `1h` | base polling interval, Go duration, at least `1s`; **no lower floor is applied** |
| `FEEDREADER_MAX_POLLING_INTERVAL` | `24h` | the only clamp applied to a computed delay |
| `FEEDREADER_SCHEDULER_ENABLED` | `true` | whether the background scheduler runs |
| `FEEDREADER_SCHEDULER_TICK` | `1s` | scheduler tick period |
| `FEEDREADER_DEFAULT_CATEGORY` | `Uncategorized` | category of a feed created without one |
| `FEEDREADER_HTTP_TIMEOUT` | `20s` | timeout when fetching a feed |
| `FEEDREADER_MAX_BODY_SIZE` | `5MiB` | maximum feed body size |

### 2.1 Polling interval semantics
The configured `FEEDREADER_POLLING_INTERVAL` is used verbatim as the base interval. **It is not clamped to any floor**, so `5s` is a legal configuration and the acceptance environment uses it so the standing intake is observable in seconds. Only two rules shape a delay:
1. a publisher supplied delay (feed TTL, `Cache-Control: max-age`, `Expires`, `Retry-After`) may only *increase* the delay: `delay = max(polling_interval, refresh_delay)`;
2. the delay is clamped from above by `FEEDREADER_MAX_POLLING_INTERVAL` (default `24h`).

There is no lower clamp other than the configured interval itself. The effective base interval is reported by `GET /api/v1/config` so a verifier can size its wait.

## 3. Data model
Schema `feedreader`:
- `users(id, username unique, password_hash, created_at)` - exactly one operator row.
- `categories(id, user_id, title)` with a unique index on `(user_id, lower(title))`; the categories are the folders of the list.
- `feeds(id, user_id, category_id, feed_url, site_url, title, description, etag, last_modified, checked_at, next_check_at, parsing_error_message, parsing_error_count, disabled)` with a unique index on `(user_id, feed_url)`.
- `entries(id, user_id, feed_id, hash, title, url, content, author, published_at, status, starred, created_at, changed_at)` with a unique index on `(feed_id, hash)`.
  - `status` is `unread` or `read`; `starred` is a boolean independent of `status`.
  - `hash` is the duplicate suppression key: sha256 of the item's stable identifier - `guid` when present, else `id`, else `url`; when the item carries none, sha256 of `title` and `published_at`.
  - Indexes on `(user_id, status, published_at desc, id desc)`, `(feed_id, status)` and `(user_id, starred)`.

Lifecycle: deleting a feed deletes its entries. Deleting a category that still holds feeds is refused. Unread counts are always computed from `entries` where `status = 'unread'`; no counter column is kept, so a count can never drift from the list.

## 4. HTTP contract
Every API path is under `/api/v1`. The API requires the header `X-Api-Key: <FEEDREADER_API_KEY>`; the web surface uses the same single operator account with a session cookie. An error body is `{"error":{"code":"...","message":"..."}}` where `code` is one of the codes named below.

### 4.1 Configuration
`GET /api/v1/config` -> 200 with the fields `polling_interval_seconds` (integer, the effective base interval in seconds), `max_polling_interval_seconds` (integer), `scheduler_enabled` (boolean) and `version` (string).

### 4.2 Categories
| Request | Result |
| --- | --- |
| `GET /api/v1/categories` | 200 `{"categories":[{"id":1,"title":"Uncategorized"}]}` |
| `POST /api/v1/categories` with `{"title":"..."}` | 201 `{"id":N,"title":"..."}`; 400 `invalid_category` when the title is blank; 409 `duplicate_category` when the account already has that title (case insensitive) |
| `DELETE /api/v1/categories/{id}` | 204; 404 `unknown_category`; 409 `category_not_empty` when it still holds feeds |

### 4.3 Feeds
| Request | Result |
| --- | --- |
| `GET /api/v1/feeds?category_id=` | 200 `{"feeds":[{"id":N,"category_id":N,"feed_url":"...","site_url":"...","title":"...","unread_count":N,"checked_at":"...","next_check_at":"...","parsing_error_message":""}],"total":N}`, ordered by title asc then id asc |
| `POST /api/v1/feeds` with `{"feed_url":"...","category_id":N}` | 201 `{"id":N,"category_id":N,"feed_url":"...","site_url":"...","title":"...","unread_count":N,"checked_at":"...","next_check_at":"..."}` |
| `DELETE /api/v1/feeds/{id}` | 204; the entries of that feed go with it |
| `PUT /api/v1/feeds/{id}/refresh` | 204 after one synchronous fetch, parse and store cycle; 404 `unknown_feed` |

`POST /api/v1/feeds` errors: `400 invalid_url` (not an absolute http or https URL), `400 not_a_feed` (the fetch failed, or the body is neither a feed nor a page that advertises one), `404 unknown_category`, `409 duplicate_feed_url` (the resolved feed URL is already subscribed). **In every error case no feed row and no entry is written.**

### 4.4 Entries
| Request | Result |
| --- | --- |
| `GET /api/v1/entries?status=&feed_id=&category_id=&starred=true&limit=&offset=` | 200 `{"entries":[...],"total":N,"unread_count":N}` where `total` is the size of the filtered scope and `unread_count` is the account wide unread total |
| `GET /api/v1/entries/{id}` | 200 the entry with its `feed` object and `prev_entry_id` / `next_entry_id`; 404 `unknown_entry` |
| `PUT /api/v1/entries/{id}` with `{"status":"read"}` | 200 the updated entry; 400 `invalid_status` for a value outside `unread` and `read` |
| `PUT /api/v1/entries/{id}` with `{"starred":true}` | 200 the updated entry; the status is not touched |
| `PUT /api/v1/entries` with `{"entry_ids":[1,2],"status":"read"}` | 200 `{"updated":2}` |
| `PUT /api/v1/feeds/{id}/entries` with `{"status":"read"}` | 200 `{"updated":N}` - every entry of one feed |
| `PUT /api/v1/categories/{id}/entries` with `{"status":"read"}` | 200 `{"updated":N}` - every entry of one category |
| `PUT /api/v1/entries/read-all` with `{"status":"read"}` | 200 `{"updated":N}` - every unread entry of the account |

The entry object is `{"id":N,"feed_id":N,"status":"unread","starred":false,"title":"...","url":"...","content":"...","author":"...","published_at":"...","created_at":"...","changed_at":"...","feed":{"id":N,"title":"...","feed_url":"..."}}`.

**Ordering is pinned.** `GET /api/v1/entries` returns the entries of the scope ordered by `published_at DESC, id DESC` (newest first) unless `order` and `direction` are given. A client therefore must not assume a creation order; the acceptance probe selects an entry by id and compares the reader view against that entry.

**Navigation is pinned.** `prev_entry_id` and `next_entry_id` are computed over the entries of the account whose status is `read`, excluding the entry itself, ordered by `changed_at DESC, id DESC`:
- `next_entry_id` is the first read entry whose `(changed_at, id)` is strictly smaller than the current entry's;
- `prev_entry_id` is the last read entry whose `(changed_at, id)` is strictly greater than the current entry's;
- both are `null` when there is no such entry.

### 4.5 Unread counts
`GET /api/v1/unread_count` -> 200 `{"total":N,"by_feed":[{"feed_id":N,"unread_count":N}]}`. `total` is the account total; `by_feed` lists every feed that holds unread entries.

### 4.6 OPML
| Request | Result |
| --- | --- |
| `GET /api/v1/export` | 200, `text/x-opml` |
| `POST /api/v1/import` with the OPML document as the body and `Content-Type: text/x-opml` | 200 `{"created":N,"existing":M,"categories_created":K,"errors":["..."]}` |

Export shape:

    <?xml version="1.0" encoding="UTF-8"?>
    <opml version="2.0">
      <head><title>feedreader subscriptions</title><dateCreated>2026-10-22T06:00:00Z</dateCreated></head>
      <body>
        <outline text="News" title="News">
          <outline type="rss" text="Probe Alpha" title="Probe Alpha" xmlUrl="http://127.0.0.1:8080/feeds/alpha.xml" htmlUrl="http://probe.invalid/alpha"/>
        </outline>
      </body>
    </opml>

Export rules: exactly one category outline per category that holds at least one feed, ordered by title asc; inside it exactly one feed outline per feed of that category, ordered by title asc; each feed outline carries `xmlUrl` (the subscribed feed URL), `htmlUrl` (the site URL), `title` and `text` (the feed title) and `type="rss"`. A feed without a category is exported under `FEEDREADER_DEFAULT_CATEGORY`.

Import rules: an outline whose `xmlUrl` is blank is a folder and its `text` or `title` is the category name - a category with that name is reused, otherwise it is created and counted in `categories_created`. An outline with a non blank `xmlUrl` is a subscription and is resolved exactly like `POST /api/v1/feeds` (a feed URL or a site URL, see 5.2); the resolved feed URL is the identity of the subscription. A subscription whose resolved feed URL is already subscribed is skipped and counted in `existing`; it is never created twice and its entries are never ingested again. A subscription that cannot be resolved is recorded in `errors` and the import continues with the remaining outlines. The import is idempotent: importing the same file twice leaves the subscription list unchanged.

## 5. Intake rules
### 5.1 Scheduler
One goroutine ticks every `FEEDREADER_SCHEDULER_TICK` (default `1s`). On each tick it selects the feeds whose `next_check_at <= now()` and that are not disabled, ordered by `next_check_at asc, id asc`, and refreshes them one at a time; there are no parallel fetches. A scheduled refresh runs exactly the same code path as `PUT /api/v1/feeds/{id}/refresh`.

After every fetch, modified or not, the next check is computed:

    refresh_delay = max(feed TTL, Cache-Control max-age, Expires - Date, Retry-After)
    delay         = max(polling_interval, refresh_delay)
    delay         = min(delay, max_polling_interval)
    next_check_at = now + delay

A publisher can therefore make the reader wait longer, never less, and the operator's configured interval is never overridden from below.

### 5.2 Resolving a subscription URL: a feed URL or a site URL
`POST /api/v1/feeds` and the OPML import both accept **a feed URL or a site URL**:
1. the URL must be an absolute http or https URL, otherwise `400 invalid_url`;
2. the body is fetched with the timeout and size limit of section 2;
3. if the body parses as RSS, Atom or JSON Feed, that is the feed;
4. otherwise, if the body is HTML, the page is scanned for `<link rel="alternate" type="application/rss+xml|application/atom+xml|application/feed+json" href="...">`; the first candidate is resolved against the page URL, fetched and parsed; if it parses as a feed, that is the feed and the subscribed `feed_url` is the **candidate** URL, not the page URL;
5. otherwise `400 not_a_feed`.

The page URL is kept as the `site_url` of the feed.

### 5.3 Subscribe time ingestion
A successful subscription is not an empty row. The fetch that resolves the feed also parses its items, and those items are stored immediately:
- every parsed item becomes an entry of the new feed with `status = 'unread'`, `starred = false`, and its title, link, content and published date;
- the feed row and those first entries are written in one transaction; if the entry insert fails, the feed row is rolled back and no partial subscription survives;
- the `unread_count` of the response is the number of items stored this way, and is `0` for a feed that published nothing;
- `checked_at = now` and `next_check_at = now + delay` (computed with 5.1) are set on the feed.

So a subscription is readable at once and the standing scheduler takes over from the next tick. Later refreshes insert only the items whose hash is unknown.

### 5.4 Fetching, conditional requests and duplicates
- Each fetch sends a `User-Agent` and, when the feed has stored validators, `If-None-Match: <etag>` and `If-Modified-Since: <last-modified>`.
- `304 Not Modified` inserts nothing; only `checked_at`, `next_check_at` and the stored validators are updated.
- `200` with a parseable body: the items are parsed; an item whose `hash` already exists for that feed is **not inserted again** - the existing row keeps its id and its stored fields may be refreshed in place; a new item is inserted with `status = 'unread'`.
- A fetch or parse failure increments `parsing_error_count`, stores the message in `parsing_error_message` and leaves the stored entries untouched.

## 6. Reading state
- `status` is `unread` or `read`; there is no third value and no keep-unread toggle in this scope.
- `starred` is a separate boolean. `PUT /api/v1/entries/{id}` with `{"status":"read"}` never clears `starred`, and `{"starred":false}` never changes the status.
- The bulk endpoints of 4.4 change the status only, for one entry, one feed, one category or the whole account; `read-all` is account wide by design and the operator accepts that.
- `changed_at` is updated on every state change and is the ordering key of the reader navigation.
- Unread counts are derived from the entries, so a count and a list can never disagree.

## 7. Web surface and operator steps
The service renders a small HTML surface with `html/template`:
- `/` - the unread view: the entries of the selected scope (unread, one feed, one category), newest first, each row with the feed title, the title, the date and an unread marker;
- `/feeds` - the subscription list with the per feed unread count, an add form and a delete action;
- `/entries/{id}` - the reader view: the stored content, the feed title, a link to the source, the star toggle, the mark read toggle and the previous and next links;
- `/categories` - the categories.

Human decisions left to the operator: which category a new feed goes into, whether a feed that stopped parsing is deleted, and what to keep (star) versus what to read. The acceptance probe drives the JSON API only; the operator checks the HTML surface by hand, and the acceptance README lists those steps.

## 8. Operating commands
    export FEEDREADER_DATABASE_URL='postgres://feedreader:feedreader@127.0.0.1:5432/feedreader?sslmode=disable'
    export FEEDREADER_API_KEY='choose-a-long-random-value'
    export FEEDREADER_USERNAME='reader'
    export FEEDREADER_PASSWORD='choose-a-password'
    export FEEDREADER_LISTEN_ADDR='127.0.0.1:8080'
    export FEEDREADER_POLLING_INTERVAL='1h'
    feedreader migrate
    feedreader serve

`feedreader serve` runs the HTTP server and the scheduler in one process. The service reads only environment variables, so the acceptance environment uses the same two commands with a disposable database and `FEEDREADER_POLLING_INTERVAL=5s` (see the acceptance README).

## 9. Acceptance mapping
| Case | What it pins | Endpoints |
| --- | --- | --- |
| A01 | standing intake: a new item arrives through the scheduler, carries the feed title and its canonical link, and is listed once | `POST /api/v1/feeds`, `GET /api/v1/entries`, `PUT /api/v1/feeds/{id}/refresh`, `GET /api/v1/config` |
| A02 | reading state: mark read one by one, per feed, per category and for the account, with the unread counts falling and the starred flag independent | `PUT /api/v1/entries/{id}`, `PUT /api/v1/feeds/{id}/entries`, `PUT /api/v1/categories/{id}/entries`, `PUT /api/v1/entries/read-all`, `GET /api/v1/unread_count` |
| A03 | portability: the export holds one outline per feed inside its category outline and the import recreates the list without duplicates | `GET /api/v1/export`, `POST /api/v1/import`, `DELETE /api/v1/feeds/{id}` |
| A04 | the subscription list: a feed URL and a site URL are accepted, and a duplicate URL, an unknown category, a malformed URL and a body that is not a feed are refused without writing a row | `POST /api/v1/feeds`, `GET /api/v1/feeds` |
| A05 | the reader view: content, feed title and canonical link of the selected entry, previous and next over the read entries, and a not found for an unknown id | `GET /api/v1/entries/{id}`, `GET /api/v1/entries` |

The probe compares the reader view with the entry it selected from the list, so it never depends on the order the service returns; the pinned order of 4.4 exists for the operator's own view and for the navigation rule.

## 10. Known limitations
- The upstream reference was read as source only and was never built, installed or run; no upstream runtime behaviour is claimed.
- The probe drives the JSON API. The HTML surface of section 7 is checked by hand, not asserted.
- The probe exercises RSS 2.0 fixtures only; Atom 0.3 and 1.0 and JSON Feed 1.0 and 1.1 parsing is specified in 5.2 but not covered by an acceptance case.
- The scheduled intake check of A01 is reported as `not_run` when the service does not report `polling_interval_seconds`, or when the configured interval is longer than the probe intake timeout.
- The probe needs a disposable instance, because `read-all` is account wide; it refuses to run against an instance that holds subscriptions outside its own `probe-` categories and deletes only records it created.
- The site URL discovery of 5.2 reads the `link rel="alternate"` tags of the page only; it does not crawl the page body.
- Full text extraction, rewrite and filter rules, share codes, webhooks, third party integrations and the Fever or Google Reader compatible APIs are outside this leaf.
- Podcast and video enclosures, playback position and the per feed crawler mode are outside this leaf.
- The reader view renders the stored content only; the target never re-fetches the article page.
- Multi user accounts, per user API tokens and passkey or OAuth logins are reduced to a single seeded operator.
- An OPML import reuses an existing category by name, so two categories with the same title inside one file are merged into the first match.
