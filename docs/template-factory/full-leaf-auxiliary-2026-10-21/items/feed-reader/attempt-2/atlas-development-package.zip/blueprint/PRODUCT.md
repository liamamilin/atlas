# 产品定义

Feed Reader

One individual reader running a self-hosted feed reader service on their own server, following about twenty blogs and news feeds.

Keep a personal list of feeds, let new items arrive on their own, and clear the unread backlog each morning while keeping the list portable

1. Add sources: submit a site or feed URL, or import an OPML file, placing each feed in a category; the user's list is the only selector of what may appear.
2. Intake: the background scheduler refreshes each subscribed feed on its own interval (default polling 1h, honoring feed TTL and ETag/Last-Modified), parses RSS, Atom or JSON Feed, and stores newly published items attributed to their feed with status unread.
3. Triage: open the Unread view to see what arrived, with per-feed and total unread counts, then open an item to read it in the reader view with previous/next navigation through already-read items.
4. Record state: mark entries read (one by one, per feed or category, or mark all as read) and star the keepers, since starred is a separate flag from unread/read.
5. Maintain: export the subscription list as OPML to carry it to another reader, and re-import that file to restore the same feeds.

- A01: A newly published item shows up in the Unread view after a scheduled refresh, carries its feed's title and canonical link, and is listed only once because the item identifier is already known.
- A02: Marking an item read removes it from the Unread view and lowers the shown unread count, the same happens when a whole feed, a whole category or the whole account is marked read, and an item that was starred keeps its starred flag after being read and still appears in the starred list.
- A03: Exporting the subscription list yields one OPML outline per subscribed feed with its xmlUrl inside its category outline, and importing that file back recreates the same subscriptions without duplicates.
- A04: A feed URL and a site URL are subscribed into a category and listed there with the feed title, while a duplicate feed URL, an unknown category, a malformed URL and a URL that is not a feed are all rejected without creating a subscription.
- A05: Opening an item in the reader view returns its content, its feed title and its canonical link with previous/next entries drawn from the already-read items, and an unknown item id is reported as not found.

- R01 One individual reader running a self-hosted feed reader service on their own server, following about twenty blogs and news feeds.: Keep a personal list of feeds, let new items arrive on their own, and clear the unread backlog each morning while keeping the list portable

| ID | 能力 | 阶段 | 适用性 | 理由 | 来源 | 验收 |
| --- | --- | --- | --- | --- | --- | --- |
| F01 | Standing intake of the user's own list: a background scheduler refreshes each subscribed feed on its own interval (default 1h, raised by feed TTL, Cache-Control and Expires, never lowered below the configured interval), honours ETag/Last-Modified, parses RSS, Atom or JSON Feed and stores each newly published item once, attributed to its feed and unread. | P0 | current required | A01: A newly published item shows up in the Unread view after a scheduled refresh, carries its feed's title and canonical link, and is listed only once because the item identifier is already known. | S01, S02, S03, S04, S05, S06, S07, S08, S09, S10, S11, S12, S13, S14, S15, S16, S17, S18, S19 | A01 |
| F02 | Personal subscription list management: the operator's own list of sources grouped into categories, filled by a feed URL, by a site URL that advertises a feed, or by an OPML import, and the only selector of what may appear on the reading surface. | P0 | current required | A02: Marking an item read removes it from the Unread view and lowers the shown unread count, the same happens when a whole feed, a whole category or the whole account is marked read, and an item that was starred keeps its starred flag after being read and still appears in the starred list. | S01, S02, S03, S04, S05, S06, S07, S08, S09, S10, S11, S12, S13, S14, S15, S16, S17, S18, S19 | A02 |
| F03 | Triage surface with per feed and total unread counts, an unread view over the selected scope and a reader view that opens one item with previous/next navigation through already-read items. | P0 | current required | A03: Exporting the subscription list yields one OPML outline per subscribed feed with its xmlUrl inside its category outline, and importing that file back recreates the same subscriptions without duplicates. | S01, S02, S03, S04, S05, S06, S07, S08, S09, S10, S11, S12, S13, S14, S15, S16, S17, S18, S19 | A03 |
| F04 | Reading state recording: mark entries read one by one, per feed, per category or for the whole account, and star the keepers with a flag that stays independent of unread and read. | P0 | current required | A04: A feed URL and a site URL are subscribed into a category and listed there with the feed title, while a duplicate feed URL, an unknown category, a malformed URL and a URL that is not a feed are all rejected without creating a subscription. | S01, S02, S03, S04, S05, S06, S07, S08, S09, S10, S11, S12, S13, S14, S15, S16, S17, S18, S19 | A04 |
| F05 | List portability: export the subscription list as OPML with one outline per feed inside its category outline, and re-import that file to restore the same subscriptions without duplicates. | P0 | current required | A05: Opening an item in the reader view returns its content, its feed title and its canonical link with previous/next entries drawn from the already-read items, and an unknown item id is reported as not found. | S01, S02, S03, S04, S05, S06, S07, S08, S09, S10, S11, S12, S13, S14, S15, S16, S17, S18, S19 | A05 |
