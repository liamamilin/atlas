# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_02914f6fcd344568a566187c9724dfba@1

Create, read, edit, reschedule and delete your own titled appointments with a start and an end date-time in a fixed UTC+08:00 offset and optional location and notes, shown on a real seven-column month grid whose schedule is persisted locally across restarts and navigable back into past months.

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_attempt_1_1

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/src/Grid/Grid.vala · 14ee18015422bf195cd0df1cbab7170525166f9a

code_observation: The month surface is a Gtk.Grid built with insert_column (7) and homogeneous columns and rows, so the frame is seven columns wide by construction.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S03 · ev_assisted_attempt_1_10

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/src/Grid/GridDay.vala · 14ee18015422bf195cd0df1cbab7170525166f9a

code_observation: Keyboard handling inside a day cell: Return emits on_event_add for the cell date, Page_Up calls change_month (1) and Page_Down calls change_month (-1).

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S04 · ev_assisted_attempt_1_11

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/src/Grid/GridDay.vala · 14ee18015422bf195cd0df1cbab7170525166f9a

code_observation: Dropping an event on another day shifts DTSTART and DTEND by the day difference and writes the component back with calmodel.update_event (src, comp, ECal.ObjModType.ALL), i.e. rescheduling to another day.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S05 · ev_assisted_attempt_1_12

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/src/Grid/Header.vala · 14ee18015422bf195cd0df1cbab7170525166f9a

code_observation: The weekday header is itself a seven-column Gtk.Grid with a single row.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S06 · ev_assisted_attempt_1_13

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/src/Grid/Header.vala · 14ee18015422bf195cd0df1cbab7170525166f9a

code_observation: update_columns fills exactly seven labels formatted with %a, starting from the configured first day of the week.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S07 · ev_assisted_attempt_1_14

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/src/Grid/Header.vala · 14ee18015422bf195cd0df1cbab7170525166f9a

code_observation: The header exposes a 'Show Week Numbers' action in a context menu, i.e. the upstream week-number column is an optional toggle rather than a core part of the frame.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S08 · ev_assisted_attempt_1_15

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/src/Grid/EventButton.vala · 14ee18015422bf195cd0df1cbab7170525166f9a

code_observation: An event block displays only the component summary, as an ellipsized label.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S09 · ev_assisted_attempt_1_16

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/src/Grid/EventButton.vala · 14ee18015422bf195cd0df1cbab7170525166f9a

code_observation: update() replaces the component and refreshes the label with the new summary, so an edited event's block re-labels itself.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S10 · ev_assisted_attempt_1_17

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/README.md · 14ee18015422bf195cd0df1cbab7170525166f9a

documentation: The upstream build depends on libecal, libedataserverui, libical, libfolks and GTK/Granite, i.e. its store is an Evolution Data Server / iCalendar source stack rather than a local single-file store.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S11 · ev_assisted_attempt_1_18

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/README.md · 14ee18015422bf195cd0df1cbab7170525166f9a

documentation: Upstream is configured with meson and built with ninja, then installed as a desktop binary launched with io.elementary.calendar.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S12 · ev_assisted_attempt_1_19

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING · 14ee18015422bf195cd0df1cbab7170525166f9a

documentation: The upstream project ships the GNU General Public License version 3 text (29 June 2007).

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S13 · ev_assisted_attempt_1_2

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/src/Grid/Grid.vala · 14ee18015422bf195cd0df1cbab7170525166f9a

code_observation: Before the day widgets are rebuilt the code asserts new_dates.size % 7 == 0, so the displayed date range is always a whole number of seven-day weeks.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S14 · ev_assisted_attempt_1_3

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/src/Grid/Grid.vala · 14ee18015422bf195cd0df1cbab7170525166f9a

code_observation: Day cells are laid out with the column counter wrapping modulo 7 and the row counter incremented on the wrap, so a month frame is seven columns by N week rows.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S15 · ev_assisted_attempt_1_4

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/src/Grid/Grid.vala · 14ee18015422bf195cd0df1cbab7170525166f9a

code_observation: add_event walks every day cell and attaches the component to each cell for which Calendar.Util.ecalcomponent_is_on_day (event, grid_day.date) holds, so one event can be attached to several day cells at once.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S16 · ev_assisted_attempt_1_5

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/src/Grid/Grid.vala · 14ee18015422bf195cd0df1cbab7170525166f9a

code_observation: update_event adds the component to the cells it now belongs to and removes it from every other cell, so an edited or moved event leaves the cells it no longer touches.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S17 · ev_assisted_attempt_1_6

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/src/Grid/Grid.vala · 14ee18015422bf195cd0df1cbab7170525166f9a

code_observation: The focused day is written into Maya.Application.saved_state as 'selected-day' and the store's displayed month is switched when the focused day lies in another month.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S18 · ev_assisted_attempt_1_7

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/src/Grid/GridDay.vala · 14ee18015422bf195cd0df1cbab7170525166f9a

code_observation: Each day cell keeps its event buttons in a hash table keyed by the event UID, replacing any earlier button with the same UID, so distinct events - including two that overlap in time - coexist in one cell.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S19 · ev_assisted_attempt_1_8

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/src/Grid/GridDay.vala · 14ee18015422bf195cd0df1cbab7170525166f9a

code_observation: remove_event drops an event from the cell by looking up its UID in that same per-cell table.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S20 · ev_assisted_attempt_1_9

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/src/Grid/GridDay.vala · 14ee18015422bf195cd0df1cbab7170525166f9a

code_observation: A double click on a day cell (n_press == 2) emits on_event_add with that cell's date, which is the entry point for creating an event on the grid.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## S21 · ev_assisted_attempt_1_design

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/LICENSE · 14ee18015422bf195cd0df1cbab7170525166f9a

inference: Target proposal: implement the leaf as a single-user desktop GUI application in Python 3 using only the standard library - Tkinter for the seven-column month frame, the day cells, the event blocks and the appointment editor - with one local JSON document as the persistent store, a fixed UTC+08:00 offset and no accounts, sync, recurrence, all-day mode or notifications; the upstream elementary/calendar project (GPL-3.0) is used only as a structural reference for the grid and event model and no upstream code is copied.

GPL-3.0

https://github.com/elementary/calendar/blob/14ee18015422bf195cd0df1cbab7170525166f9a/COPYING

只参考设计；不复制上游代码。OpenCode CLI + Go 研究与编写；独立会话静态审阅通过，上游和下游应用均未运行。

## 待验证

- 辅助静态独审通过，不代表运行通过
- 上游not_run
- Only the month frame is implemented; there is no day, week, agenda or year view, and the upstream week-number toggle is deliberately not reproduced.
- Rescheduling is done through the editor's date-time fields rather than by dragging a block to another day, so the upstream drag-and-drop reschedule is not reproduced.
- The upstream Evolution Data Server / iCalendar source layer, calendar colours, calendars sidebar, context menus and libical interop are out of scope; the store is one local JSON document.
- All instants use a fixed UTC+08:00 offset with no daylight-saving handling and no time-zone switch, so appointments do not follow a machine zone change.
- There is no undo/redo, no search, no import/export, no recurring event, no all-day mode, no reminders, no attendee or invitation data.
- The widget-tree half of the acceptance probe is reported as NOT_RUN on a machine without a graphical display; the model/store half still runs there.
- The target code is not present in this workspace, so the probe is expected to fail loudly rather than pass until the implementation is written.
- No upstream code was copied; the GPL-3.0 upstream project was read as a structural reference only.
