# 阶段与验收

## P0 · 核心可用

Create, read, edit, reschedule and delete your own titled appointments with a start and an end date-time in a fixed UTC+08:00 offset and optional location and notes, shown on a real seven-column month grid whose schedule is persisted locally across restarts and navigable back into past months.

| 用例 | 类型 | 行为 | 执行器 |
| --- | --- | --- | --- |
| A01 | positive | The month view shows exactly 7 weekday columns and 4-6 week rows, and the header's next/previous controls move exactly one month and re-render the grid, including navigation back into a past month. | acceptance/probe.py |
| A02 | positive | An appointment 2026-10-05 10:00-11:00 (+08:00) with title, location and notes renders on the October 2026 grid and is readable in the editor, while a save whose end is not strictly after its start is refused with a message and no record is written and no recurrence/all-day/attendee field exists. | acceptance/probe.py |
| A03 | positive | An appointment 2026-10-31 22:00 to 2026-11-01 02:00 is visible in both the October 2026 and November 2026 grids, and two overlapping appointments in the same day cell are both displayed with the second save accepted. | acceptance/probe.py |
| A04 | positive | After an edit or reschedule the previous slot is empty and the new slot shows the updated title and time, and deleting a probe-created appointment removes it from the grid and from the persistent store while leaving other records untouched. | acceptance/probe.py |
| A05 | positive | After restarting the app every created appointment is still present and a past month can be re-navigated to. | acceptance/probe.py |
