# 决策与默认值

## D01 · 首版运行与数据边界？

A single Python 3.9+ process on the user's own machine, standard library only, Tkinter for the desktop window. No server, no listening socket, no network access, no account. The entire mutable state is one JSON document at <data_dir>/appointments.json (default per-user directory, overridable with --data-dir); the probe overrides it with a fresh disposable temporary directory so no user record is ever read or deleted.

When to ask / 询问条件: 确需公网托管或多人数据时先确认，不自行扩展。

保护本地数据，避免默认外发。

assisted default

## D02 · 是否复刻上游？

Target proposal: implement the leaf as a single-user desktop GUI application in Python 3 using only the standard library - Tkinter for the seven-column month frame, the day cells, the event blocks and the appointment editor - with one local JSON document as the persistent store, a fixed UTC+08:00 offset and no accounts, sync, recurrence, all-day mode or notifications; the upstream elementary/calendar project (GPL-3.0) is used only as a structural reference for the grid and event model and no upstream code is copied.

When to ask / 询问条件: 目标变化、破坏已有数据或需要引入上游实现/依赖时先确认。

不混淆来源事实与目标设计。

assisted default
