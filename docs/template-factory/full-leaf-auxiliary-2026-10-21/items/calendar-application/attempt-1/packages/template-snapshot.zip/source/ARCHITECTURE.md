# 架构与契约

# Architecture - Personal Month-Grid Calendar (desktop target)

## 1. Scope
One local user on one machine. The product owns exactly two structures:

- **Appointment** - title (required), start date-time, end date-time (both required), optional location, optional notes. Nothing else.
- **Schedule** - the accumulated appointments, persisted locally and shown on a seven-column month frame that can be walked one month backwards or forwards.

Out of scope for this leaf: recurrence, all-day events, invitations/RSVP, accounts, sharing, sync, notifications, alerts, time-zone switching, tasks, resource booking, day/week/agenda frames, search, week numbers, undo.

## 2. Target stack (explicit proposal)
- Runtime: Python 3.9+, standard library only - no third-party packages, nothing to install.
- UI: Tkinter (Tk). A real desktop window on Linux, macOS and Windows.
- Storage: one JSON document file written atomically. No database server, no HTTP service, no listening socket, no network access at all.
- This is an independent implementation. The upstream project (elementary/calendar, GPL-3.0) is a structural reference only; no upstream source code is copied.

## 3. Module map

    calendar_app/
      __init__.py    create_app(data_dir=None, headless=True) -> App
      timeutil.py    UTC8 offset, parsing/formatting, month arithmetic, month frames
      model.py       Appointment dataclass, validation rules, SaveResult
      store.py       AppointmentStore - JSON file, atomic replace, CRUD
      gridmodel.py   MonthGrid, DayCell, EventBlock - the month frame model
      controller.py  CalendarController - navigation, CRUD, validation
      app.py         App - binds a controller to an optional window
      ui_tk.py       CalendarWindow (tk.Tk), EditorDialog (tk.Toplevel)
      __main__.py    python3 -m calendar_app [--data-dir PATH]

Layering rule: timeutil, model, store and gridmodel never import tkinter, so the whole schedule can be exercised without a display. Only ui_tk touches Tk.

## 4. Time semantics
- One fixed offset: UTC+08:00, i.e. datetime.timezone(timedelta(hours=8)). No DST, no zone table, no zone switch. The machine local zone is never used for storage.
- Stored instants are always written as YYYY-MM-DDTHH:MM:SS+08:00.
- The editor edits wall-clock text YYYY-MM-DD HH:MM in the fixed offset.
- An appointment covers the half-open interval [start, end). The days it touches are start.date() .. (end - 1 microsecond).date(); an appointment ending exactly at 2026-10-31 00:00 touches 2026-10-29 and 2026-10-30 but not 2026-10-31.
- end must be strictly greater than start. There is no zero-length and no all-day form.
- The OS clock is read only to mark today in the frame; it never moves an appointment.

## 5. Record contract

    {
      'uid':        '32 lowercase hex characters, generated once, stable across edits',
      'title':      'trimmed, 1..200 characters, never blank',
      'start':      '2026-10-05T10:00:00+08:00',
      'end':        '2026-10-05T11:00:00+08:00',
      'location':   '0..200 characters, optional',
      'notes':      '0..2000 characters, optional',
      'created_at': '2026-10-21T09:12:00+08:00',
      'updated_at': '2026-10-21T09:12:00+08:00'
    }

There is deliberately no rrule, all_day, attendees, alerts, calendar, timezone or tzid key. Every appointment has a time-of-day range.

Validation (every failure is reported as a field error, none is fatal):

| Field | Rule | Message |
| title | non-blank after trimming, at most 200 chars | 'Title is required' / 'Title is limited to 200 characters' |
| start | parses as YYYY-MM-DD HH:MM | 'Start must be a local date-time (YYYY-MM-DD HH:MM)' |
| end | parses, and end > start | 'End must be after start' |
| location | at most 200 chars | 'Location is limited to 200 characters' |
| notes | at most 2000 chars | 'Notes are limited to 2000 characters' |

A validation failure returns SaveResult(ok=False, appointment=None, errors={field: message}) and writes nothing.

## 6. Store contract
File: <data_dir>/appointments.json

    {
      'schema_version': 1,
      'appointments': [ <record>, ... ]
    }

- AppointmentStore(path); path is a pathlib.Path.
- The store is the single source of truth: the controller re-reads the file for every read, so two application instances over the same directory agree.
- Writes are atomic: the document is written to appointments.json.tmp in the same directory, flushed and fsync-ed, then moved onto the target with os.replace. A crash leaves either the previous or the next file, never a truncated one.
- Reading never writes; launching the application does not rewrite the file.
- A missing file means an empty schedule; the directory is created on demand.
- A malformed file is a hard error at launch and the file is left untouched.
- A delete removes exactly one uid; other records are never rewritten.

## 7. Month frame contract
- The week starts on Monday; the header shows seven labels, Mon .. Sun.
- The frame for month M contains every day of M, padded to whole weeks with filler cells from the adjacent months, so the frame always has 7 columns and 4, 5 or 6 week rows.
- Filler cells are rendered dimmed and never carry an event block, so 'visible in the October grid' and 'visible in the November grid' are unambiguous.
- DayCell: date, in_current_month, blocks.
- EventBlock: uid, title, start, end, location, notes, day, continues_before, continues_after.
- MonthGrid: year, month, weeks (list of 7-cell rows), weekday_labels, header_label ('October 2026'), blocks_on(date) -> list of EventBlock.
- Navigation moves exactly one month: next_month() and previous_month() roll the year over at the boundaries (2026-12 -> 2027-01, 2026-01 -> 2025-12) and rebuild the frame. Navigation backwards is unbounded.

## 8. Controller contract (the app public API)

    CalendarController(data_dir)
      .store                    -> AppointmentStore
      .year, .month             -> int (visible month)
      .grid                     -> MonthGrid, rebuilt on every change
      .open_month(year, month)
      .next_month() / .previous_month()
      .all_appointments()       -> list of Appointment
      .find(uid)                -> Appointment or None
      .save_new(title, start_text, end_text, location='', notes='') -> SaveResult
      .save_existing(uid, title, start_text, end_text, location='', notes='') -> SaveResult
      .delete(uid)              -> bool
      .add_listener(callback)   -> called after every successful change

    SaveResult(ok, appointment, errors)

start_text and end_text are editor strings (YYYY-MM-DD HH:MM); an unparsable value is returned as a field error and never raised. save_existing on an unknown uid returns ok=False and writes nothing.

## 9. UI surfaces (Tk)
- CalendarWindow(tk.Tk): header with header_label (a tk.Label naming the month), prev_button, next_button, new_button and seven weekday labels exposed by header_weekday_labels() -> list of str.
- grid_frame holds the day-cell frames, attached with grid() at columns 0..6 of each row. grid_geometry() -> (columns, rows) is computed from the live widget tree, not from a stored number.
- Each cell frame carries the attribute cell_date (a datetime.date) and holds a date label plus a nested blocks frame whose children are one tk.Label per event block, in chronological order. A cell with many blocks uses a scrollable list so every block stays reachable.
- header_label_text() -> str.
- open_editor(date=None, uid=None) -> EditorDialog.
- The window registers itself as a controller listener, so any successful change rebuilds the frame.
- EditorDialog(tk.Toplevel): title_var, start_var, end_var, location_var, notes_var, error_var (all tk.StringVar), a Save button, a Delete button in edit mode only, and a Cancel button. save() -> bool returns False and fills error_var when the controller refuses. delete() -> bool.
- Double-clicking a day cell, or pressing Return in it, opens the editor for that date with 09:00-10:00 pre-filled.
- The header previous/next buttons call controller.previous_month() / next_month() and re-render.

## 10. Lifecycle and transaction semantics
- Every mutation is validate -> persist -> rebuild. If validation fails, neither the file nor the visible frame changes.
- Create inserts a new uid; edit replaces the record that keeps its uid and bumps updated_at; delete removes exactly one uid.
- The frame is derived state, rebuilt from the store after every change; the UI keeps no second copy of the schedule.
- Restart means launch, read the file, rebuild the frame. The file is not rewritten.

## 11. Edge cases

| Case | Behaviour |
| end equals start | refused, 'End must be after start', nothing written |
| end precedes start | refused, same message |
| blank or whitespace title | refused, 'Title is required' |
| unparsable date-time text | refused with a field error, never an exception |
| title longer than 200 chars | refused, length message |
| event ends exactly at midnight | that day is not touched (half-open [start,end)) |
| event crosses midnight | both days are touched |
| event crosses a month boundary | touched in both months |
| event crosses a year boundary | touched in December and January |
| two or three events in one cell | all are stored and all are rendered |
| 28-day month starting on Monday | 4 week rows |
| 31-day month starting on Sunday | 6 week rows |
| delete of an unknown uid | no-op, returns False, store unchanged |
| store file missing at launch | empty schedule, file created on the first save |
| store file malformed | launch fails with a clear error, file not overwritten |
| edit of an unknown uid | refused, returns ok=False, store unchanged |

## 12. Verification strategy
Three layers, reported separately:
1. Model and store layer (always executed): the probe drives the real controller, model, store and month-frame model through the public API in section 8 and asserts the on-disk document.
2. Widget-tree layer (executed only when a display is available): the probe drives the real Tk tree - header buttons, day-cell frames, event-block labels, editor variables and the error message.
3. Manual layer (operator): the visible journey on a real desktop.
A check that cannot be executed is reported as NOT_RUN and never as PASS. The probe writes nothing outside a fresh temporary directory and deletes only the records it created inside it.

## 13. Operating commands
- Install: nothing to install; standard library only.
- Launch: python3 -m calendar_app --data-dir <dir>
- Default data directory: $XDG_DATA_HOME/personal-calendar/appointments.json, else ~/Library/Application Support/PersonalCalendar/appointments.json on macOS, else ~/.local/share/personal-calendar/appointments.json.
- Verify: python3 probe.py (options --app-path DIR to point at the package, --keep to retain the temporary probe data).

## 14. Human decisions and defaults
- Week starts on Monday (upstream makes it configurable; the target fixes it so the frame is deterministic).
- Only the month frame exists; there is no day, week, agenda or year frame.
- Adjacent-month filler cells are dimmed and never carry blocks.
- New appointments opened from a day cell default to 09:00-10:00 in the fixed offset.
- Title is trimmed; blank titles are refused rather than defaulted.
- uid is a random 32-hex string generated once and never reused.
- Editing an appointment keeps its uid and its created_at; only updated_at changes.
- Delete is available only from the editor of one existing record; there is no bulk delete and no undo.
- Two instances writing the same file at the same time are out of scope; last writer wins.

## 15. Known limits
- The upstream project was never installed, built or executed while writing this blueprint; every upstream statement here is a read-only observation.
- The target implementation does not exist in this workspace yet, so the probe is written against the contract pinned above and fails loudly until the code lands.
- On a headless machine the widget-tree assertions are NOT_RUN.
- No certification, conformance or performance claim is made.
