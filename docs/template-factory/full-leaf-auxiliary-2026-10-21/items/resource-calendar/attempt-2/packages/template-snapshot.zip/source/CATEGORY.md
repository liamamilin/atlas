# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_fe000b631b6b4b21a2ab5144d5164a72@1

Check the Aurora room calendar for a free window, claim Thursday 2026-10-22 14:00-16:00, see a clashing claim refused with the conflict named, then cancel and confirm the slot is free again.

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_attempt_2_1

https://github.com/technekey/booking-tool/blob/de05ec6cf49886f2f6194f42c16254ec1183920a/booking-tool.py · de05ec6cf49886f2f6194f42c16254ec1183920a

code_observation: overlaps() parses '%Y-%m-%d %H:%M' strings and returns True only when start1 < end2 and start2 < end1, so directly touching intervals are not considered overlapping.

MIT

https://github.com/technekey/booking-tool/blob/de05ec6cf49886f2f6194f42c16254ec1183920a/LICENSE

只参考设计；不复制上游代码。OpenCode CLI 研究与编写（渠道与模型见调用记录）；独立会话静态审阅通过，上游和下游应用均未运行。

## S03 · ev_assisted_attempt_2_2

https://github.com/technekey/booking-tool/blob/de05ec6cf49886f2f6194f42c16254ec1183920a/booking-tool.py · de05ec6cf49886f2f6194f42c16254ec1183920a

code_observation: The /bookings POST handler loops over all stored bookings, derives the lab name from each stored description with a regex, and returns HTTP 400 when the lab matches and overlaps(start, end, booking['start'], booking['end']) is true.

MIT

https://github.com/technekey/booking-tool/blob/de05ec6cf49886f2f6194f42c16254ec1183920a/LICENSE

只参考设计；不复制上游代码。OpenCode CLI 研究与编写（渠道与模型见调用记录）；独立会话静态审阅通过，上游和下游应用均未运行。

## S04 · ev_assisted_attempt_2_3

https://github.com/technekey/booking-tool/blob/de05ec6cf49886f2f6194f42c16254ec1183920a/booking-tool.py · de05ec6cf49886f2f6194f42c16254ec1183920a

code_observation: delete_event requires an authenticated session, allows admins, otherwise compares the session username with a 'booked by' name parsed from the stored description, and rewrites the rebuilt booking list back to the JSON file.

MIT

https://github.com/technekey/booking-tool/blob/de05ec6cf49886f2f6194f42c16254ec1183920a/LICENSE

只参考设计；不复制上游代码。OpenCode CLI 研究与编写（渠道与模型见调用记录）；独立会话静态审阅通过，上游和下游应用均未运行。

## S05 · ev_assisted_attempt_2_4

https://github.com/technekey/booking-tool/blob/de05ec6cf49886f2f6194f42c16254ec1183920a/templates/index.html · de05ec6cf49886f2f6194f42c16254ec1183920a

code_observation: The embedded FullCalendar initialization uses events:'/bookings', defaults to the month view, sets editable:true, and includes month, agendaWeek, and agendaDay in the header right controls.

MIT

https://github.com/technekey/booking-tool/blob/de05ec6cf49886f2f6194f42c16254ec1183920a/LICENSE

只参考设计；不复制上游代码。OpenCode CLI 研究与编写（渠道与模型见调用记录）；独立会话静态审阅通过，上游和下游应用均未运行。

## S06 · ev_assisted_attempt_2_5

https://github.com/technekey/booking-tool/blob/de05ec6cf49886f2f6194f42c16254ec1183920a/README.md · de05ec6cf49886f2f6194f42c16254ec1183920a

documentation: The README says the tool is a test tool not intended for serious use without evaluation and modification, identifies file read/write instead of a database as a big disadvantage, and says it may not suit real use cases.

MIT

https://github.com/technekey/booking-tool/blob/de05ec6cf49886f2f6194f42c16254ec1183920a/LICENSE

只参考设计；不复制上游代码。OpenCode CLI 研究与编写（渠道与模型见调用记录）；独立会话静态审阅通过，上游和下游应用均未运行。

## S07 · ev_assisted_attempt_2_design

https://github.com/technekey/booking-tool/blob/de05ec6cf49886f2f6194f42c16254ec1183920a/LICENSE · de05ec6cf49886f2f6194f42c16254ec1183920a

inference: Explicit target proposal, not an upstream fact: build a small Node.js 22, Fastify 5, SQLite, and server-rendered web application in which the Aurora room schedule is the authority. The core is a public busy/free week read model, a transactional half-open-interval claim command, a 409 conflict refusal naming the existing claim and both times, and an owner-or-admin soft cancellation that reopens the window. This is inferred from the web delivery profile and the leaf model of a resource-owned schedule; suite synchronization, approvals, recurrence, and resource administration are deliberately omitted.

MIT

https://github.com/technekey/booking-tool/blob/de05ec6cf49886f2f6194f42c16254ec1183920a/LICENSE

只参考设计；不复制上游代码。OpenCode CLI 研究与编写（渠道与模型见调用记录）；独立会话静态审阅通过，上游和下游应用均未运行。

## 待验证

- 辅助静态独审通过，不代表运行通过
- 上游not_run
- The template models one fixed room and one fixed policy; there is no administration console, resource inventory, recurring-series editor, approval flow, delegate routing, notification delivery, or no-show check-in.
- Staff identity is delegated to a trusted ingress proxy. The application does not implement SSO, password authentication, CSRF protection for a cookie-based UI, or rate limiting, so it must not be exposed directly to an untrusted network.
- The probe verifies the JSON contract and core journey only. It does not install or start the target, render the UI, measure accessibility or performance, or certify security.
- The acceptance run requires an isolated disposable SQLite database with the fixed Thursday windows free. The probe exits as not_run with code 2 before any write when setup is unsafe, but it cannot prove that the database is disposable.
- Soft-cancelled reservations are retained with no restore, retention, purge, or reporting surface. Changing the room timezone requires a full data review because stored instants are rendered in the configured room zone.
- There is no idempotency key. If a 201 response is lost after commit, a retry can be refused as a conflict even though the first claim exists; the operator must inspect the week view.
- SQLite is a single-writer authority; the template does not scale horizontally or coordinate multiple writers.
