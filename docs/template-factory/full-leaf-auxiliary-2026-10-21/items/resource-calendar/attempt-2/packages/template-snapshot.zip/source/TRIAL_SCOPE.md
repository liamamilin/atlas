# 辅助试用范围

Check the Aurora room calendar for a free window, claim Thursday 2026-10-22 14:00-16:00, see a clashing claim refused with the conflict named, then cancel and confirm the slot is free again.

- The template models one fixed room and one fixed policy; there is no administration console, resource inventory, recurring-series editor, approval flow, delegate routing, notification delivery, or no-show check-in.
- Staff identity is delegated to a trusted ingress proxy. The application does not implement SSO, password authentication, CSRF protection for a cookie-based UI, or rate limiting, so it must not be exposed directly to an untrusted network.
- The probe verifies the JSON contract and core journey only. It does not install or start the target, render the UI, measure accessibility or performance, or certify security.
- The acceptance run requires an isolated disposable SQLite database with the fixed Thursday windows free. The probe exits as not_run with code 2 before any write when setup is unsafe, but it cannot prove that the database is disposable.
- Soft-cancelled reservations are retained with no restore, retention, purge, or reporting surface. Changing the room timezone requires a full data review because stored instants are rendered in the configured room zone.
- There is no idempotency key. If a 201 response is lost after commit, a retry can be refused as a conflict even though the first claim exists; the operator must inspect the week view.
- SQLite is a single-writer authority; the template does not scale horizontally or coordinate multiple writers.

OpenCode CLI 研究与编写（渠道与模型见调用记录）；独立会话静态审阅通过，上游和下游应用均未运行。模板先于应用；仅代表场景后续开发应用。严格G1/T08不因本包通过。