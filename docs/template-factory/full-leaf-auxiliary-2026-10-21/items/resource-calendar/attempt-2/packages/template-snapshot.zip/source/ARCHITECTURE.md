# 架构与契约

# Aurora Room Calendar - target architecture

## 1. Fixed scope and invariants

One shared bookable resource: room `aurora`, named **Aurora Conference Room**, timezone `Asia/Shanghai`, capacity 12, location `HQ 3F`. The fixed journey is the department room week of Monday 2026-10-19 through Sunday 2026-10-25, with Thursday 2026-10-22 at 14:00-16:00 claimed, overlapped, and cancelled.

A reservation is a staff claim over a half-open interval `[start,end)`. Confirmed claims are the only entries that make the room busy. Cancelled claims remain as audit rows and do not block time. The SQLite database is the single authority for the schedule; there is no external calendar sync, message bus, or second source of truth in the core.

Fixed room policy: Monday-Friday, 08:00-18:00 room-local time, 30-minute grid, minimum 30 minutes, maximum 4 hours, same local day, exclusive claims. Policy editing, multiple rooms, recurring series, approvals, delegates, notifications, check-in, and payments are out of scope for this template.

Purpose text is booking detail. Availability is readable by authenticated staff, but another staff member sees only that the room is busy, not the purpose. The owner and an administrator see the purpose.

## 2. Runtime and boundaries

- Node.js 22 LTS, TypeScript, Fastify 5, better-sqlite3, EJS, Luxon for IANA timezone conversion, and a small vanilla JavaScript enhancement for the week page.
- One web process serves HTML and JSON from the same origin. A SQLite file at `DATABASE_PATH` (default `./data/resource-calendar.sqlite`) is the only persistent store. Enable WAL, foreign keys, a 5000 ms busy timeout, and `synchronous=NORMAL`.
- No queue, cache, external identity provider, mail service, or calendar connector is required for the core journey. SQLite is a single-writer authority; horizontal scaling is a non-goal.
- Identity: a trusted ingress proxy authenticates staff, strips any inbound `X-Actor`, and injects the stable staff id as `X-Actor`; it may inject `X-Role: admin`. The application never accepts an actor from a JSON body. For local demo only, `NODE_ENV=development` with `DEV_ACTOR=alex` supplies the actor when the trusted header is absent; production must refuse that fallback.
- Every API response is JSON except `204 No Content` and the server-rendered HTML page. Errors use the shape `error: {code, message, details?}`.

## 3. Components and layout

```text
src/
  server.ts             process start, Fastify registration
  config.ts             DATABASE_PATH, PORT, NODE_ENV, DEV_ACTOR
  db.ts                 connection, migrations, seed
  schema.sql            rooms and reservations tables
  domain/time.ts        ISO parsing, room-zone conversion, 30-minute grid
  domain/policy.ts      availability window and duration rules
  domain/overlap.ts     strict half-open overlap
  domain/errors.ts      typed error codes
  routes/week.ts        GET week read model and HTML week page
  routes/reservations.ts POST create, GET own list, DELETE cancel
  views/week.ejs        server-rendered seven-day grid and forms
  public/week.js        progressive form submission and cancel buttons
scripts/seed.ts         idempotent room seed, no destructive deletes
```

The domain modules are pure and unit-testable. Routes parse transport data, call the domain rules, and run the transaction; they do not contain a second copy of the policy.

## 4. Data model

```sql
CREATE TABLE rooms (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  timezone TEXT NOT NULL,
  capacity INTEGER NOT NULL,
  location TEXT NOT NULL
);

CREATE TABLE reservations (
  id TEXT PRIMARY KEY,
  room_id TEXT NOT NULL REFERENCES rooms(id),
  actor_id TEXT NOT NULL,
  purpose TEXT NOT NULL CHECK (length(purpose) BETWEEN 1 AND 200),
  start_utc TEXT NOT NULL,
  end_utc TEXT NOT NULL,
  start_local_date TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('confirmed','cancelled')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  cancelled_at TEXT,
  cancelled_by TEXT,
  CHECK (end_utc > start_utc)
);

CREATE INDEX reservations_room_status_start
  ON reservations (room_id, status, start_utc);
CREATE INDEX reservations_actor_start
  ON reservations (actor_id, start_utc);
```

`start_utc` and `end_utc` are ISO-8601 instants in UTC with `Z`. `start_local_date` is the room-local calendar date of `start`. IDs are UUIDv4 strings. `actor_id` is the trusted staff id, not a display name. The `CHECK (end_utc > start_utc)` is defense in depth; the application must reject the same case with a 400 before attempting an insert.

The room row is seeded once: `INSERT OR IGNORE INTO rooms ...` for `aurora`. The seed never deletes reservations. No user table is required for this template; authorization compares `actor_id` and the trusted `X-Role` header.

## 5. Time and domain rules

- Parse `start` and `end` as ISO-8601 strings that include an explicit UTC offset. Convert both to instants; render room-local times with Luxon.
- The local start and end must be on the same room-local date, and both must land on a 30-minute boundary (`HH:00` or `HH:30`, seconds zero).
- Duration is `end - start` in whole minutes.
- If `end <= start`, return 400. The canonical code is `INVALID_INTERVAL`; a target that applies the duration rule first may return `INVALID_DURATION`, and both codes are conforming for this case. No row is written.
- If `end > start` and duration is below 30 minutes or above 240 minutes, return 400 `INVALID_DURATION`.
- The window must lie inside Monday-Friday 08:00-18:00 room-local time. An end at exactly 18:00 is allowed. Otherwise return 400 `OUTSIDE_AVAILABILITY`.
- Purpose is trimmed; it must contain 1-200 characters. Otherwise return 400 `INVALID_PURPOSE`.
- Overlap is strict: `a.start < b.end AND b.start < a.end`. Touching intervals are compatible. A 14:00-16:00 claim therefore conflicts with 14:30-15:30 and is compatible with 16:00-17:00.
- Conflict lookup considers only rows with `status = confirmed` for the same room. Cancelled rows never conflict.

## 6. HTTP contract

All endpoints require `X-Actor`. A missing or empty actor returns 401 `UNAUTHENTICATED`. The room id in the path must be `aurora`; any other room returns 404 `NOT_FOUND`.

### Week availability

`GET /api/rooms/aurora/week?weekStart=2026-10-19`

`weekStart` must be a Monday in the room timezone. Missing, malformed, or non-Monday values return 400 `INVALID_WEEK_START`. The week is exactly seven days, `weekEnd` exclusive.

```text
{
  room: {id, name, timezone, capacity, location},
  weekStart: 2026-10-19,
  weekEnd: 2026-10-26,
  days: [{date, weekday, opensAt: 08:00, closesAt: 18:00}, ... seven entries],
  busy: [{reservationId, start, end, mine, purpose?}, ... sorted by start]
}
```

`busy` contains only confirmed, non-zero reservations that intersect the week. `start` and `end` are ISO-8601 instants with the room offset, for example `2026-10-22T14:00:00+08:00`. `mine` is `true` when the caller owns the reservation. `purpose` is present only for the owner or an administrator; for other staff it is omitted or null. The busy projection never exposes `actor_id`.

### Caller reservation list

`GET /api/rooms/aurora/reservations?weekStart=2026-10-19`

Returns every stored row owned by the caller whose local start date falls in the week, including cancelled rows and any defensive zero-length row. This is the caller audit view; it never returns another actor rows.

```text
{
  roomId: aurora,
  weekStart: 2026-10-19,
  weekEnd: 2026-10-26,
  reservations: [{id, start, end, purpose, status, createdAt, cancelledAt}, ...]
}
```

The list exists so a rejected write can be checked independently of the busy projection: a zero-length ghost row is not busy under half-open overlap but would still appear here.

### Create claim

`POST /api/rooms/aurora/reservations`

```text
{start: 2026-10-22T14:00:00+08:00, end: 2026-10-22T16:00:00+08:00, purpose: Training session}
```

Success is `201 Created` with:

```text
{reservation: {id, roomId: aurora, start, end, purpose, status: confirmed, createdAt}}
```

Validation follows the order in section 5. On success the row is confirmed and immediately busy. `201` is returned only after the transaction commits.

### Conflict refusal

An overlapping confirmed claim returns `409 Conflict`:

```text
{
  error: {
    code: SLOT_CONFLICT,
    message: Requested 2026-10-22 14:30-15:30 conflicts with reservation <id> at 2026-10-22 14:00-16:00,
    conflicts: [{id, start: 2026-10-22T14:00:00+08:00, end: 2026-10-22T16:00:00+08:00}]
  }
}
```

`conflicts` lists every overlapping confirmed reservation in start order. The message names the requested interval, every conflicting interval, and the conflicting reservation id, using room-local `YYYY-MM-DD HH:MM` times, 24-hour clock. No row is inserted or updated on this path.

### Cancel claim

`DELETE /api/rooms/aurora/reservations/:id`

- `204 No Content` for the owner or an administrator; the row becomes `cancelled`, `cancelled_at` and `cancelled_by` are set, and it no longer appears in `busy`.
- `403 FORBIDDEN` for an authenticated non-owner; the row is unchanged.
- `404 NOT_FOUND` when the id is unknown, belongs to another room, or is already cancelled. Repeating a cancellation is therefore a 404.

There is no hard delete and no restore endpoint. An administrator uses the same route with the trusted `X-Role: admin` header.

## 7. Transactions and lifecycle

Create uses one write transaction:

1. Validate all request fields outside the transaction.
2. `BEGIN IMMEDIATE`.
3. Select confirmed rows for `aurora` whose `start_utc < new.end_utc` and `end_utc > new.start_utc`, ordered by `start_utc`.
4. If any row exists, `ROLLBACK` and return 409 with the conflict payload.
5. Insert one confirmed row, `COMMIT`, and return 201.

`BEGIN IMMEDIATE` takes the SQLite write lock before the conflict query, so two concurrent claims cannot both pass the check. One commits; the other sees the committed row and returns 409. The process is single-node; WAL still permits readers during the write.

Cancel uses `BEGIN IMMEDIATE`, loads the row, checks ownership and status, then updates `status = cancelled` with a conditional `WHERE id = ? AND status = confirmed`. If the update changes zero rows, roll back and return 404. This makes a racing double cancel deterministic.

Week and caller-list reads see committed data only. No read is allowed to repair or mutate rows. The seed is idempotent and never truncates tables. Reservations survive process restart; changing the room timezone is a data migration, not a runtime toggle.

## 8. Week page and operator surface

`GET /rooms/aurora/week?weekStart=2026-10-19` renders the seven-day grid server-side. Each day shows its local date, 08:00-18:00 range, and confirmed busy blocks. A block owned by the caller shows its purpose and a Cancel button; another staff member block is labelled Busy. The page includes a claim form with start, end, and purpose fields, and a JSON error area that displays the 409 message and conflict times.

`public/week.js` progressively enhances the form to `POST /api/rooms/aurora/reservations` and the cancel control to `DELETE /api/rooms/aurora/reservations/:id`, both same-origin. Without JavaScript the page remains readable; the acceptance probe does not render or score the UI. Labels are associated with inputs, focus is visible, and busy state is not conveyed by colour alone.

The API is the verification surface. A manual operator can open the page through the trusted ingress with an `X-Actor` identity, or use `NODE_ENV=development DEV_ACTOR=alex` for a local demo only. The probe itself always sends explicit `X-Actor` headers and never relies on the development fallback.

## 9. Acceptance and probe safety

The portable verifier targets the JSON API at `ATLAS_BASE_URL` and covers A01-A04. Before any write it reads the week and requires Thursday 09:00-10:00, 14:00-16:00, 14:30-15:30, and 16:00-17:00 to be free. If the view is unreachable or any window is occupied, it exits 2 with `status: not_run` and performs no POST or DELETE. It therefore never writes a setup claim before discovering that the 14:00 window is unusable.

All writes use generated `probe-*` actor ids. The probe creates only its own claims, soft-cancels only ids it created during best-effort cleanup, and never hard-deletes or cancels a row it did not create. It requires a disposable database and does not attempt to detect a shared one; the operator must provide isolation. Case failures exit 1; a complete pass exits 0.

## 10. Known limits

- One fixed room and one fixed policy; no resource inventory, admin console, approval flow, delegate routing, recurring series, notifications, check-in, or utilization reporting.
- Identity is delegated to a trusted ingress proxy; the application does not implement SSO, password authentication, CSRF protection for a cookie-based UI, or rate limiting. It must not be exposed directly to an untrusted network.
- The probe verifies the HTTP contract and core journey only. It does not install or start the target, render the UI, measure accessibility or performance, or certify security.
- The probe requires an isolated SQLite database with the fixed windows free. It exits 2 before writes when setup is unsafe, but it cannot prove that the database is disposable.
- Cancelled rows are retained with no restore, retention, purge, or reporting surface. A timezone change requires a full data review because stored instants are rendered in the configured room zone.
- There is no idempotency key. A lost 201 response can make a retry look like a conflict even though the first claim committed; the operator must inspect the week view.
- SQLite is a single-writer authority; this template does not scale horizontally or coordinate multiple writers.
