# 决策与默认值

## D01 · 首版运行与数据边界？

One Node.js 22 TypeScript/Fastify web process serving a server-rendered week page and JSON API; SQLite at DATABASE_PATH is the only authority; identity arrives as X-Actor from a trusted ingress proxy, with no external calendar or database service.

When to ask / 询问条件: 确需公网托管或多人数据时先确认，不自行扩展。

保护本地数据，避免默认外发。

assisted default

## D02 · 是否复刻上游？

Explicit target proposal, not an upstream fact: build a small Node.js 22, Fastify 5, SQLite, and server-rendered web application in which the Aurora room schedule is the authority. The core is a public busy/free week read model, a transactional half-open-interval claim command, a 409 conflict refusal naming the existing claim and both times, and an owner-or-admin soft cancellation that reopens the window. This is inferred from the web delivery profile and the leaf model of a resource-owned schedule; suite synchronization, approvals, recurrence, and resource administration are deliberately omitted.

When to ask / 询问条件: 目标变化、破坏已有数据或需要引入上游实现/依赖时先确认。

不混淆来源事实与目标设计。

assisted default
