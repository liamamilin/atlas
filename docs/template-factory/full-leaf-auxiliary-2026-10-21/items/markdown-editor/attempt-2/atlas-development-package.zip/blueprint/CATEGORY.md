# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

同一共享案例记录的静态研究与明确的设计推断；完整定位见inputs/shared-case-record.json。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_6ab05f5a50764c4f8f2eb9f74a9dfda8@1

Turn a plain draft into a saved README.md whose formatting exists only as markup characters, verifying the derived preview before saving

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_attempt_2_1

https://github.com/liyasthomas/marcdown/blob/f61f79f7d92f4a76a4d1a8bd446201fd2844159b/index.js · f61f79f7d92f4a76a4d1a8bd446201fd2844159b

code_observation: In the apply action switch, bold uses the prefix and suffix **, h1 uses the prefix '# ' and an empty suffix, and the other actions likewise receive fixed prefix and suffix strings.

MIT

https://github.com/liyasthomas/marcdown/blob/f61f79f7d92f4a76a4d1a8bd446201fd2844159b/LICENSE

只参考设计；不复制上游代码。OpenCode CLI 研究与编写（渠道与模型见调用记录）；独立会话静态审阅通过，上游和下游应用均未运行。

## S03 · ev_assisted_attempt_2_2

https://github.com/liyasthomas/marcdown/blob/f61f79f7d92f4a76a4d1a8bd446201fd2844159b/index.js · f61f79f7d92f4a76a4d1a8bd446201fd2844159b

code_observation: The modern-browser branch rebuilds the textarea value from the text before startPos, the prefix, the selected substring, the suffix, and the text after endPos, then sets selectionStart and selectionEnd to startPos and endPos plus the prefix length.

MIT

https://github.com/liyasthomas/marcdown/blob/f61f79f7d92f4a76a4d1a8bd446201fd2844159b/LICENSE

只参考设计；不复制上游代码。OpenCode CLI 研究与编写（渠道与模型见调用记录）；独立会话静态审阅通过，上游和下游应用均未运行。

## S04 · ev_assisted_attempt_2_3

https://github.com/liyasthomas/marcdown/blob/f61f79f7d92f4a76a4d1a8bd446201fd2844159b/index.js · f61f79f7d92f4a76a4d1a8bd446201fd2844159b

code_observation: download() reads the #getm textarea value, replaces every LF with CRLF, creates a Blob of type text/plain, and clicks an anchor whose download name is fixed as marcdown.md.

MIT

https://github.com/liyasthomas/marcdown/blob/f61f79f7d92f4a76a4d1a8bd446201fd2844159b/LICENSE

只参考设计；不复制上游代码。OpenCode CLI 研究与编写（渠道与模型见调用记录）；独立会话静态审阅通过，上游和下游应用均未运行。

## S05 · ev_assisted_attempt_2_4

https://github.com/liyasthomas/marcdown/blob/f61f79f7d92f4a76a4d1a8bd446201fd2844159b/index.js · f61f79f7d92f4a76a4d1a8bd446201fd2844159b

code_observation: Counts use innerText from whichever viewer or buffer element is currently visible; the character count removes whitespace runs, and an empty text value writes 0 words, 0 chars, and disables #save.

MIT

https://github.com/liyasthomas/marcdown/blob/f61f79f7d92f4a76a4d1a8bd446201fd2844159b/LICENSE

只参考设计；不复制上游代码。OpenCode CLI 研究与编写（渠道与模型见调用记录）；独立会话静态审阅通过，上游和下游应用均未运行。

## S06 · ev_assisted_attempt_2_5

https://github.com/liyasthomas/marcdown/blob/f61f79f7d92f4a76a4d1a8bd446201fd2844159b/index.js · f61f79f7d92f4a76a4d1a8bd446201fd2844159b

code_observation: SwapBuffers exchanges the preview and buffer references, hides the element that was preview, and sets the element that was buffer to display flex.

MIT

https://github.com/liyasthomas/marcdown/blob/f61f79f7d92f4a76a4d1a8bd446201fd2844159b/LICENSE

只参考设计；不复制上游代码。OpenCode CLI 研究与编写（渠道与模型见调用记录）；独立会话静态审阅通过，上游和下游应用均未运行。

## S07 · ev_assisted_attempt_2_6

https://github.com/liyasthomas/marcdown/blob/f61f79f7d92f4a76a4d1a8bd446201fd2844159b/index.html · f61f79f7d92f4a76a4d1a8bd446201fd2844159b

code_observation: The output section defines #viewer with inline display:none and a sibling #buffer with no inline display style; the #getm textarea is in the editor div immediately before both.

MIT

https://github.com/liyasthomas/marcdown/blob/f61f79f7d92f4a76a4d1a8bd446201fd2844159b/LICENSE

只参考设计；不复制上游代码。OpenCode CLI 研究与编写（渠道与模型见调用记录）；独立会话静态审阅通过，上游和下游应用均未运行。

## S08 · ev_assisted_attempt_2_7

https://github.com/liyasthomas/marcdown/blob/f61f79f7d92f4a76a4d1a8bd446201fd2844159b/README.md · f61f79f7d92f4a76a4d1a8bd446201fd2844159b

documentation: The documented demo loop is to paste or type markdown on the left, view the preview on the right, then save the markdown file.

MIT

https://github.com/liyasthomas/marcdown/blob/f61f79f7d92f4a76a4d1a8bd446201fd2844159b/LICENSE

只参考设计；不复制上游代码。OpenCode CLI 研究与编写（渠道与模型见调用记录）；独立会话静态审阅通过，上游和下游应用均未运行。

## S09 · ev_assisted_attempt_2_design

https://github.com/liyasthomas/marcdown/blob/f61f79f7d92f4a76a4d1a8bd446201fd2844159b/LICENSE · f61f79f7d92f4a76a4d1a8bd446201fd2844159b

inference: Build a dependency-free static ES-module web app for the same fixed journey: a textarea source of record, Bold and H1 insertion at the current selection, a preview recomputed only from that text, and Save producing README.md unchanged. The upstream CDN renderer, MathJax, highlight.js, syncscroll, service worker and theme persistence are not replicated; a small deterministic escaped renderer covers only the scenario's headings, emphasis and inline code.

MIT

https://github.com/liyasthomas/marcdown/blob/f61f79f7d92f4a76a4d1a8bd446201fd2844159b/LICENSE

只参考设计；不复制上游代码。OpenCode CLI 研究与编写（渠道与模型见调用记录）；独立会话静态审阅通过，上游和下游应用均未运行。

## 待验证

- 辅助静态独审通过，不代表运行通过
- 上游not_run
- No persistence or autosave: reloading the page loses the draft; only the downloaded file survives.
- Programmatic textarea value replacement may reset the browser undo stack, so undo after Bold or H1 is not guaranteed.
- The renderer covers headings, paragraphs, strong, emphasis and inline code only; unmatched markers stay literal and lists, links, images, tables, fenced blocks, math and raw HTML are not rendered.
- Counts are UTF-16 code units and whitespace-split words: astral characters count as two and unspaced CJK prose counts as one word. Source-looking HTML counts as visible characters.
- H1 only inserts prefixes; existing H1 to H6 lines are preserved, so it is not a heading-level toggle and cannot remove markup.
- No scroll sync, outline, multi-document workspace, syntax highlighting or drag-and-drop.
- Browser download naming and placement, the file chooser, visual layout and undo behavior are manual checks; probe.py verifies the core through Node and does not run a browser.
- openText preserves a leading BOM and line endings exactly; the UI decodes UTF-8 with BOM preservation, but other tools may treat a BOM differently.
- Non-UTF-8 input is decoded as UTF-8 with replacement characters; there is no encoding picker.
