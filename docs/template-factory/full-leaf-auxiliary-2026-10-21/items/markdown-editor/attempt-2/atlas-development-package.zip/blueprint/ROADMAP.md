# 阶段与验收

## P0 · 核心可用

Turn a plain draft into a saved README.md whose formatting exists only as markup characters, verifying the derived preview before saving

| 用例 | 类型 | 行为 | 执行器 |
| --- | --- | --- | --- |
| A01 | positive | Bold on 'A plain phrase.' with offsets 2..7 returns 'A **plain** phrase.' with offsets 4..9 and leaves the input untouched; H1 on a two-line Title/Body document with offsets 0..5 returns a single '# ' prefix, offsets 2..7, and is idempotent; empty and blank documents return unchanged; bad ranges raise INVALID_SELECTION and unsupported actions raise UNKNOWN_ACTION. | acceptance/probe.py |
| A02 | positive | Rendering a Title heading followed by a blank line and 'A **bold** phrase.' produces <h1>Title</h1> and <strong>bold</strong> with no literal **; inline code is escaped; a script tag is escaped as visible text; CRLF and LF render identically; unmatched ** does not create strong. | acceptance/probe.py |
| A03 | positive | The default payload is README.md with mime text/markdown and a body identical to the source, including CRLF and a leading BOM; reopening returns the same text and preview; blank documents raise EMPTY_DOCUMENT; unsafe names raise INVALID_FILENAME; non-string or null input raises INVALID_CONTENT; more than 1,048,576 UTF-8 bytes raises FILE_TOO_LARGE. | acceptance/probe.py |
| A04 | positive | For the fixed heading-plus-bold example, counts are 4 words and 17 characters; bolding a plain phrase changes neither; empty and blank text are 0/0; markup markers are excluded while inline-code content is counted; the returned keys are words then chars. | acceptance/probe.py |
