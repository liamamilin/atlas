# 产品定义

README Markup Editor

a developer writing repository documentation

Turn a plain draft into a saved README.md whose formatting exists only as markup characters, verifying the derived preview before saving

1. Paste or open a plain-text draft of the README into the source editor
2. Select a phrase and use the Bold button, then select a line and use the H1 button, so markup is inserted around the selection
3. Glance at the live preview pane to confirm the heading and emphasis render as intended
4. Save, downloading the .md file, and reopen it to confirm the stored text is the markup itself

- The downloaded .md file contains the literal markup characters and no styling data
- The preview is recomputed from the saved text and shows the same heading and bold phrase
- Word and character counts update to reflect the rendered source

- R01 a developer writing repository documentation: Turn a plain draft into a saved README.md whose formatting exists only as markup characters, verifying the derived preview before saving

| ID | 能力 | 阶段 | 适用性 | 理由 | 来源 | 验收 |
| --- | --- | --- | --- | --- | --- | --- |
| F01 | Selection-based markup insertion: Bold wraps the selected phrase in ** and keeps that phrase selected; H1 adds one '# ' prefix to each selected non-blank line that is not already an ATX heading. | P0 | current required | Bold on 'A plain phrase.' with offsets 2..7 returns 'A **plain** phrase.' with offsets 4..9 and leaves the input untouched; H1 on a two-line Title/Body document with offsets 0..5 returns a single '# ' prefix, offsets 2..7, and is idempotent; empty and blank documents return unchanged; bad ranges raise INVALID_SELECTION and unsupported actions raise UNKNOWN_ACTION. | S01, S02, S03, S04, S05, S06, S07, S08, S09 | A01 |
| F02 | Derived preview: rendered synchronously from source text only, with escaped HTML, ATX headings, strong, emphasis and inline code, and with CRLF, LF and CR treated as equivalent line breaks. | P0 | current required | Rendering a Title heading followed by a blank line and 'A **bold** phrase.' produces <h1>Title</h1> and <strong>bold</strong> with no literal **; inline code is escaped; a script tag is escaped as visible text; CRLF and LF render identically; unmatched ** does not create strong. | S01, S02, S03, S04, S05, S06, S07, S08, S09 | A02 |
| F03 | Markup-only save and reopen: README.md by default, text/markdown, body identical to the source including line endings and BOM; openText is an identity transform under a 1 MiB UTF-8 cap. | P0 | current required | The default payload is README.md with mime text/markdown and a body identical to the source, including CRLF and a leading BOM; reopening returns the same text and preview; blank documents raise EMPTY_DOCUMENT; unsafe names raise INVALID_FILENAME; non-string or null input raises INVALID_CONTENT; more than 1,048,576 UTF-8 bytes raises FILE_TOO_LARGE. | S01, S02, S03, S04, S05, S06, S07, S08, S09 | A03 |
| F04 | Rendered counts: words and UTF-16 characters from preview-visible text, excluding markup, neutral under bolding, and zero for empty text. | P0 | current required | For the fixed heading-plus-bold example, counts are 4 words and 17 characters; bolding a plain phrase changes neither; empty and blank text are 0/0; markup markers are excluded while inline-code content is counted; the returned keys are words then chars. | S01, S02, S03, S04, S05, S06, S07, S08, S09 | A04 |
