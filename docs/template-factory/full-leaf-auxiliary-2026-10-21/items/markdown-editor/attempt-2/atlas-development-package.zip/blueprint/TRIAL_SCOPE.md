# 辅助试用范围

Turn a plain draft into a saved README.md whose formatting exists only as markup characters, verifying the derived preview before saving

- No persistence or autosave: reloading the page loses the draft; only the downloaded file survives.
- Programmatic textarea value replacement may reset the browser undo stack, so undo after Bold or H1 is not guaranteed.
- The renderer covers headings, paragraphs, strong, emphasis and inline code only; unmatched markers stay literal and lists, links, images, tables, fenced blocks, math and raw HTML are not rendered.
- Counts are UTF-16 code units and whitespace-split words: astral characters count as two and unspaced CJK prose counts as one word. Source-looking HTML counts as visible characters.
- H1 only inserts prefixes; existing H1 to H6 lines are preserved, so it is not a heading-level toggle and cannot remove markup.
- No scroll sync, outline, multi-document workspace, syntax highlighting or drag-and-drop.
- Browser download naming and placement, the file chooser, visual layout and undo behavior are manual checks; probe.py verifies the core through Node and does not run a browser.
- openText preserves a leading BOM and line endings exactly; the UI decodes UTF-8 with BOM preservation, but other tools may treat a BOM differently.
- Non-UTF-8 input is decoded as UTF-8 with replacement characters; there is no encoding picker.

OpenCode CLI 研究与编写（渠道与模型见调用记录）；独立会话静态审阅通过，上游和下游应用均未运行。模板先于应用；仅代表场景后续开发应用。严格G1/T08不因本包通过。