# 决策与默认值

## D01 · 首版运行与数据边界？

Serve app/ with a static server (`python3 -m http.server 4173 --directory app`) and use it in a browser; the document lives only in page memory and is written solely through the Save download. Data boundary: no server, database, storage API or network. Node.js >=18 is needed only for acceptance_files/probe.py.

When to ask / 询问条件: 确需公网托管或多人数据时先确认，不自行扩展。

保护本地数据，避免默认外发。

assisted default

## D02 · 是否复刻上游？

Build a dependency-free static ES-module web app for the same fixed journey: a textarea source of record, Bold and H1 insertion at the current selection, a preview recomputed only from that text, and Save producing README.md unchanged. The upstream CDN renderer, MathJax, highlight.js, syncscroll, service worker and theme persistence are not replicated; a small deterministic escaped renderer covers only the scenario's headings, emphasis and inline code.

When to ask / 询问条件: 目标变化、破坏已有数据或需要引入上游实现/依赖时先确认。

不混淆来源事实与目标设计。

assisted default
