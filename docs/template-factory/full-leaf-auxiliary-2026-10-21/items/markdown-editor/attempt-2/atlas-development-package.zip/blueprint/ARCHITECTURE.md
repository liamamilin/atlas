# 架构与契约

# README Markup Editor - target architecture

## 1. Stack, boundary and delivery
- Target: static web app made of HTML, CSS and ES2020 modules under `app/`, with no build step, no third-party runtime dependency and no network request while editing.
- Delivery profile: `web`. Serve `app/` read-only from any static file server.
- One in-memory document per page. No server, database, account, localStorage, sessionStorage or cookie. Reload discards the draft; the downloaded file is the only persistent artifact.
- Source of record is the textarea string. Preview HTML, counts and Save-enabled state are derived and never written back into the document.
- Node.js >=18 is used only by the acceptance adapter to import `src/core.js`; the app itself does not need Node.
- Data flow:
```text
source text + selection -> applyMarkup -> new source text
source text -> renderMarkdown -> preview DOM
source text -> countText -> rendered counts
source text -> createSavePayload -> UTF-8 Blob download
file bytes -> UTF-8 decode preserving BOM -> openText -> source text
```

## 2. File layout
```text
app/
  index.html          toolbar, textarea #source, preview #preview, #status, counts
  styles.css          fixed shell and preview element styling only
  package.json        {'type': 'module'}
  src/core.js         pure contracts: applyMarkup, renderMarkdown, countText, createSavePayload, openText
  src/app.js          DOM wiring, file reading, Blob download
acceptance_files/
  probe.py            stdlib Node-backed verifier for the core contracts
  README.md           run steps, manual UI check, limits
```
- `core.js` imports nothing from the DOM, network or Node built-ins. It may use the global `TextEncoder`.
- `app.js` owns only textarea, file, download and status DOM behavior; decisions come from core functions.

## 3. Document model
`{ text: string, start: int, end: int }`
- `text` is the exact UTF-16 string.
- `start` and `end` are code-unit offsets with `0 <= start <= end <= text.length`.
- No other authoritative state. Save is enabled iff `text.trim() !== ''`.
- Opened bytes are decoded as UTF-8 with the BOM preserved by using `TextDecoder('utf-8', {'ignoreBOM': true})` in the UI. Line endings (LF, CRLF, CR) and a leading U+FEFF are data; open and save preserve them.
- Open does not normalize the selection: it returns `start = 0`, `end = 0`.

## 4. Selection insertion: applyMarkup(doc, action)
Signature: `applyMarkup(doc, action) -> {text, start, end}`. It is pure, never mutates `doc`, and always returns a new object.

Validation order:
1. `doc` must be an object with a string `text`, integer `start` and `end`, and a valid range. Otherwise throw an `Error` with `code = 'INVALID_SELECTION'`.
2. `action` must be exactly `'bold'` or `'h1'`. Otherwise throw `code = 'UNKNOWN_ACTION'`.

### bold
- Insert `**` at `start` and `**` at `end` around the selected text.
- Return selection `[start + 2, end + 2]`, so the selected phrase stays selected without either marker pair.
- An empty selection is allowed: it inserts `****` and puts the caret between the two pairs.

### h1
- Lines are split after CRLF, LF or CR. A line starts at the first character after its separator. A final empty line exists when the text ends with a separator.
- Lines considered are all lines intersecting the half-open range `[start, end)` for a non-empty selection, or the line containing the caret for an empty selection. A line that starts exactly at `end` is not considered when `start < end`. A caret at `text.length` after a trailing separator belongs to the final empty line.
- A line that contains only whitespace is untouched.
- A line already beginning with 1 to 6 `#` characters followed by a space, a tab or end of line is untouched. This makes repeated H1 calls idempotent and leaves an H2 as an H2.
- Every other considered line receives exactly one `# ` inserted at its start.
- If no line receives a prefix, return `{text: doc.text, start: doc.start, end: doc.end}` unchanged.
- Otherwise the new selection keeps the same original characters selected: `newStart = start + 2 * (number of insertions at positions <= start)`; `newEnd = end + 2 * (number of insertions at positions < end)`. For a caret, both ends are `newStart`. This includes prefixes inserted at interior line starts and excludes a prefix inserted exactly at the selection start.
- Consequences: an empty document, a whitespace-only document, a caret on a blank line, or a set of lines that are all existing headings returns unchanged text and selection. H1 with a caret on a plain line inserts `# ` and moves the caret after it. There is no toggle or marker removal.

Pinned examples:
- `A plain phrase.` with selection 2..7 and `bold` becomes `A **plain** phrase.` with selection 4..9.
- The text `One`, blank line, `Body`, trailing newline, with selection 0..9 and `h1` becomes `# One`, blank line, `# Body`, trailing newline, with selection 2..13.

## 5. Derived preview: renderMarkdown(text)
- A non-string input throws `INVALID_CONTENT`.
- Escape `&`, `<`, `>`, double quote and single quote before adding any tags, so source HTML is always visible text rather than markup.
- Split on CRLF, LF or CR. A line of 1 to 6 `#` characters followed by a space, a tab or end of line becomes `<h1>` to `<h6>`; inline formatting applies inside the heading text.
- A blank line closes an open paragraph. Consecutive non-blank, non-heading lines become one `<p>`; line breaks inside that paragraph are retained as newline text.
- Inline subset, in this order: matched backtick code spans first (escaped content, no nested formatting), then `**text**` to `<strong>`, then `*text*` to `<em>`. Unmatched delimiters stay literal.
- Blocks are joined with one newline. Empty or blank-only input returns an empty string. The result depends only on the input.
- Out of scope: links, images, lists, blockquotes, tables, fenced code blocks, raw HTML pass-through, math and footnotes. CSS may style preview elements, but no CSS or styling data is stored in the document.

## 6. Counts, save and open
### countText(text)
- A non-string input throws `INVALID_CONTENT`.
- Render with `renderMarkdown`, strip only the generated block and inline tags, then decode `&lt;`, `&gt;`, `&quot;`, `&#39;` and finally `&amp;` to recover visible text.
- `words`: 0 for empty or whitespace-only visible text, otherwise the count of whitespace-separated tokens. `chars`: the visible text with all whitespace removed, measured in UTF-16 code units.
- Return `{words, chars}` in that key order. Markup markers, heading prefixes and emphasis delimiters are excluded; inline-code content is included; source-looking HTML is visible and counted.

### createSavePayload(doc, filename = 'README.md')
- `doc` must be an object with a string `text`, otherwise `INVALID_CONTENT`.
- If the UTF-8 encoding of `text` exceeds 1,048,576 bytes, throw `FILE_TOO_LARGE`; the boundary is allowed.
- If `text.trim() === ''`, throw `EMPTY_DOCUMENT`.
- `filename` must be a string of 4 to 120 characters, start with an ASCII letter or digit, contain only ASCII letters, digits, dot, underscore or hyphen, and end with `.md` case-insensitively. No directory separators, spaces, control characters or leading dot. Otherwise throw `INVALID_FILENAME`.
- Return `{filename, mime: 'text/markdown', body: doc.text}`. `body` is exactly the source string: no line-ending normalization, no BOM insertion or removal, no added trailing newline, no HTML or style metadata.
- The app has no overwrite operation. The browser owns the download location and may rename on collision; the app never deletes or rewrites an existing local file.

### openText(raw)
- A non-string input throws `INVALID_CONTENT`.
- If the UTF-8 encoding of `raw` exceeds 1,048,576 bytes, throw `FILE_TOO_LARGE`; exactly 1,048,576 bytes is accepted.
- Return `{text: raw, start: 0, end: 0}`. Do not trim, strip a BOM or normalize line endings. An empty string is a valid open, although Save then refuses it.
- Therefore `openText(payload.body).text === payload.body`, and its preview equals the preview before save.

### Error contract
Errors are `Error` objects with a stable `.code` among `INVALID_SELECTION`, `UNKNOWN_ACTION`, `EMPTY_DOCUMENT`, `INVALID_FILENAME`, `FILE_TOO_LARGE` and `INVALID_CONTENT`; messages are human-readable. The UI catches them, shows code and message in `#status`, and leaves the document unchanged.

## 7. UI and lifecycle
- Layout: a header toolbar with B, H1, Open and Save; a `#source` textarea; a `#preview` pane; a `#status` live region; word and character counts.
- On load the document is blank, preview is empty, counts are 0/0, and Save is disabled.
- Text input, selection changes, clicks and key events update the cached `start` and `end` without mutating text.
- Bold or H1 click: read the textarea value and cached selection, call `applyMarkup`, then atomically write the returned text, set the returned selection and recompute preview and counts. If the call throws, keep the old text and selection and show the code.
- Open accepts `.md`, `.markdown` and `.txt`. Read the file bytes, decode UTF-8 with BOM preserved, and call `openText`; replace the current document only after that call succeeds. A failed open shows the code and keeps the old document. No upload or server call occurs.
- Preview and counts recompute synchronously after every edit, insertion or successful open; there is no debounce timer.
- Save calls `createSavePayload` with the default README.md, builds a Blob from `payload.body` with type `text/markdown;charset=utf-8`, triggers a download named `payload.filename`, then revokes the object URL. Save is disabled for blank text and the core still rejects it.
- Page reload starts blank. There is no autosave, undo integration, theme persistence, drag-and-drop, PWA, syntax highlighting, scroll sync or multi-document tab. Those are explicit non-goals.

Lifecycle: blank -> type or open -> derived preview/counts -> insert markup -> derived preview/counts -> save download -> optionally open the saved file as a new document. A failure never partially mutates the document.

## 8. Acceptance mapping
- A01 verifies pure selection insertion: Bold text and selection, H1 prefix/selection/idempotence, blank and empty no-ops, UTF-16 offsets, and coded errors.
- A02 verifies the derived preview: heading and strong output, escaped HTML, inline code and emphasis, paragraph boundaries, CRLF equivalence, determinism and unmatched delimiters.
- A03 verifies save and reopen: default name and MIME, body identity for CRLF and BOM, reopen identity and preview equality, blank, unsafe, non-string and oversized errors.
- A04 verifies visible-text counts: 4 words/17 characters for the pinned example, bolding neutrality, zero for empty text, markup exclusion, inline-code inclusion and key order.
- `probe.py` runs these through a Node ES-module adapter. The browser shell, layout, file chooser and download placement are manual checks; no pixel or download-path claim is made.

## 9. Decisions and limits
- The default filename is README.md to match the fixed journey; custom names are a core contract, not a UI feature.
- H1 inserts prefixes and never removes them. Existing H1 to H6 lines are preserved, so the action is idempotent but not a heading-level switch.
- The renderer is deliberately small. Unmatched markers stay literal; non-supported markup appears as escaped or plain text.
- Counts use UTF-16 units and whitespace tokenization: astral characters count as two and unspaced CJK prose counts as one word. HTML-looking source text counts as visible characters.
- No persistence, collaboration, sync, version control or publishing integration exists.
- The 1 MiB UTF-8 cap is a safety boundary applied on both open and save; larger drafts cannot be saved through this core.
- Source observations describe the upstream files at the pinned commit as static evidence; upstream was not installed or run. Browser behavior for downloads and the file picker is host-owned and only manually checked.
