# 架构与契约

## 默认实现
Python标准库http.server＋SQLite；全新服务端HTML表单，零第三方依赖。单用户本机127.0.0.1，无账户/云同步，不连接银行；固定CNY。

## 数据与金额
months(month PRIMARY KEY,income_minor INTEGER)；categories(id,month,name,planned_minor INTEGER, UNIQUE(month,name))；expenses(id,month,date,category_id,amount_minor INTEGER,note)；template(name PRIMARY KEY,planned_minor INTEGER)。金额输入仅十进制定点字符串，最多两位小数，不接受NaN/Inf/科学记数法；Decimal转整数分，收入/预算>=0、支出/转移>0，单项上限999999999.99；不使用浮点求和。
按月份和分类聚合；实际=本月交易SUM，剩余=计划-实际，允许超支为负；未分配=收入-计划，负数明确提示。修改交易原行更新，每次查询重新聚合，不维护容易漂移的余额缓存。事务内校验分类/日期归属与金额，失败零写入。GET不隐式创建月份。
分类转移只修改同月两个planned_minor，不允许转出超过源分类计划，不转移交易，计划总额保持不变。月度模板通过显式保存计划覆盖；新月份显式创建，从模板复制分类/计划/预计收入但绝不复制交易或剩余；没有模板时为空月。已有月份重建应409不覆盖。

## JSON接口
GET /api/health；GET /api/state?month=YYYY-MM 返回initialized、month、income_minor、categories、expenses、totals(planned_minor/spent_minor/remaining_minor/unallocated_minor)。
POST /api/months/start {month}→201；POST /api/income {month,income}→200；POST /api/categories {month,name,amount}→201；POST /api/categories/update {id,month,amount}→200；POST /api/expenses {month,date,category_id,amount,note}→201；POST /api/expenses/update {id,month,date,category_id,amount,note}→200；POST /api/transfer {month,source_id,target_id,amount}→200；POST /api/template {month}→200。金额字段为元字符串，输出*_minor为整数分。
400 invalid_amount/invalid_date/invalid_month/invalid_category/invalid_name/bad_request，404 not_found，409 already_exists；{error:{code,message}}。不向外部请求，不使用真实财务资料作为演示。

## HTML与恢复
GET /?month=YYYY-MM 顶部month-form选择月份；未创建显示明确“创建本月计划”；已创建显示收入/预算/实际/剩余、分类行、支出表与新增支出表单。所有写表单POST至与API共用服务的对应路径，无JS假列表；成功303回所选月，失败400/409可读role=alert并保留输入及月份。每笔支出“编辑”进入/expense/{id}/edit，原值回填、保存后重算；分类行支持预算修改；转移与模板独立有说明。默认小样本演示仅显式--demo且新库一次性加入。

## 范围
无结转（场景要求）；本月剩余不带下月。正文无银行同步/汇率/账户簿/投资建议；不宣称上游运行、自动独审或严格G1通过。保留普通顺序使用、事务一致性和重启持久化。
