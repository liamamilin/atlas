# 品类认知与来源

固定的模型调研记录；来源访问日期与 Atlas 叶子原稿编写日期含义不同。叶子原稿的研究笔记链接属于原语料上下文，不表示本包附带该文件；本包来源以以下条目及未知项为准。

按同一规范共享case记录研究；代码观察与目标推断分别标识，证据独立审阅pending，上游运行not_run。
ev_assisted_budget_design [inference]: 本地单用户、人民币两位小数转整数分、预计收入、正数支出、无结转模板月度启动，是本场景的适配设计；不声称上游与本应用语义完全相同。
ev_assisted_budget_docs [documentation]: 入门文档说明信封预算可在分类间移动可用资金，并介绍按月份分配预算及对照预算与实际支出。
ev_assisted_budget_minor [code_observation]: CLI set-amount显式要求month、category和以cents为单位的amount，通过parseIntFlag解析整数再调用setBudgetAmount。
ev_assisted_budget_recompute [code_observation]: 账户相关属性变化处理按月份枚举交易分类，并调用sheet.recompute重新计算sum-amount；这是上游重算机制的静态代码观察。
ev_assisted_budget_sum [code_observation]: 预算源码通过SQL按交易日期月份和分类GROUP BY聚合SUM(t.amount)，并以month-category键保存分类月度支出；该观察不说明本试用程序已运行。

## S01 · Atlas confirmed input

inputs/scenario.json · scn_6fb4896d9eb0428aa1c080df0a137813@1

为一个月的各项用途预先设定计划金额，并在每次消费前查看该用途的剩余额度，让计划真正影响消费决策。

Atlas scenario input; not a third-party code license



Pinned requirement input

## S02 · ev_assisted_budget_design

https://github.com/actualbudget/actual/blob/8fba0e87cf7a4cda6ab5ea8012477bd7051f6ebc/LICENSE.txt · 8fba0e87cf7a4cda6ab5ea8012477bd7051f6ebc

inference: 本地单用户、人民币两位小数转整数分、预计收入、正数支出、无结转模板月度启动，是本场景的适配设计；不声称上游与本应用语义完全相同。

上游LICENSE.txt为MIT；本包只引用设计证据，不复制实现。

https://github.com/actualbudget/actual/blob/8fba0e87cf7a4cda6ab5ea8012477bd7051f6ebc/LICENSE.txt

参考，不直接复用代码；独立审阅pending，上游运行not_run

## S03 · ev_assisted_budget_docs

https://github.com/actualbudget/actual/blob/8fba0e87cf7a4cda6ab5ea8012477bd7051f6ebc/packages/docs/docs/getting-started/starting-fresh.md · 8fba0e87cf7a4cda6ab5ea8012477bd7051f6ebc

documentation: 入门文档说明信封预算可在分类间移动可用资金，并介绍按月份分配预算及对照预算与实际支出。

上游LICENSE.txt为MIT；本包只引用设计证据，不复制实现。

https://github.com/actualbudget/actual/blob/8fba0e87cf7a4cda6ab5ea8012477bd7051f6ebc/LICENSE.txt

参考，不直接复用代码；独立审阅pending，上游运行not_run

## S04 · ev_assisted_budget_minor

https://github.com/actualbudget/actual/blob/8fba0e87cf7a4cda6ab5ea8012477bd7051f6ebc/packages/cli/src/commands/budgets.ts · 8fba0e87cf7a4cda6ab5ea8012477bd7051f6ebc

code_observation: CLI set-amount显式要求month、category和以cents为单位的amount，通过parseIntFlag解析整数再调用setBudgetAmount。

上游LICENSE.txt为MIT；本包只引用设计证据，不复制实现。

https://github.com/actualbudget/actual/blob/8fba0e87cf7a4cda6ab5ea8012477bd7051f6ebc/LICENSE.txt

参考，不直接复用代码；独立审阅pending，上游运行not_run

## S05 · ev_assisted_budget_recompute

https://github.com/actualbudget/actual/blob/8fba0e87cf7a4cda6ab5ea8012477bd7051f6ebc/packages/loot-core/src/server/budget/base.ts · 8fba0e87cf7a4cda6ab5ea8012477bd7051f6ebc

code_observation: 账户相关属性变化处理按月份枚举交易分类，并调用sheet.recompute重新计算sum-amount；这是上游重算机制的静态代码观察。

上游LICENSE.txt为MIT；本包只引用设计证据，不复制实现。

https://github.com/actualbudget/actual/blob/8fba0e87cf7a4cda6ab5ea8012477bd7051f6ebc/LICENSE.txt

参考，不直接复用代码；独立审阅pending，上游运行not_run

## S06 · ev_assisted_budget_sum

https://github.com/actualbudget/actual/blob/8fba0e87cf7a4cda6ab5ea8012477bd7051f6ebc/packages/loot-core/src/server/budget/base.ts · 8fba0e87cf7a4cda6ab5ea8012477bd7051f6ebc

code_observation: 预算源码通过SQL按交易日期月份和分类GROUP BY聚合SUM(t.amount)，并以month-category键保存分类月度支出；该观察不说明本试用程序已运行。

上游LICENSE.txt为MIT；本包只引用设计证据，不复制实现。

https://github.com/actualbudget/actual/blob/8fba0e87cf7a4cda6ab5ea8012477bd7051f6ebc/LICENSE.txt

参考，不直接复用代码；独立审阅pending，上游运行not_run

## 待验证

- 未运行上游；无独立证据审阅通过声明
- 本应用以全新Python代码实现，不复制上游实现；预计收入/无结转/月度模板为本场景设计
